<?php
ob_start();
session_start();
error_reporting(0);
$id_usuario = isset($_SESSION['usuario_id']) ? intval($_SESSION['usuario_id']) : 0;
session_write_close();

header('Content-Type: application/json; charset=utf-8');

function guardarFotoTarea(array $archivo): string
{
    if (($archivo['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return '';
    if (($archivo['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK
        || !isset($archivo['tmp_name'], $archivo['size'])
        || !is_uploaded_file((string)$archivo['tmp_name'])
        || (int)$archivo['size'] > 5 * 1024 * 1024
        || !function_exists('finfo_open')
        || !function_exists('getimagesize')) {
        throw new Exception("Adjunta una imagen JPG, PNG o WEBP válida de hasta 5 MB.");
    }
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    if ($finfo === false) throw new Exception("No se pudieron validar imágenes.");
    $mime = finfo_file($finfo, (string)$archivo['tmp_name']);
    finfo_close($finfo);
    $extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if (!isset($extensions[$mime]) || @getimagesize((string)$archivo['tmp_name']) === false) {
        throw new Exception("Adjunta una imagen JPG, PNG o WEBP válida de hasta 5 MB.");
    }
    $directory = __DIR__ . '/../../inventario/uploads/tareas/';
    if (!is_dir($directory) && !mkdir($directory, 0750, true) && !is_dir($directory)) {
        throw new Exception("No se pudo crear el directorio de imágenes.");
    }
    $filename = 'tarea_' . bin2hex(random_bytes(12)) . '.' . $extensions[$mime];
    if (!move_uploaded_file((string)$archivo['tmp_name'], $directory . $filename)) {
        throw new Exception("No se pudo guardar la imagen adjunta.");
    }
    return $filename;
}

function eliminarFotoTarea(string $filename): void
{
    if (!preg_match('/^tarea_[a-f0-9]{24}\.(jpg|png|webp)$/i', $filename)) return;
    $path = __DIR__ . '/../../inventario/uploads/tareas/' . $filename;
    if (is_file($path) && !unlink($path)) {
        error_log('Administración tareas: no se pudo eliminar el archivo de imagen ' . $filename);
    }
}

try {
    require_once '../../conexion.php';
    if (!isset($conexion) || !$conexion) throw new Exception("Fallo de conexion a la BD.");
    mysqli_set_charset($conexion, "utf8mb4");

    if ($id_usuario === 0) throw new Exception("Sesion expirada.");
    $qRol = mysqli_query($conexion, "SELECT rol FROM usuario WHERE ID = $id_usuario LIMIT 1");
    $datosRol = $qRol ? mysqli_fetch_assoc($qRol) : null;
    if (!$datosRol || !in_array(strtolower(trim((string)$datosRol['rol'])), ['master', 'admin'], true)) {
        http_response_code(403);
        throw new Exception("No tienes permiso para gestionar tareas de Administración.");
    }

    $alterPinned = mysqli_query(
        $conexion,
        "ALTER TABLE tareas_diarias ADD COLUMN IF NOT EXISTS anclada TINYINT(1) NOT NULL DEFAULT 0"
    );
    if (!$alterPinned) {
        error_log('Administración tareas: no se pudo preparar el campo de anclado: ' . mysqli_error($conexion));
        throw new Exception("No se pudo preparar la bandeja de tareas.");
    }

    $accion = $_POST['accion'] ?? '';

    if ($accion === 'get_tareas_hoy') {
        $fecha = date('Y-m-d');
        $q = mysqli_query($conexion, "SELECT * FROM tareas_diarias WHERE id_usuario = $id_usuario AND (fecha_tarea = '$fecha' OR anclada = 1) ORDER BY anclada DESC, estado ASC, id DESC");
        if (!$q) throw new Exception("No se pudieron cargar las tareas de hoy.");
        $data = [];
        while($r = mysqli_fetch_assoc($q)) {
            $data[] = $r;
        }
        echo json_encode(['success' => true, 'data' => $data]); exit;
    }

    if ($accion === 'crear_tarea') {
        $tareaTexto = trim((string)($_POST['tarea'] ?? ''));
        $fechaTexto = trim((string)($_POST['fecha_tarea'] ?? ''));
        if ($tareaTexto === '' || mb_strlen($tareaTexto, 'UTF-8') > 1000 || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $fechaTexto)) {
            throw new Exception("Describe la tarea y selecciona una fecha válida.");
        }
        $tarea = mysqli_real_escape_string($conexion, $tareaTexto);
        $fecha = mysqli_real_escape_string($conexion, $fechaTexto);
        
        $nombre_foto = guardarFotoTarea($_FILES['foto'] ?? []);

        $sql = "INSERT INTO tareas_diarias (id_usuario, tarea, foto, estado, fecha_tarea, anclada) VALUES ($id_usuario, '$tarea', '$nombre_foto', 0, '$fecha', 0)";
        if(mysqli_query($conexion, $sql)) { echo json_encode(['success' => true]); }
        else {
            eliminarFotoTarea($nombre_foto);
            throw new Exception("No se pudo guardar la tarea en la base de datos.");
        }
        exit;
    }

    if ($accion === 'editar_tarea') {
        $id = (int)($_POST['id_tarea'] ?? 0);
        $tareaTexto = trim((string)($_POST['tarea'] ?? ''));
        if ($id < 1 || $tareaTexto === '' || mb_strlen($tareaTexto, 'UTF-8') > 1000) {
            throw new Exception("La tarea seleccionada o su descripción no es válida.");
        }
        $tarea = mysqli_real_escape_string($conexion, $tareaTexto);
        $qFotoAnterior = mysqli_query($conexion, "SELECT foto FROM tareas_diarias WHERE id = $id AND id_usuario = $id_usuario LIMIT 1");
        $tareaAnterior = $qFotoAnterior ? mysqli_fetch_assoc($qFotoAnterior) : null;
        if (!$tareaAnterior) throw new Exception("No se encontró la tarea seleccionada.");
        $fotoAnterior = (string)($tareaAnterior['foto'] ?? '');
        $fotoNueva = guardarFotoTarea($_FILES['foto'] ?? []);
        $quitarFoto = (string)($_POST['quitar_foto'] ?? '') === '1';
        $fotoFinal = $fotoNueva !== '' ? $fotoNueva : ($quitarFoto ? '' : $fotoAnterior);
        $fotoFinalSql = mysqli_real_escape_string($conexion, $fotoFinal);
        $updated = mysqli_query($conexion, "UPDATE tareas_diarias SET tarea = '$tarea', foto = '$fotoFinalSql' WHERE id = $id AND id_usuario = $id_usuario");
        if (!$updated) {
            if ($fotoNueva !== '') eliminarFotoTarea($fotoNueva);
            throw new Exception("No se pudo actualizar la tarea.");
        }
        if ($fotoAnterior !== '' && ($fotoNueva !== '' || $quitarFoto)) eliminarFotoTarea($fotoAnterior);
        if (mysqli_affected_rows($conexion) === 0) {
            $exists = mysqli_query($conexion, "SELECT id FROM tareas_diarias WHERE id = $id AND id_usuario = $id_usuario LIMIT 1");
            if (!$exists || mysqli_num_rows($exists) === 0) throw new Exception("No se encontró la tarea seleccionada.");
        }
        echo json_encode(['success' => true]); exit;
    }

    if ($accion === 'anclar_tarea') {
        $id = (int)($_POST['id'] ?? 0);
        $anclada = (int)($_POST['anclada'] ?? -1);
        if ($id < 1 || !in_array($anclada, [0, 1], true)) {
            throw new Exception("La tarea seleccionada no es válida.");
        }
        $updated = mysqli_query(
            $conexion,
            "UPDATE tareas_diarias SET anclada = $anclada WHERE id = $id AND id_usuario = $id_usuario"
        );
        if (!$updated) throw new Exception("No se pudo anclar la tarea a la bandeja.");
        if (mysqli_affected_rows($conexion) === 0) {
            $exists = mysqli_query($conexion, "SELECT id FROM tareas_diarias WHERE id = $id AND id_usuario = $id_usuario LIMIT 1");
            if (!$exists || mysqli_num_rows($exists) === 0) throw new Exception("No se encontró la tarea seleccionada.");
        }
        echo json_encode(['success' => true]); exit;
    }

    if ($accion === 'toggle_tarea') {
        $id = (int)($_POST['id'] ?? 0);
        $estado = (int)($_POST['estado'] ?? -1);
        if ($id < 1 || !in_array($estado, [0, 1], true)) throw new Exception("El estado de la tarea no es válido.");
        if (!mysqli_query($conexion, "UPDATE tareas_diarias SET estado = $estado WHERE id = $id AND id_usuario = $id_usuario")) {
            throw new Exception("No se pudo actualizar el estado de la tarea.");
        }
        echo json_encode(['success' => true]); exit;
    }

    if ($accion === 'eliminar_tarea') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id < 1) throw new Exception("La tarea seleccionada no es válida.");
        $qFoto = mysqli_query($conexion, "SELECT foto FROM tareas_diarias WHERE id = $id AND id_usuario = $id_usuario LIMIT 1");
        $tareaAEliminar = $qFoto ? mysqli_fetch_assoc($qFoto) : null;
        if (!$tareaAEliminar) throw new Exception("No se encontró la tarea seleccionada.");
        $deleted = mysqli_query($conexion, "DELETE FROM tareas_diarias WHERE id = $id AND id_usuario = $id_usuario");
        if (!$deleted) throw new Exception("No se pudo eliminar la tarea.");
        if (mysqli_affected_rows($conexion) === 0) throw new Exception("No se encontró la tarea seleccionada.");
        eliminarFotoTarea((string)($tareaAEliminar['foto'] ?? ''));
        echo json_encode(['success' => true]); exit;
    }

    if ($accion === 'get_historial') {
        $fecha = date('Y-m-d');
        $q = mysqli_query($conexion, "SELECT * FROM tareas_diarias WHERE id_usuario = $id_usuario AND fecha_tarea < '$fecha' AND anclada = 0 ORDER BY fecha_tarea DESC, id DESC");
        if (!$q) throw new Exception("No se pudo cargar el historial de tareas.");
        $data = [];
        while($r = mysqli_fetch_assoc($q)) {
            $data[] = $r;
        }
        echo json_encode(['success' => true, 'data' => $data]); exit;
    }

    throw new Exception("Accion no valida.");

} catch (Throwable $e) {
    echo json_encode(['success' => false, 'msg' => $e->getMessage()]);
    exit;
}
?>