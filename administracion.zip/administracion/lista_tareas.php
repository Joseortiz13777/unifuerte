<?php
ini_set('display_errors', 0); 
error_reporting(E_ALL);
session_start();
require_once '../conexion.php';

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login/index.php");
    exit();
}

$id_usuario = intval($_SESSION['usuario_id']);
$q_usr = mysqli_query($conexion, "SELECT nombre, apellido FROM usuario WHERE ID = $id_usuario");
$datos_usr = mysqli_fetch_assoc($q_usr);
$nombre_completo = $datos_usr['nombre'] . ' ' . $datos_usr['apellido'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Tareas - Unifuerte</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="../portal_ventas/css/estilos_portal.css?v=<?= time(); ?>">
    <link rel="stylesheet" href="css/estilos_admin.css?v=<?= time(); ?>">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .card-tarea { border: 1px solid #d93845; border-radius: 8px; overflow: hidden; }
        .card-tarea-header { background-color: #d93845; color: white; padding: 10px 15px; font-weight: bold; }
        .tarea-item { border: 1px solid #adb5bd; border-radius: 5px; padding: 10px; margin-bottom: 10px; transition: 0.3s; background: white; }
        .tarea-item:hover { box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .checkbox-grande { transform: scale(1.4); margin-right: 15px; cursor: pointer; }
        .texto-tachado { text-decoration: line-through; color: #6c757d; opacity: 0.8; }
        .btn-marcar-entregado { background-color: #198754; color: white; font-weight: bold; border-radius: 4px; padding: 10px; border: none; }
        .btn-marcar-entregado:hover { background-color: #146c43; color: white; }
    </style>
</head>
<body style="background-color: #f8f9fa;">

    <!-- HEADER MOVIL -->
    <div class="d-none mobile-header bg-dark text-white p-3 justify-content-between align-items-center w-100 position-sticky top-0" style="z-index: 1020; background-color: #0B4C8C !important;">
        <div class="d-flex align-items-center"><img src="../img/camisa.jpg" style="height:30px; border-radius: 4px;" class="me-2 bg-white p-1" alt="Logo"><h5 class="m-0 font-sugo">Unifuerte</h5></div>
        <button class="btn btn-outline-light btn-sm" onclick="window.location.href='index.php'"><i class="bi bi-arrow-left fs-3"></i></button>
    </div>

    <div class="container py-4">
        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h4 class="fw-bold text-dark m-0"><i class="bi bi-card-checklist text-primary me-2"></i> Mis Tareas Diarias</h4>
            <div>
                <button class="btn btn-outline-secondary me-2 fw-bold shadow-sm" onclick="abrirHistorial()"><i class="bi bi-clock-history"></i> Historial</button>
                <button class="btn btn-primary fw-bold shadow-sm" onclick="abrirModalNuevaTarea()"><i class="bi bi-plus-lg"></i> Agregar</button>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <!-- TARJETA ESTILO REFERENCIA -->
                <div class="card-tarea shadow-sm bg-white">
                    <div class="card-tarea-header d-flex justify-content-between align-items-center">
                        <span><i class="bi bi-exclamation-triangle-fill me-1"></i> LISTA DEL DIA</span>
                        <span id="lbl_fecha_hoy">--/--/----</span>
                    </div>
                    <div class="p-3">
                        <div class="mb-2">
                            <div class="fw-bold" style="color: #0d6efd;"><i class="bi bi-person-fill"></i> Usuario: <?php echo strtoupper($nombre_completo); ?></div>
                            <div class="text-secondary small fw-bold"><i class="bi bi-phone"></i> Recordatorios Personales</div>
                        </div>
                        <hr class="text-secondary opacity-25">
                        
                        <h6 class="fw-bold" style="color: #d93845;">Tareas a realizar:</h6>
                        
                        <!-- CONTENEDOR DE LAS TAREAS -->
                        <div id="contenedorTareas">
                            <div class="text-center py-4"><div class="spinner-border text-danger"></div></div>
                        </div>

                        <!-- BOTON VERDE ESTILO REFERENCIA -->
                        <button class="btn-marcar-entregado w-100 mt-3 shadow-sm" onclick="limpiarCompletadas()">
                            <i class="bi bi-check2-all me-1"></i> OCULTAR TERMINADAS
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL NUEVA TAREA -->
    <div class="modal fade" id="modalNuevaTarea" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <form id="formNuevaTarea" class="modal-content border-0 shadow-lg" enctype="multipart/form-data">
          <div class="modal-header bg-primary text-white">
              <h5 class="modal-title fw-bold"><i class="bi bi-pencil-square"></i> Nueva Tarea</h5>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body p-4 bg-light">
              <input type="hidden" name="accion" value="crear_tarea">
              <input type="hidden" name="fecha_tarea" id="input_fecha_tarea">
              
              <div class="mb-3">
                  <label class="small text-muted fw-bold mb-1">Descripcion de la tarea *</label>
                  <textarea name="tarea" class="form-control border-primary fw-bold" rows="3" placeholder="Ej: Comprar material en la ferreteria..." required></textarea>
              </div>
              <div class="mb-3">
                  <label class="small text-muted fw-bold mb-1">Adjuntar Foto (Opcional)</label>
                  <input type="file" name="foto" class="form-control" accept="image/*">
              </div>
          </div>
          <div class="modal-footer border-0 bg-white">
              <button type="button" class="btn btn-secondary fw-bold" data-bs-dismiss="modal">Cancelar</button>
              <button type="submit" class="btn btn-primary fw-bold" id="btnGuardarTarea">Guardar Tarea</button>
          </div>
        </form>
      </div>
    </div>

    <!-- MODAL HISTORIAL -->
    <div class="modal fade" id="modalHistorial" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 shadow-lg">
          <div class="modal-header bg-dark text-white">
              <h5 class="modal-title fw-bold"><i class="bi bi-archive"></i> Historial de Tareas Anteriores</h5>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body p-0 bg-light">
              <div class="table-responsive" style="max-height: 60vh; overflow-y: auto;">
                  <table class="table table-hover mb-0">
                      <thead class="table-light sticky-top"><tr><th>Fecha</th><th>Tarea</th><th class="text-center">Estado</th><th class="text-center">Borrar</th></tr></thead>
                      <tbody id="tbodyHistorial"></tbody>
                  </table>
              </div>
          </div>
        </div>
      </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/logica_tareas.js?v=<?= time(); ?>"></script>
</body>
</html>