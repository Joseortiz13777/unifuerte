<style>
    .card-tarea-box { border: 1px solid #d93845; border-radius: 8px; overflow: hidden; background: #fff; }
    .card-tarea-header { background-color: #d93845; color: white; padding: 12px 15px; font-weight: bold; }
    .tarea-caja { border: 1px solid #d9e2ec; border-radius: 12px; padding: 12px 14px; margin-bottom: 10px; transition: 0.2s; display: flex; align-items: flex-start; gap: 10px; background: #fff; }
    .tarea-caja:hover { box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
    .tarea-caja.completada { opacity: 0.7; background-color: #f8f9fa; }
    .tarea-caja-contenido { min-width: 0; flex: 1; }
    .tarea-caja-acciones { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 2px; }
    .tarea-adjunto-panel { padding: 12px; border: 1px solid #d9e2ec; border-radius: 10px; background: #fff; }
    .tarea-adjunto-preview { max-width: 100%; max-height: 170px; object-fit: contain; border-radius: 8px; }
    @media (max-width: 575.98px) {
        .tarea-caja { flex-wrap: wrap; }
        .tarea-caja-acciones { width: 100%; justify-content: flex-end; }
    }
    .tarea-caja.completada .texto-tarea { text-decoration: line-through; color: #6c757d; }
    
    /* ESTILOS NUEVOS PARA EL CHECKBOX GIGANTE */
    .check-tarea { 
        width: 30px !important; 
        height: 30px !important; 
        margin-right: 15px; 
        cursor: pointer; 
        border: 2px solid #0B4C8C !important; /* Borde azul oscuro para que resalte */
        border-radius: 6px !important;
        flex-shrink: 0;
        transition: 0.2s;
    }
    .check-tarea:checked {
        background-color: #198754 !important; /* Fondo verde al completar */
        border-color: #198754 !important;
    }

    .btn-verde-entrega { background-color: #198754; color: white; font-weight: bold; border-radius: 4px; padding: 12px; border: none; width: 100%; transition: 0.2s; }
    .btn-verde-entrega:hover { background-color: #146c43; color: white; }
</style>

<div class="tab-pane fade" id="tab-tareas">
    
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <h5 class="fw-bold text-dark m-0"><i class="bi bi-ui-checks text-primary me-2"></i> Mi Agenda / Tareas</h5>
        <div>
            <button class="btn btn-outline-secondary fw-bold shadow-sm me-2" onclick="abrirHistorialTareas()"><i class="bi bi-archive"></i> Historial</button>
            <button class="btn btn-primary fw-bold shadow-sm" onclick="abrirModalNuevaTarea()"><i class="bi bi-plus-lg"></i> Agregar Tarea</button>
        </div>
    </div>

    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="card-tarea-box shadow-sm mb-4">
                <div class="card-tarea-header d-flex justify-content-between align-items-center">
                    <span><i class="bi bi-exclamation-triangle-fill me-2"></i> LISTA DEL DIA</span>
                    <span id="lbl_fecha_tareas">--/--/----</span>
                </div>
                <div class="p-4">
                    <div class="mb-3">
                        <div class="fw-bold text-primary fs-6"><i class="bi bi-person-fill"></i> Usuario: <?php echo strtoupper($datos_usr['nombre'] . ' ' . $datos_usr['apellido']); ?></div>
                        <div class="text-secondary small fw-bold mt-1"><i class="bi bi-phone"></i> Recordatorios y Pendientes</div>
                    </div>
                    
                    <hr class="text-secondary opacity-25 mb-4">
                    
                    <h6 class="fw-bold mb-1" style="color: #d93845;">Tareas a realizar:</h6>
                    <p class="small text-muted mb-3"><i class="bi bi-pin-angle-fill text-warning"></i> Las tareas ancladas aparecen primero en la bandeja.</p>
                    
                    <div id="contenedorTareasDiarias">
                        <div class="text-center py-4"><div class="spinner-border text-danger"></div></div>
                    </div>

                    <button class="btn-verde-entrega mt-3 shadow-sm" onclick="cargarTareasHoy()">
                        <i class="bi bi-check2-all me-1"></i> ACTUALIZAR LISTA
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modalFormTarea" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
      <div class="modal-dialog modal-dialog-centered">
        <form id="formTarea" class="modal-content border-0 shadow-lg" enctype="multipart/form-data">
          <div class="modal-header bg-primary text-white">
              <h5 class="modal-title fw-bold" id="titModalTarea"><i class="bi bi-pencil-square"></i> Nueva Tarea</h5>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body p-4 bg-light">
              <input type="hidden" name="accion" id="accion_tarea" value="crear_tarea">
              <input type="hidden" name="id_tarea" id="id_tarea_edit">
              <input type="hidden" name="fecha_tarea" id="input_fecha_tarea">
              
              <div class="mb-3">
                  <label class="small text-muted fw-bold mb-1">Descripcion de la tarea *</label>
                  <textarea name="tarea" id="txt_tarea_desc" class="form-control border-primary fw-bold text-dark" rows="3" placeholder="Ej: Comprar material en la ferreteria..." required></textarea>
              </div>
              <div class="mb-3" id="box_foto_tarea">
                  <label class="small text-muted fw-bold mb-2" for="foto_tarea">Imagen adjunta (opcional)</label>
                  <div class="tarea-adjunto-panel">
                      <div id="foto_actual_tarea" class="mb-2" hidden></div>
                      <label class="small d-flex align-items-center gap-2 mb-2" id="quitar_foto_tarea_label" hidden>
                          <input type="checkbox" name="quitar_foto" value="1" id="quitar_foto_tarea">
                          Quitar imagen actual
                      </label>
                      <input type="file" name="foto" id="foto_tarea" class="form-control" accept="image/jpeg,image/png,image/webp">
                      <div id="foto_nueva_preview" class="mt-2" hidden></div>
                      <small class="text-muted d-block mt-2">JPG, PNG o WEBP; máximo 5 MB. Al adjuntar otra imagen, se reemplaza la actual.</small>
                  </div>
              </div>
          </div>
          <div class="modal-footer border-0 bg-white justify-content-between">
              <button type="button" class="btn btn-secondary fw-bold" data-bs-dismiss="modal">Cancelar</button>
              <button type="submit" class="btn btn-primary fw-bold px-4" id="btnGuardarTarea"><i class="bi bi-save"></i> Guardar</button>
          </div>
        </form>
      </div>
    </div>

    <div class="modal fade" id="modalHistorialTareas" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 shadow-lg">
          <div class="modal-header bg-dark text-white">
              <h5 class="modal-title fw-bold"><i class="bi bi-archive"></i> Historial de Tareas</h5>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body p-0 bg-light">
              <div class="table-responsive" style="max-height: 60vh; overflow-y: auto;">
                  <table class="table table-hover align-middle mb-0">
                      <thead class="table-light sticky-top"><tr><th class="ps-3">Fecha</th><th>Tarea</th><th class="text-center">Estado</th><th class="text-center pe-3">Accion</th></tr></thead>
                      <tbody id="tbodyHistorialTareas"></tbody>
                  </table>
              </div>
          </div>
        </div>
      </div>
    </div>

</div>