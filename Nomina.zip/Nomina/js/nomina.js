let datos_nomina_actual = [];
let id_pago_seleccionado_foto = 0;
let id_lote_actual_subida = 0;
let datos_liquidacion_actual = null; 
let viendoArchivadosPrestaciones = false;
let indiceEdicionActual = -1; 

$(document).ready(function(){
    $("#buscadorArchivo").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $("#tablaPagosArchivoBody tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });

    $(document).on('change', '#liq_id_empleado', function() {
        let f_in = $(this).find(':selected').data('ingreso');
        if (f_in && f_in !== '0000-00-00' && f_in !== 'null') {
            $('#liq_fecha_ingreso').val(f_in);
        } else {
            $('#liq_fecha_ingreso').val('');
        }
    });
});

function mostrarVista(vista, e) {
    $('.vista-spa').hide(); $('#vista' + vista).fadeIn(300);
    $('.nav-link-custom').removeClass('active'); $(e).addClass('active');
    if(vista === 'Registro') cargarEmpleados();
    if(vista === 'Pagos') cargarHistorialPagos();
    if(vista === 'Asistencia') cargarAsistencia();
    if(vista === 'Prestaciones') { viendoArchivadosPrestaciones = false; toggleInterfacePrestaciones(); cargarHistorialPrestaciones(); }
    if(vista === 'Prestamos') cargarVales(); 
}

// ============================ REGISTRO DE PERSONAL ==============================
function abrirModalEmpleado() { $('#formEmpleado')[0].reset(); $('#emp_id').val(0); $('#div_estado_emp').hide(); $('#modalEmpleado').modal('show'); }

function asignarSalarioSugerido() {
    let cargo = $('#emp_cargo').val().toLowerCase();
    let dep = ''; let sal = 0; let ces = 0;

    if(cargo.includes('presidente') || cargo.includes('gerente de ventas')) { dep = 'Administracion'; sal = 35; ces = 20; }
    else if(cargo.includes('logística') || cargo.includes('logistica')) { dep = 'Administracion'; sal = 25; ces = 20; }
    else if(cargo.includes('diseño') || cargo.includes('diseno')) { dep = 'Sistemas / Diseño'; sal = 50; ces = 50; }
    else if(cargo.includes('costurera tipo i')) { dep = 'Produccion / Confeccion'; sal = 25; ces = 20; }
    else if(cargo.includes('costurera tipo ii')) { dep = 'Produccion / Confeccion'; sal = 20; ces = 20; }
    else if(cargo.includes('ayudante de costura')) { dep = 'Produccion / Confeccion'; sal = 15; ces = 20; }
    else if(cargo.includes('cortadora')) { dep = 'Produccion / Confeccion'; sal = 25; ces = 20; }
    else if(cargo.includes('ayudante de corte')) { dep = 'Produccion / Confeccion'; sal = 25; ces = 20; }
    else if(cargo.includes('bordador')) { dep = 'Acabado Final / Bordado'; sal = 25; ces = 20; }
    else if(cargo.includes('limpieza')) { dep = 'Personal de Apoyo'; sal = 15; ces = 20; }
    else if(cargo.includes('contador')) { dep = 'Personal de Apoyo'; sal = 30; ces = 0; }
    else if(cargo.includes('tecnico') || cargo.includes('técnico')) { dep = 'Personal de Apoyo'; sal = 30; ces = 0; }
    else if(cargo.includes('tesista')) { dep = 'Personal de Apoyo'; sal = 20; ces = 0; }
    else if(cargo.includes('pasante')) { dep = 'Personal de Apoyo'; sal = 20; ces = 0; }
    else { Swal.fire('Sin coincidencias', 'Escribe un cargo válido de la lista para auto-asignar', 'info'); return; }

    $('#emp_departamento').val(dep);
    $('#emp_salario').val(sal);
    $('#emp_cesta').val(ces);
    Swal.fire({toast: true, position: 'top-end', icon: 'success', title: 'Salario y Área asignados', showConfirmButton: false, timer: 1500});
}

function cargarEmpleados() {
    $.post('Registro/api_empleados.php', { action: 'listar' }, function(res) {
        if(res.success) {
            let html = ''; let activos = 0;
            res.data.forEach(e => {
                if(e.estado === 'Activo') activos++;

                let bancoTd = (e.banco && e.banco.trim() !== '') 
                    ? `<td class="text-nowrap"><small class="text-primary fw-bold" style="font-size:0.75rem;"><i class="bi bi-bank"></i> ${e.banco}</small><br><small class="text-dark fw-bold" style="font-size:0.75rem; cursor:pointer;" onclick="navigator.clipboard.writeText('${e.nro_cuenta}'); Swal.fire({toast:true, position:'top-end', icon:'success', title:'Cuenta copiada', showConfirmButton:false, timer:1000});" title="Click para copiar cuenta">${e.nro_cuenta} <i class="bi bi-copy text-muted"></i></small></td>`
                    : `<td><span class="badge bg-light text-muted border">Sin registrar</span></td>`;

                let btnEstado = `<span class="badge ${e.estado === 'Activo' ? 'bg-success' : 'bg-danger'}" style="cursor:pointer; padding: 6px 10px;" onclick="cambiarEstadoEmpleado(${e.id}, '${e.estado}', '${e.nombre} ${e.apellido}')" title="Clic para Activar/Desactivar"><i class="bi bi-power"></i> ${e.estado}</span>`;
                let ced_limpia = "V-" + e.cedula.replace(/^[vejgcVEJGC]\s*-\s*/, '').trim().toUpperCase();

                html += `<tr>
                    <td class="fw-bold">${ced_limpia}</td>
                    <td>
                        <div class="fw-bold" style="color:#2e1065;">${e.nombre} ${e.apellido}</div>
                        <small class="text-muted"><i class="bi bi-telephone"></i> ${e.telefono}</small>
                    </td>
                    <td><span class="badge bg-light text-dark border">${e.cargo}</span><br><small class="text-muted" style="font-size:0.65rem;">${e.departamento || ''}</small></td>
                    ${bancoTd}
                    <td class="text-end"><span class="fw-bold text-success">$${e.salario_base}</span><br><small class="text-muted" style="font-size:0.6rem;">${e.frecuencia_pago}</small></td>
                    <td class="text-end fw-bold text-primary">$${e.cesta_ticket}</td>
                    <td class="text-end fw-bold text-warning">$${e.bonos}</td>
                    <td class="text-center">${btnEstado}</td>
                    <td class="text-center text-nowrap">
                        <button class="btn btn-sm btn-outline-info rounded-pill me-1" onclick="abrirModalPerfil(${e.id})"><i class="bi bi-eye-fill"></i></button>
                        <button class="btn btn-sm btn-outline-dark rounded-pill me-1" onclick="imprimirContrato(${e.id})"><i class="bi bi-file-pdf"></i></button>
                        <button class="btn btn-sm btn-outline-primary rounded-pill me-1" onclick='editarEmpleado(${JSON.stringify(e).replace(/'/g, "&apos;")})'><i class="bi bi-pencil"></i></button>
                        <button class="btn btn-sm btn-outline-danger rounded-pill" onclick="eliminarEmpleado(${e.id}, '${e.nombre}')"><i class="bi bi-trash"></i></button>
                    </td></tr>`;
            });
            $('#tablaEmpleadosBody').html(html); $('#resumen_empleados').text(activos);
        }
    }, 'json');
}

$('#formEmpleado').submit(function(e) { e.preventDefault(); $.post('Registro/api_empleados.php', $(this).serialize(), function(res) { if(res.success) { $('#modalEmpleado').modal('hide'); cargarEmpleados(); Swal.fire('Guardado','','success'); } }, 'json'); });

function editarEmpleado(e) { 
    $('#formEmpleado')[0].reset(); 
    $('#emp_id').val(e.id); 
    $('#emp_cedula').val(e.cedula); 
    $('#emp_nombre').val(e.nombre); 
    $('#emp_apellido').val(e.apellido); 
    $('#emp_cargo').val(e.cargo); 
    $('#emp_departamento').val(e.departamento || ''); 
    $('#emp_telefono').val(e.telefono); 

    $('#emp_banco').val(e.banco || ''); 
    $('#emp_nro_cuenta').val(e.nro_cuenta || ''); 

    $('#emp_salario').val(e.salario_base); 
    $('#emp_cesta').val(e.cesta_ticket); 
    $('#emp_bonos').val(e.bonos); 
    $('#emp_frecuencia').val(e.frecuencia_pago); 
    $('#emp_fecha_ingreso').val(e.fecha_ingreso); 
    $('#emp_estado').val(e.estado); 
    $('#div_estado_emp').show(); 
    $('#modalEmpleado').modal('show'); 
}

function eliminarEmpleado(id, n) { Swal.fire({title:'Desincorporar a '+n+'?', icon:'warning', showCancelButton:true}).then((r)=>{ if(r.isConfirmed) $.post('Registro/api_empleados.php',{action:'eliminar', id:id}, function(){cargarEmpleados();}); }); }

function cambiarEstadoEmpleado(id, estadoActual, nombre) {
    let nuevoEstado = estadoActual === 'Activo' ? 'Inactivo' : 'Activo';
    Swal.fire({
        title: `¿Cambiar estado de ${nombre}?`,
        text: `Pasará de ${estadoActual} a ${nuevoEstado}. Al estar Inactivo, no aparecerá en la próxima Nómina.`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#2e1065',
        confirmButtonText: `Sí, marcar como ${nuevoEstado}`,
        cancelButtonText: 'Cancelar'
    }).then((r) => {
        if(r.isConfirmed) {
            $.post('Registro/api_empleados.php', { action: 'cambiar_estado', id: id, estado: nuevoEstado }, function(res){
                if(res.success) {
                    cargarEmpleados();
                    Swal.fire({toast:true, position:'top-end', icon:'success', title:'Estado actualizado', showConfirmButton:false, timer:1500});
                } else {
                    Swal.fire('Error', res.msg, 'error');
                }
            }, 'json');
        }
    });
}

function imprimirContrato(id) { window.open('Registro/imprimir_contrato.php?id=' + id, '_blank'); }

function abrirModalPerfil(id) {
    $.post('Registro/api_empleados.php', { action: 'ver_perfil', id: id }, function(res){
        if(res.success) {
            let p = res.data; 
            $('#perfil_nombre').text(p.nombre + ' ' + p.apellido); 
            $('#perfil_cargo').text(p.cargo); 

            let bancoInfoProfile = p.banco ? `<br><small class="text-muted mt-1 d-block"><i class="bi bi-bank"></i> ${p.banco} - ${p.nro_cuenta}</small>` : '';
            
            let ced_perfil = "V-" + p.cedula.replace(/^[vejgcVEJGC]\s*-\s*/, '').trim().toUpperCase();
            
            $('#perfil_cedula').html(`${ced_perfil} ${bancoInfoProfile}`);

            let partes = p.fecha_ingreso.split('-'); $('#perfil_ingreso').text(`${partes[2]}/${partes[1]}/${partes[0]}`);
            $('#perfil_dias_trabajados').text(p.dias_trabajados); $('#perfil_total_pagado').text('$' + parseFloat(p.total_pagado_historico).toFixed(2));
            let html_pagos = '';
            if(p.pagos_historial.length === 0) html_pagos = '<tr><td colspan="6" class="text-center text-muted">Sin historial</td></tr>';
            else {
                p.pagos_historial.forEach(pg => {
                    html_pagos += `<tr><td class="fw-bold">${pg.fecha_pago_fmt}</td><td><span class="badge bg-secondary">${pg.periodo_fmt}</span></td><td class="text-success">$${parseFloat(pg.salario_base_periodo).toFixed(2)}</td><td class="text-info">+$${parseFloat(pg.asignaciones_extras).toFixed(2)}</td><td class="text-danger">-$${parseFloat(pg.deducciones).toFixed(2)}</td><td class="fw-bold" style="background-color: #f0fdfa; color: #0f766e;">$${parseFloat(pg.total_pagado).toFixed(2)}</td></tr>`;
                });
            }
            $('#tbody_perfil_pagos').html(html_pagos); $('#modalPerfilEmpleado').modal('show');
        }
    }, 'json');
}

// ============================ NUEVO MÓDULO ASISTENCIA DIARIA ==============================
function cargarAsistencia() {
    let fecha = $('#filtro_fecha_asistencia').val();
    if(!fecha) return;
    $('#tablaAsistenciaBody').html('<tr><td colspan="5" class="text-muted py-3"><div class="spinner-border spinner-border-sm text-primary"></div> Cargando...</td></tr>');
    
    $.post('Asistencia/api_asistencia.php', { action: 'listar_dia', fecha: fecha }, function(res) {
        if(res.success) {
            let html = '';
            res.data.forEach((a, index) => {
                let selectEstado = `
                    <select class="form-select form-select-sm fw-bold asis-estado" data-index="${index}" onchange="calcularFilaAsistencia(${index})">
                        <option value="Presente" ${a.estado === 'Presente' ? 'selected' : ''}>Presente</option>
                        <option value="Falta" ${a.estado === 'Falta' ? 'selected' : ''}>Falta</option>
                        <option value="Permiso" ${a.estado === 'Permiso' ? 'selected' : ''}>Permiso Remunerado</option>
                    </select>
                `;
                
                html += `
                <tr id="row_asis_${index}">
                    <td class="text-start fw-bold">
                        ${a.nombre} ${a.apellido}
                        <input type="hidden" class="asis-id-emp" value="${a.id_empleado}">
                    </td>
                    <td style="width: 180px;">${selectEstado}</td>
                    <td style="width: 150px;">
                        <input type="time" class="form-control form-control-sm asis-entrada fw-bold" data-index="${index}" value="${a.hora_entrada || ''}" onchange="calcularFilaAsistencia(${index})">
                    </td>
                    <td style="width: 150px;">
                        <input type="time" class="form-control form-control-sm asis-salida fw-bold" data-index="${index}" value="${a.hora_salida || ''}" onchange="calcularFilaAsistencia(${index})">
                    </td>
                    <td style="width: 250px;">
                        <span class="badge bg-light text-danger border fw-bold asis-resultado w-100 p-2 fs-6" id="res_asis_${index}">
                            ${a.minutos_retardo > 0 ? a.minutos_retardo + ' min retraso' : 'A tiempo'}
                        </span>
                    </td>
                </tr>`;
            });
            if(res.data.length === 0) html = '<tr><td colspan="5" class="text-muted py-4">No hay empleados activos en el sistema.</td></tr>';
            $('#tablaAsistenciaBody').html(html);
            // Hacer cálculo inicial
            res.data.forEach((a, i) => calcularFilaAsistencia(i));
        }
    }, 'json');
}

function calcularFilaAsistencia(index) {
    let estado = $(`#row_asis_${index} .asis-estado`).val();
    let entrada = $(`#row_asis_${index} .asis-entrada`).val();
    let salida = $(`#row_asis_${index} .asis-salida`).val();
    let resSpan = $(`#res_asis_${index}`);
    
    $(`#row_asis_${index} .asis-entrada, #row_asis_${index} .asis-salida`).prop('disabled', estado !== 'Presente');

    if(estado === 'Falta') {
        resSpan.removeClass('text-success text-dark border-success border-dark').addClass('text-danger border-danger').text('Día perdido (1 Falta)');
        return;
    } else if (estado === 'Permiso') {
        resSpan.removeClass('text-danger text-dark border-danger border-dark').addClass('text-success border-success').text('Permiso / Reposo');
        return;
    }

    let minutos_retraso = 0;
    
    if(entrada) {
        let [hE, mE] = entrada.split(':').map(Number);
        let minsEntrada = (hE * 60) + mE;
        let minsEstandarEntrada = (7 * 60) + 30; // 7:30 AM
        if(minsEntrada > minsEstandarEntrada) {
            minutos_retraso += (minsEntrada - minsEstandarEntrada);
        }
    }
    
    if(salida) {
        let [hS, mS] = salida.split(':').map(Number);
        let minsSalida = (hS * 60) + mS;
        let minsEstandarSalida = (16 * 60) + 0; // 4:00 PM
        if(minsSalida < minsEstandarSalida) {
            minutos_retraso += (minsEstandarSalida - minsSalida);
        }
    }

    if(minutos_retraso > 0) {
        let h = Math.floor(minutos_retraso / 60);
        let m = minutos_retraso % 60;
        let txt = h > 0 ? `${h}h ${m}m de retardo` : `${m} min de retardo`;
        resSpan.removeClass('text-success text-dark border-success border-dark').addClass('text-danger border-danger').text(txt);
    } else {
        resSpan.removeClass('text-danger text-dark border-danger border-dark').addClass('text-success border-success').text('A tiempo');
    }
}

function guardarAsistencia() {
    let fecha = $('#filtro_fecha_asistencia').val();
    let registros = [];
    $('#tablaAsistenciaBody tr').each(function(index) {
        let id_emp = $(this).find('.asis-id-emp').val();
        if(id_emp) {
            let estado = $(this).find('.asis-estado').val();
            let entrada = $(this).find('.asis-entrada').val();
            let salida = $(this).find('.asis-salida').val();
            
            let minutos_retraso = 0;
            if(estado === 'Presente') {
                if(entrada) {
                    let [hE, mE] = entrada.split(':').map(Number);
                    if((hE*60)+mE > 450) minutos_retraso += ((hE*60)+mE) - 450;
                }
                if(salida) {
                    let [hS, mS] = salida.split(':').map(Number);
                    if((hS*60)+mS < 960) minutos_retraso += 960 - ((hS*60)+mS);
                }
            }

            registros.push({
                id_empleado: id_emp,
                estado: estado,
                hora_entrada: entrada || null,
                hora_salida: salida || null,
                minutos_retardo: minutos_retraso
            });
        }
    });

    Swal.fire({ title: 'Guardando...', allowOutsideClick: false, didOpen: () => { Swal.showLoading(); }});
    
    $.post('Asistencia/api_asistencia.php', {
        action: 'guardar_lote',
        fecha: fecha,
        registros: JSON.stringify(registros)
    }, function(res) {
        if(res.success) {
            Swal.fire('¡Asistencia Guardada!', 'Los registros se han actualizado con éxito. Si existen faltas, el sistema las descontará en nómina.', 'success');
        } else {
            Swal.fire('Error', res.msg, 'error');
        }
    }, 'json');
}

// ============================ PAGOS / GENERAR NÓMINA ==============================
function abrirModalGenerarNomina() { 
    $('#formFiltroNomina')[0].reset(); 
    $('#nom_id_lote_edit').val(0); 
    document.getElementById('nom_fecha_pago').valueAsDate = new Date(); 
    $('#box_previa_nomina').hide(); 
    $('#btnProcesarNomina').hide(); 
    $('#modalGenerarNomina').modal('show'); 
}

$('#formFiltroNomina').submit(function(e) {
    e.preventDefault();
    let f_i = $('#nom_fecha_inicio').val(); let f_f = $('#nom_fecha_fin').val(); let t = parseFloat($('#nom_tasa_bcv').val());
    if(f_i > f_f) { Swal.fire('Error', 'Fechas inválidas', 'error'); return; }
    if(t <= 0) { Swal.fire('Atención', 'Ingrese la Tasa BCV para calcular en Bolívares', 'warning'); return; }

    $('#tbody_previa_nomina').html('<tr><td colspan="20" class="text-center py-4"><div class="spinner-border text-primary"></div></td></tr>');
    $('#box_previa_nomina').slideDown();

    $.post('Pagos/api_pagos.php', { action: 'generar_previa', fecha_inicio: f_i, fecha_fin: f_f }, function(res) {
        if(res.success) { datos_nomina_actual = res.data; renderTablaNomina(); }
    }, 'json');
});

// AQUI SE REEMPLAZÓ EL CÓDIGO POR LA TABLA MODO LECTURA Y BOTÓN EDITAR
function renderTablaNomina() {
    let html = ''; let cargo_actual = '';
    let t_sue=0, t_ces=0, t_bon=0, t_per=0, t_he=0, t_prod=0, t_pend=0, t_asig=0;
    let t_df=0, t_hf=0, t_pres=0, t_deduc=0, t_neto=0, t_bs=0;
    let tasa = parseFloat($('#nom_tasa_bcv').val()) || 0;

    datos_nomina_actual.forEach((n, i) => {
        if (n.cargo !== cargo_actual) { 
            html += `<tr><td colspan="20" class="bg-light fw-bold text-start text-dark text-uppercase border-bottom border-top border-2" style="font-size:0.85rem; letter-spacing: 1px;">${n.cargo}</td></tr>`; 
            cargo_actual = n.cargo; 
        }

        let s_q = n.sueldo_quincena; let c_t = n.cesta_ticket; let b_a = n.bono_ayuda; let percibir = s_q + c_t + b_a;
        let s_diario = percibir > 0 ? percibir / 15 : 0; let s_hora = s_diario > 0 ? s_diario / 8 : 0;

        let val_sabados = n.qty_sabados * s_diario * 1.5; 
        let val_he_diurna = n.qty_he_diurna * s_hora * 1.5; 
        let val_he_noct = n.qty_he_noct * s_hora * 1.8;
        let total_he_usd = val_sabados + val_he_diurna + val_he_noct;

        let asig_total = percibir + total_he_usd + n.bono_prod + n.pago_pendiente;
        let desc_dias = n.dias_falta * s_diario; let desc_horas = n.horas_falta * s_hora;
        let deduc_total = desc_dias + desc_horas + n.vales;

        let pagar_usd = asig_total - deduc_total; if(pagar_usd < 0) pagar_usd = 0;
        let pagar_bs = pagar_usd * tasa;

        // Actualizamos base de datos temporal
        datos_nomina_actual[i].total_percibir = percibir; datos_nomina_actual[i].salario_diario = s_diario; datos_nomina_actual[i].valor_hora = s_hora; datos_nomina_actual[i].valor_sabados = val_sabados; datos_nomina_actual[i].valor_he_diurna = val_he_diurna; datos_nomina_actual[i].valor_he_noct = val_he_noct; datos_nomina_actual[i].monto_descuento_dias = desc_dias; datos_nomina_actual[i].monto_descuento_horas = desc_horas; datos_nomina_actual[i].total_asignaciones = asig_total; datos_nomina_actual[i].total_deducciones = deduc_total; datos_nomina_actual[i].total_pagar = pagar_usd;

        t_sue+=s_q; t_ces+=c_t; t_bon+=b_a; t_per+=percibir; t_he+=total_he_usd; t_prod+=n.bono_prod; t_pend+=n.pago_pendiente; t_asig+=asig_total;
        t_df+=desc_dias; t_hf+=desc_horas; t_pres+=n.vales; t_deduc+=deduc_total; t_neto+=pagar_usd; t_bs+=pagar_bs;

        html += `<tr>
            <td class="text-center align-middle">
                <button type="button" class="btn btn-sm btn-primary rounded shadow-sm" onclick="abrirModalEdicionEmpleado(${i})">
                    <i class="bi bi-pencil-square"></i> Editar
                </button>
            </td>
            <td class="text-start fw-bold text-dark text-nowrap">${n.nombre_completo}<br><small class="text-muted fw-normal">${n.cedula}</small></td>
            <td class="text-center">$${s_q.toFixed(2)}</td>
            <td class="text-center">$${c_t.toFixed(2)}</td>
            <td class="text-center text-warning fw-bold">$${b_a.toFixed(2)}</td>
            <td class="col-ingreso">$${percibir.toFixed(2)}</td>
            <td class="text-center">${n.qty_sabados}</td>
            <td class="text-center">${n.qty_he_diurna}</td>
            <td class="text-center">${n.qty_he_noct}</td>
            <td class="fw-bold" style="color:#0369a1;">$${total_he_usd.toFixed(2)}</td>
            <td class="text-center">$${n.bono_prod.toFixed(2)}</td>
            <td class="fw-bold" style="color:#0284c7;">$${n.pago_pendiente.toFixed(2)}</td>
            <td class="bg-primary text-white fw-bold">$${asig_total.toFixed(2)}</td>
            <td class="text-center text-danger fw-bold">${n.dias_falta}</td>
            <td class="text-center text-danger fw-bold">${n.horas_falta}</td>
            <td class="col-deduc">-$${desc_dias.toFixed(2)}</td>
            <td class="col-deduc">-$${desc_horas.toFixed(2)}</td>
            <td class="fw-bold" style="color:#9a3412;">-$${n.vales.toFixed(2)}</td>
            <td class="bg-danger text-white fw-bold">-$${deduc_total.toFixed(2)}</td>
            <td class="bg-success text-white fw-bold fs-6">$${pagar_usd.toFixed(2)}</td>
        </tr>`;
    });
    $('#tbody_previa_nomina').html(html); 
    
    // Totales del footer
    $('#tot_sueldo').text('$'+t_sue.toFixed(2)); $('#tot_cesta').text('$'+t_ces.toFixed(2)); $('#tot_bono').text('$'+t_bon.toFixed(2)); $('#tot_percibir').text('$'+t_per.toFixed(2));
    $('#tot_he').text('$'+t_he.toFixed(2)); $('#tot_prod').text('$'+t_prod.toFixed(2)); $('#tot_pend').text('$'+t_pend.toFixed(2)); $('#tot_asig').text('$'+t_asig.toFixed(2));
    $('#tot_df').text('-$'+t_df.toFixed(2)); $('#tot_hf').text('-$'+t_hf.toFixed(2)); $('#tot_pres').text('-$'+t_pres.toFixed(2)); $('#tot_deduc').text('-$'+t_deduc.toFixed(2));
    $('#tot_neto_usd').text('$'+t_neto.toFixed(2)); $('#tot_neto_bs').text('Bs '+t_bs.toFixed(2));
    $('#btnProcesarNomina').show();
}

function abrirModalEdicionEmpleado(index) {
    indiceEdicionActual = index;
    let emp = datos_nomina_actual[index];

    $('#editNom_nombre').text(emp.nombre_completo);
    $('#editNom_cargo').text(emp.cargo);
    
    $('#editNom_sueldo').val(emp.sueldo_quincena);
    $('#editNom_cesta').val(emp.cesta_ticket);
    $('#editNom_bono').val(emp.bono_ayuda);
    
    $('#editNom_sabados').val(emp.qty_sabados);
    $('#editNom_he_diurna').val(emp.qty_he_diurna);
    $('#editNom_he_noct').val(emp.qty_he_noct);
    $('#editNom_bono_prod').val(emp.bono_prod);
    
    $('#editNom_dias_falta').val(emp.dias_falta);
    $('#editNom_horas_falta').val(emp.horas_falta);

    $('#modalEditarValoresNomina').modal('show');
}

function guardarEdicionNomina() {
    if (indiceEdicionActual > -1) {
        let n = datos_nomina_actual[indiceEdicionActual];
        
        n.sueldo_quincena = parseFloat($('#editNom_sueldo').val()) || 0;
        n.cesta_ticket = parseFloat($('#editNom_cesta').val()) || 0;
        n.bono_ayuda = parseFloat($('#editNom_bono').val()) || 0;
        
        n.qty_sabados = parseFloat($('#editNom_sabados').val()) || 0;
        n.qty_he_diurna = parseFloat($('#editNom_he_diurna').val()) || 0;
        n.qty_he_noct = parseFloat($('#editNom_he_noct').val()) || 0;
        n.bono_prod = parseFloat($('#editNom_bono_prod').val()) || 0;
        
        n.dias_falta = parseFloat($('#editNom_dias_falta').val()) || 0;
        n.horas_falta = parseFloat($('#editNom_horas_falta').val()) || 0;

        $('#modalEditarValoresNomina').modal('hide');
        renderTablaNomina(); 
        Swal.fire({toast: true, position: 'top-end', icon: 'success', title: 'Valores actualizados', showConfirmButton: false, timer: 1000});
    }
}

function procesarNominaDefinitiva() { 
    Swal.fire({ title: '¿Guardar Nómina?', icon: 'warning', showCancelButton: true, confirmButtonText: 'Sí, Guardar' }).then((r) => { 
        if (r.isConfirmed) { 
            Swal.fire({ title: 'Procesando y guardando...', allowOutsideClick: false, didOpen: () => { Swal.showLoading(); }});
            $.post('Pagos/api_pagos.php', { 
                action: 'procesar_nomina', 
                id_lote_edit: $('#nom_id_lote_edit').val(), 
                fecha_inicio: $('#nom_fecha_inicio').val(), 
                fecha_fin: $('#nom_fecha_fin').val(), 
                fecha_pago: $('#nom_fecha_pago').val(), 
                tasa_bcv: $('#nom_tasa_bcv').val(), 
                datos_nomina: JSON.stringify(datos_nomina_actual) 
            }, function(res) { 
                if(res.success) { 
                    Swal.fire('Nómina Procesada', 'Se ha guardado el listín con éxito', 'success'); 
                    $('#modalGenerarNomina').modal('hide'); 
                    cargarHistorialPagos(); 
                } else {
                    Swal.fire('Error del Servidor', res.msg, 'error');
                }
            }, 'json').fail(function() {
                Swal.fire('Error', 'Fallo de conexión al intentar guardar la nómina.', 'error');
            }); 
        } 
    }); 
}

function editarLote(id_lote) {
    $('#formFiltroNomina')[0].reset();
    $('#nom_id_lote_edit').val(id_lote);
    $('#box_previa_nomina').hide();
    $('#btnProcesarNomina').hide();

    Swal.fire({ title: 'Cargando Nómina...', allowOutsideClick: false, didOpen: () => { Swal.showLoading(); }});

    $.post('Pagos/api_pagos.php', { action: 'cargar_lote_editar', id_lote: id_lote }, function(res) {
        Swal.close();
        if(res.success) {
            $('#nom_fecha_inicio').val(res.lote.fecha_inicio);
            $('#nom_fecha_fin').val(res.lote.fecha_fin);
            $('#nom_fecha_pago').val(res.lote.fecha_pago);
            $('#nom_tasa_bcv').val(parseFloat(res.lote.tasa_bcv).toFixed(2));

            datos_nomina_actual = res.data;
            $('#box_previa_nomina').slideDown();
            renderTablaNomina();
            $('#modalGenerarNomina').modal('show');
        } else {
            Swal.fire('Error', res.msg, 'error');
        }
    }, 'json');
}

function cargarHistorialPagos() {
    $.post('Pagos/api_pagos.php', { action: 'listar_historial_lotes' }, function(res) {
        if(res.success) {
            let htmlPendientes = '';
            let htmlArchivo = '';

            res.data.forEach(l => {
                let isFinalizada = (l.estado === 'Finalizada');
                let badgeEstado = isFinalizada ? 
                    `<span class="badge bg-success mb-1 d-block"><i class="bi bi-check2-all"></i> Finalizada</span>` : 
                    `<span class="badge bg-warning text-dark mb-1 d-block"><i class="bi bi-clock"></i> Pendiente</span>`;

                let btnFinalizar = isFinalizada ? '' : `
                    <button class="btn btn-sm btn-warning mb-1 rounded-pill" onclick="editarLote(${l.id})"><i class="bi bi-pencil"></i> Editar</button>
                    <button class="btn btn-sm btn-success mb-1 rounded-pill" onclick="finalizarLote(${l.id})"><i class="bi bi-check-circle"></i> Finalizar</button>
                `;

                let row = `<tr>
                    <td class="fw-bold text-center">#${l.id}</td>
                    <td class="fw-bold"><i class="bi bi-calendar-check"></i> ${l.fecha_pago_fmt}</td>
                    <td><span class="badge bg-light text-dark border">${l.periodo_fmt}</span></td>
                    <td class="text-end fw-bold text-success">$${parseFloat(l.total_usd).toFixed(2)}</td>
                    <td class="text-end fw-bold text-primary">Bs ${parseFloat(l.total_bs).toFixed(2)}</td>
                    <td class="text-center">${badgeEstado}</td>
                    <td class="text-center"><button class="btn btn-sm btn-outline-secondary rounded-pill px-3" onclick="abrirModalSubidaIndividual(${l.id})"><i class="bi bi-camera"></i> Subir Recibos</button></td>
                    <td class="text-center">
                        <div class="btn-group-vertical w-100">
                            <button class="btn btn-sm btn-dark mb-1 rounded-pill" onclick="imprimirListinGuardado('${l.fecha_pago}')"><i class="bi bi-list-columns-reverse"></i> Nómina Gral</button>
                            <button class="btn btn-sm btn-outline-dark mb-1 rounded-pill" onclick="imprimirRecibosLote(${l.id})"><i class="bi bi-file-person"></i> Recibos</button>
                            ${btnFinalizar}
                            <button class="btn btn-sm btn-danger mt-1 rounded-pill" onclick="eliminarLote(${l.id})"><i class="bi bi-trash"></i> Eliminar</button>
                        </div>
                    </td>
                </tr>`;

                if(isFinalizada) {
                    htmlArchivo += row;
                } else {
                    htmlPendientes += row;
                }
            });

            if(htmlPendientes === '') htmlPendientes = '<tr><td colspan="8" class="text-center text-muted py-4">No hay nóminas pendientes.</td></tr>';
            if(htmlArchivo === '') htmlArchivo = '<tr><td colspan="8" class="text-center text-muted py-4">El archivo está vacío.</td></tr>';

            $('#tablaPagosPendientesBody').html(htmlPendientes);
            $('#tablaPagosArchivoBody').html(htmlArchivo);
        }
    }, 'json');
}

function finalizarLote(id_lote) { Swal.fire({ title: '¿Mover al Archivo Histórico?', text: "La nómina pasará a estado Finalizada y se guardará en el Archivo.", icon: 'info', showCancelButton: true, confirmButtonText: 'Sí, Archivar' }).then((r) => { if (r.isConfirmed) { $.post('Pagos/api_pagos.php', { action: 'finalizar_lote', id_lote: id_lote }, function(res) { if(res.success) { cargarHistorialPagos(); Swal.fire('Archivada', '', 'success'); } }); } }); }

function eliminarLote(id_lote) {
    Swal.fire({
        title: '¿Eliminar Nómina?',
        text: "Esta acción borrará el lote y todos los pagos asociados a los trabajadores. ¡Es irreversible!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#dc3545',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Sí, Eliminar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            $.post('Pagos/api_pagos.php', { action: 'eliminar_lote', id_lote: id_lote }, function(res) {
                if (res.success) {
                    Swal.fire('¡Eliminado!', 'El lote de nómina ha sido borrado por completo.', 'success');
                    cargarHistorialPagos();
                } else {
                    Swal.fire('Error', res.msg, 'error');
                }
            }, 'json');
        }
    });
}

function imprimirListinGuardado(fecha_pago) { window.open('Pagos/imprimir_nomina.php?fecha=' + fecha_pago, '_blank'); }
function imprimirRecibosLote(id_lote) { window.open('Pagos/imprimir_todos_recibos.php?id_lote=' + id_lote, '_blank'); }

function abrirModalSubidaIndividual(id_lote) { 
    id_lote_actual_subida = id_lote; 
    $('#lbl_lote_subida').text(id_lote); 
    cargarTablaSubidaIndividual(id_lote); 
    $('#modalSubidaIndividual').modal('show'); 
}

function cargarTablaSubidaIndividual(id_lote) {
    $('#tbody_subida_individual').html('<tr><td colspan="4" class="text-center"><div class="spinner-border spinner-border-sm text-primary"></div></td></tr>');
    $.post('Pagos/api_pagos.php', { action: 'listar_detalles_lote', id_lote: id_lote }, function(res) {
        if(res.success) {
            let html = '';
            res.data.forEach(p => {
                let btnSubir = `<button class="btn btn-sm btn-outline-primary rounded-pill px-3" onclick="seleccionarFotoReciboIndiv(${p.id})"><i class="bi bi-upload"></i> Adjuntar</button>`;
                let estadoAval = `<span class="badge bg-warning text-dark">Sin Archivo</span>`;
                
                if(p.comprobante_foto && p.comprobante_foto.trim() !== '') {
                    let fotos = p.comprobante_foto.split(',');
                    let totalFotos = fotos.length;
                    
                    estadoAval = `<span class="badge bg-success shadow-sm" style="cursor:pointer;" onclick="seleccionarFotoReciboIndiv(${p.id})" title="Click para añadir otro comprobante"><i class="bi bi-upload"></i> ${totalFotos} Cargado(s)</span>`;
                    
                    btnSubir = `<button class="btn btn-sm btn-success rounded-pill px-3 me-1" onclick="abrirModalVerComprobantes('${p.comprobante_foto}')"><i class="bi bi-eye"></i> Ver Recibos</button>`;
                    
                    btnSubir += `<button class="btn btn-sm btn-outline-primary rounded-pill px-2 me-1" onclick="seleccionarFotoReciboIndiv(${p.id})" title="Añadir otro recibo"><i class="bi bi-plus-lg"></i></button>`;
                    
                    btnSubir += `<button class="btn btn-sm btn-outline-danger rounded-pill px-2" onclick="limpiarComprobantes(${p.id})" title="Borrar todos los recibos"><i class="bi bi-trash"></i></button>`;
                }
                
                html += `<tr><td class="fw-bold">${p.nombre} ${p.apellido} <br><small class="text-muted">${p.cedula}</small></td><td class="text-end fw-bold text-success">$${parseFloat(p.total_pagado).toFixed(2)}</td><td class="text-center align-middle">${estadoAval}</td><td class="text-center align-middle text-nowrap">${btnSubir}</td></tr>`;
            });
            $('#tbody_subida_individual').html(html);
        }
    }, 'json');
}

function abrirModalVerComprobantes(nombres_fotos) {
    let fotos = nombres_fotos.split(',');
    let html = '';
    fotos.forEach((foto, index) => {
        let ext = foto.split('.').pop().toLowerCase();
        html += `<div class="card mb-3 shadow-sm border-0">
                    <div class="card-header bg-secondary text-white fw-bold py-1">Recibo de Pago ${index + 1}</div>
                    <div class="card-body p-2">`;
        if(ext === 'pdf') {
            html += `<iframe src="../uploads/${foto}" width="100%" height="400px" style="border:none;"></iframe>
                     <a href="../uploads/${foto}" target="_blank" class="btn btn-sm btn-primary mt-2">Abrir PDF en otra pestaña</a>`;
        } else {
            html += `<img src="../uploads/${foto}" class="img-fluid rounded" style="max-height: 500px; object-fit: contain;">
                     <br><a href="../uploads/${foto}" target="_blank" class="btn btn-sm btn-primary mt-3">Ver imagen completa</a>`;
        }
        html += `   </div>
                 </div>`;
    });
    $('#contenedor_comprobantes').html(html);
    $('#modalVerComprobantes').modal('show');
}

function seleccionarFotoReciboIndiv(id_pago) { 
    id_pago_seleccionado_foto = id_pago; 
    $('#input_foto_recibo_indiv').click(); 
}

$('#input_foto_recibo_indiv').change(function() {
    if(this.files.length > 0) {
        let formData = new FormData(); 
        formData.append('action', 'subir_comprobante'); 
        formData.append('id_pago', id_pago_seleccionado_foto); 
        
        for(let i = 0; i < this.files.length; i++) {
            formData.append('comprobantes[]', this.files[i]);
        }
        
        Swal.fire({ title: 'Cargando documento(s)...', allowOutsideClick: false, didOpen: () => { Swal.showLoading(); }});
        $.ajax({ 
            url: 'Pagos/api_pagos.php', type: 'POST', data: formData, contentType: false, processData: false, dataType: 'json',
            success: function(res) { 
                if(res.success) { 
                    Swal.fire({icon: 'success', title: 'Guardado', timer: 1000, showConfirmButton: false}); 
                    cargarTablaSubidaIndividual(id_lote_actual_subida); 
                } else {
                    Swal.fire('Error', res.msg, 'error'); 
                }
                $('#input_foto_recibo_indiv').val(''); 
            }
        });
    }
});

function limpiarComprobantes(id_pago) {
    Swal.fire({
        title: '¿Borrar comprobantes?',
        text: "Se eliminarán los archivos adjuntos actuales de este trabajador.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        confirmButtonText: 'Sí, borrar'
    }).then((result) => {
        if (result.isConfirmed) {
            $.post('Pagos/api_pagos.php', { action: 'limpiar_comprobantes', id_pago: id_pago }, function(res) {
                if(res.success) {
                    cargarTablaSubidaIndividual(id_lote_actual_subida);
                } else {
                    Swal.fire('Error', res.msg, 'error');
                }
            }, 'json');
        }
    });
}

// ============================ PRESTACIONES Y LIQUIDACIONES ==============================
function toggleArchivadosPrestaciones() {
    viendoArchivadosPrestaciones = !viendoArchivadosPrestaciones;
    if (viendoArchivadosPrestaciones) {
        $('#btnToggleArchivadosPrest').html('<i class="bi bi-eye"></i> Ver Activos').removeClass('btn-secondary').addClass('btn-info text-white');
        $('.titulo-prestaciones-tabla').text('Personal Liquidado (ARCHIVADOS)');
    } else {
        $('#btnToggleArchivadosPrest').html('<i class="bi bi-archive"></i> Ver Archivados').removeClass('btn-info text-white').addClass('btn-secondary');
        $('.titulo-prestaciones-tabla').text('Personal Liquidado / Egresado');
    }
    cargarHistorialPrestaciones();
}

function cargarHistorialPrestaciones() {
    let action = viendoArchivadosPrestaciones ? 'listar_archivados' : 'listar_historial';
    $.post('Prestaciones/api_prestaciones.php', { action: action }, function(res) {
        if(res.success) {
            let html = '';
            res.data.forEach(pr => {
                let badge = pr.estado === 'Archivado' 
                    ? `<span class="badge bg-secondary">${pr.estado}</span>` 
                    : `<span class="badge bg-success"><i class="bi bi-check-circle"></i> ${pr.estado}</span>`;
                    
                let btnImprimir = `<button class="btn btn-sm btn-outline-dark rounded-pill me-1" onclick="imprimirLiquidacion(${pr.id})" title="Imprimir PDF"><i class="bi bi-printer"></i></button>`;
                
                let btnEditar = pr.estado === 'Archivado' ? '' : `<button class="btn btn-sm btn-info text-white rounded-pill me-1" onclick="editarLiquidacion(${pr.id})" title="Editar (Revertir)"><i class="bi bi-pencil"></i></button>`;
                
                let btnArchivar = pr.estado === 'Archivado' 
                    ? `<button class="btn btn-sm btn-outline-success rounded-pill me-1" onclick="desarchivarLiquidacion(${pr.id})" title="Restaurar de Archivo"><i class="bi bi-arrow-up-circle"></i></button>`
                    : `<button class="btn btn-sm btn-outline-secondary rounded-pill me-1" onclick="archivarLiquidacion(${pr.id})" title="Archivar"><i class="bi bi-archive"></i></button>`;
                    
                let btnEliminar = pr.estado === 'Archivado' ? '' : `<button class="btn btn-sm btn-outline-danger rounded-pill" onclick="eliminarLiquidacion(${pr.id})" title="Eliminar y Restaurar Trabajador"><i class="bi bi-trash"></i></button>`;
                
                html += `<tr>
                    <td class="fw-bold"><i class="bi bi-calendar2-x text-danger"></i> ${pr.fecha_fmt}</td>
                    <td class="fw-bold text-dark">${pr.nombre} ${pr.apellido} <br><small class="text-muted">${pr.cedula}</small></td>
                    <td><span class="badge bg-secondary">${pr.motivo}</span></td>
                    <td class="text-center fw-bold">${pr.dias_acumulados} Días</td>
                    <td class="text-end text-primary fw-bold">$${parseFloat(pr.salario_promedio).toFixed(2)}</td>
                    <td class="text-end text-danger fw-bold fs-6">$${parseFloat(pr.monto_total).toFixed(2)}</td>
                    <td class="text-center">${badge}</td>
                    <td class="text-center text-nowrap">
                        ${btnImprimir}
                        ${btnEditar}
                        ${btnArchivar}
                        ${btnEliminar}
                    </td>
                </tr>`;
            });
            if(html === '') html = `<tr><td colspan="8" class="text-center text-muted py-4">No hay liquidaciones ${viendoArchivadosPrestaciones ? 'archivadas' : 'registradas'}.</td></tr>`;
            $('#tablaPrestacionesBody').html(html);
        }
    }, 'json');
}

function abrirModalLiquidacion() {
    $('#formSimularLiquidacion')[0].reset();
    document.getElementById('liq_fecha_egreso').valueAsDate = new Date();
    $('#liq_resultados').slideUp();
    $('#modalLiquidacion').modal('show');
}

$('#formSimularLiquidacion').submit(function(e) {
    e.preventDefault();
    let id = $('#liq_id_empleado').val();
    let fecha_ingreso = $('#liq_fecha_ingreso').val();
    let fecha_egreso = $('#liq_fecha_egreso').val();
    let motivo = $('#liq_motivo').val();

    if(!id || !fecha_ingreso || !fecha_egreso) { Swal.fire('Atención', 'Seleccione un empleado y verifique las fechas obligatorias', 'warning'); return; }

    Swal.fire({ title: 'Calculando...', allowOutsideClick: false, didOpen: () => { Swal.showLoading(); }});

    $.ajax({
        url: 'Prestaciones/api_prestaciones.php',
        type: 'POST',
        data: { action: 'simular_liquidacion', id_empleado: id, fecha_ingreso: fecha_ingreso, fecha_egreso: fecha_egreso, motivo: motivo },
        dataType: 'text',
        success: function(responseRaw) {
            Swal.close();
            try {
                let res = JSON.parse(responseRaw);
                if(res.success) {
                    datos_liquidacion_actual = res.data; 
                    let d = res.data;

                    $('#res_tiempo').text(d.tiempo_servicio);
                    $('#res_salario_mensual').text('$' + parseFloat(d.salario_mensual).toFixed(2));
                    $('#res_salario_integral').text('$' + parseFloat(d.salario_integral_diario).toFixed(2));

                    $('#res_dias_cal').text(d.dias_calendario);
                    $('#res_dias_falta').text(d.dias_falta);
                    $('#res_dias_efectivos').text(d.dias_efectivos);

                    $('#res_dias_prest').text(d.dias_prestaciones);
                    $('#res_monto_prest').text('+$' + parseFloat(d.monto_prestaciones).toFixed(2));
                    $('#res_vac_frac').text('+$' + parseFloat(d.vacaciones_fraccionadas).toFixed(2));
                    $('#res_bvac_frac').text('+$' + parseFloat(d.bono_vacacional_fraccionado).toFixed(2));
                    $('#res_uti_frac').text('+$' + parseFloat(d.utilidades_fraccionadas).toFixed(2));

                    if(d.indemnizacion_despido > 0) {
                        $('#fila_indemnizacion').show();
                        $('#res_indemnizacion').text('+$' + parseFloat(d.indemnizacion_despido).toFixed(2));                     } else {$('#fila_indemnizacion').hide();
                    }

                    $('#res_deuda').text('-$' + parseFloat(d.deducciones_pendientes).toFixed(2));
                    $('#res_total_liquidar').text('$' + parseFloat(d.total_liquidar).toFixed(2));

                    $('#liq_resultados').slideDown();
                } else {
                    Swal.fire('Atención', res.msg, 'warning');
                }
            } catch (e) {
                Swal.fire({
                    title: 'Error de Servidor',
                    html: '<p>PHP devolvió un error. Copia esto y repórtalo:</p><textarea class="form-control text-danger fw-bold" rows="6" readonly>' + responseRaw + '</textarea>',
                    icon: 'error'
                });
            }
        }
    });
});

function guardarLiquidacionDefinitiva() {
    Swal.fire({
        title: '¿Confirmar Liquidación?',
        text: "Se registrará el pago y el empleado pasará a INACTIVO automáticamente. Sus deudas serán saldadas.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#dc3545',
        confirmButtonText: 'Sí, Ejecutar Liquidación'
    }).then((r) => {
        if (r.isConfirmed) {
            $.post('Prestaciones/api_prestaciones.php', {
                action: 'guardar_liquidacion',
                id_empleado: $('#liq_id_empleado').val(),
                fecha_egreso: $('#liq_fecha_egreso').val(),
                motivo: $('#liq_motivo').val(),
                datos_json: JSON.stringify(datos_liquidacion_actual)
            }, function(res) {
                if(res.success) {
                    Swal.fire('Liquidación Completada', 'El empleado ha sido desincorporado.', 'success');
                    $('#modalLiquidacion').modal('hide');
                    cargarHistorialPrestaciones();
                    cargarEmpleados(); 
                } else {
                    Swal.fire('Error', res.msg, 'error');
                }
            }, 'json');
        }
    });
}

function archivarLiquidacion(id) {
    Swal.fire({
        title: '¿Archivar liquidación?', 
        text: 'Desaparecerá de esta vista, pero el empleado seguirá inactivo.', 
        icon: 'info', 
        showCancelButton: true,
        confirmButtonColor: '#6c757d',
        confirmButtonText: 'Sí, Archivar'
    }).then((r) => {
        if(r.isConfirmed) {
            $.post('Prestaciones/api_prestaciones.php', {action: 'archivar', id_prestacion: id}, function(res) {
                if(res.success) { 
                    cargarHistorialPrestaciones(); 
                    Swal.fire({toast:true, position:'top-end', icon:'success', title:'Archivado', showConfirmButton:false, timer:1500}); 
                } else { 
                    Swal.fire('Error', res.msg, 'error'); 
                }
            }, 'json');
        }
    });
}

function desarchivarLiquidacion(id) {
    $.post('Prestaciones/api_prestaciones.php', {action: 'desarchivar', id_prestacion: id}, function(res) {
        if(res.success) { 
            cargarHistorialPrestaciones(); 
            Swal.fire({toast:true, position:'top-end', icon:'success', title:'Restaurado', showConfirmButton:false, timer:1500}); 
        } else { 
            Swal.fire('Error', res.msg, 'error'); 
        }
    }, 'json');
}

function eliminarLiquidacion(id) {
    Swal.fire({
        title: '¿Eliminar y Revertir?', 
        text: 'Se borrará esta liquidación. El trabajador volverá a estar "Activo" y sus deudas pendientes se restaurarán.', 
        icon: 'warning', 
        showCancelButton: true,
        confirmButtonColor: '#dc3545',
        confirmButtonText: 'Sí, Eliminar y Revertir'
    }).then((r) => {
        if(r.isConfirmed) {
            $.post('Prestaciones/api_prestaciones.php', {action: 'eliminar', id_prestacion: id}, function(res) {
                if(res.success) { 
                    cargarHistorialPrestaciones(); 
                    cargarEmpleados();
                    Swal.fire({toast:true, position:'top-end', icon:'success', title:'Liquidación Eliminada', showConfirmButton:false, timer:1500}); 
                } else { 
                    Swal.fire('Error', res.msg, 'error'); 
                }
            }, 'json');
        }
    });
}

function editarLiquidacion(id) {
    Swal.fire({
        title: '¿Editar Liquidación?',
        text: 'Para editar, primero debes ELIMINARLA. Esto revertirá al trabajador a estado "Activo" para que simules y generes una nueva liquidación.',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Sí, Eliminar para Editar',
        confirmButtonColor: '#dc3545'
    }).then((result) => {
        if(result.isConfirmed) {
            eliminarLiquidacion(id);
        }
    })
}

function imprimirLiquidacion(id) { window.open('Prestaciones/imprimir_liquidacion.php?id=' + id, '_blank'); }

// ============================ VALES Y PRÉSTAMOS ==============================
function cargarVales() {
    $.post('Prestamos/api_prestamos.php', { action: 'listar' }, function(res) {
        if(res.success) {
            let html = '';
            res.data.forEach(v => {
                let badge = v.estado === 'Pendiente' 
                    ? '<span class="badge bg-warning text-dark"><i class="bi bi-hourglass-split"></i> Por Descontar</span>' 
                    : `<span class="badge bg-success"><i class="bi bi-check-circle"></i> Procesado</span>`;
                    
                let btnEliminar = `<button class="btn btn-sm btn-outline-danger rounded-pill" onclick="eliminarVale(${v.id})" title="Eliminar"><i class="bi bi-trash"></i></button>`;
                
                let btnArchivar = (v.estado === 'Procesado' || v.estado === 'Procesado (Liquidacion)') 
                    ? `<button class="btn btn-sm btn-outline-secondary rounded-pill me-1" onclick="archivarVale(${v.id})" title="Archivar (Ocultar de la lista)"><i class="bi bi-archive"></i></button>` 
                    : '';
                
                let cedula_limpia = "V-" + v.cedula.replace(/^[vejgcVEJGC]\s*-\s*/, '').trim().toUpperCase();

                html += `<tr>
                    <td class="fw-bold">${v.fecha_fmt}</td>
                    <td><div class="fw-bold text-dark">${v.nombre} ${v.apellido}</div><small class="text-muted">${cedula_limpia}</small></td>
                    <td>${v.concepto}</td>
                    <td class="text-end fw-bold text-danger">-${v.monto_mostrar}</td>
                    <td class="text-center">${badge}</td>
                    <td class="text-center">
                        <button class="btn btn-sm btn-info text-white me-1 rounded-pill" onclick="editarVale(${v.id})" title="Editar"><i class="bi bi-pencil"></i></button>
                        <button class="btn btn-sm btn-outline-dark rounded-pill me-1" onclick="imprimirVale(${v.id})" title="Imprimir PDF"><i class="bi bi-printer"></i></button>
                        ${btnArchivar}
                        ${btnEliminar}
                    </td>
                </tr>`;
            });
            if(html === '') html = '<tr><td colspan="6" class="text-center text-muted py-4">No hay vales registrados en el sistema.</td></tr>';
            $('#tablaValesBody').html(html);
        }
    }, 'json');
}

function abrirModalVale() {
    $('#formNuevoVale')[0].reset();
    $('#vale_id').val('0'); 
    document.getElementById('vale_fecha').valueAsDate = new Date();
    $('#vale_equivalencia').html('Ingrese Tasa BCV y Monto para ver la equivalencia');
    $('#modalNuevoVale').modal('show');
}

function editarVale(id) {
    $.post('Prestamos/api_prestamos.php', { action: 'obtener', id_vale: id }, function(response) {
        try {
            let res = JSON.parse(response);
            if (res.success) {
                let v = res.data;
                $('#vale_id').val(v.id);
                $('#vale_id_empleado').val(v.id_empleado);
                $('#vale_fecha').val(v.fecha);
                $('#vale_moneda').val(v.moneda);
                $('#vale_tasa').val(v.tasa_bcv);
                $('#vale_monto').val(v.monto_original > 0 ? v.monto_original : v.monto);
                $('#vale_concepto').val(v.concepto);
                
                if (typeof calcularEquivalenteVale === 'function') calcularEquivalenteVale();
                
                $('#modalNuevoVale').modal('show');
            } else {
                Swal.fire('Error', res.msg || 'No se pudo obtener la información', 'error');
            }
        } catch(e) {
            console.error("Error al parsear el vale para editar", e);
        }
    });
}

function calcularEquivalenteVale() {
    let moneda = $('#vale_moneda').val();
    let tasa = parseFloat($('#vale_tasa').val()) || 0;
    let monto = parseFloat($('#vale_monto').val()) || 0;
    
    if(tasa > 0 && monto > 0) {
        if(moneda === 'BS') {
            let usd = monto / tasa;
            $('#vale_equivalencia').html('Monto que se descontará en la Nómina: <span class="text-danger">$' + usd.toFixed(2) + ' USD</span>');
        } else {
            let bs = monto * tasa;
            $('#vale_equivalencia').html('Equivalente entregado al trabajador: <span class="text-primary">Bs ' + bs.toFixed(2) + '</span>');
        }
    } else {
        $('#vale_equivalencia').html('Ingrese Tasa BCV y Monto para ver la equivalencia');
    }
}

$('#formNuevoVale').submit(function(e) {
    e.preventDefault();
    Swal.fire({ title: 'Procesando...', allowOutsideClick: false, didOpen: () => { Swal.showLoading(); }});
    
    $.post('Prestamos/api_prestamos.php', $(this).serialize(), function(res) {
        if(res.success) {
            $('#modalNuevoVale').modal('hide');
            cargarVales();
            Swal.fire({
                title: '¡Vale Registrado!',
                text: 'El descuento se aplicará automáticamente en la próxima nómina. ¿Deseas imprimir el recibo físico ahora?',
                icon: 'success',
                showCancelButton: true,
                confirmButtonColor: '#0B4C8C',
                confirmButtonText: '<i class="bi bi-printer"></i> Imprimir Vale',
                cancelButtonText: 'Más tarde'
            }).then((r) => {
                if(r.isConfirmed) imprimirVale(res.id_vale);
            });
        } else {
            Swal.fire('Error', res.msg, 'error');
        }
    }, 'json');
});

function archivarVale(id) { Swal.fire({ title: '¿Archivar este vale?', text: 'Desaparecerá de esta lista principal.', icon: 'info', showCancelButton: true, confirmButtonColor: '#6c757d', confirmButtonText: 'Sí, Archivar' }).then((r) => { if(r.isConfirmed) { $.post('Prestamos/api_prestamos.php', {action: 'archivar', id_cuenta: id}, function(res) { if(res.success) { cargarVales(); Swal.fire({toast:true, position:'top-end', icon:'success', title:'Vale Archivado', showConfirmButton:false, timer:1500}); } }, 'json'); } }); }
function eliminarVale(id) { Swal.fire({ title: '¿Eliminar este vale?', text: 'Se borrará el registro de la deuda.', icon: 'warning', showCancelButton: true, confirmButtonColor: '#dc3545', confirmButtonText: 'Sí, Eliminar' }).then((r) => { if(r.isConfirmed) { $.post('Prestamos/api_prestamos.php', {action: 'eliminar', id_cuenta: id}, function(res) { if(res.success) { cargarVales(); Swal.fire({toast:true, position:'top-end', icon:'success', title:'Vale Eliminado', showConfirmButton:false, timer:1500}); } }, 'json'); } }); }

function imprimirVale(id) { window.open('Prestamos/imprimir_vale.php?id=' + id, '_blank'); }