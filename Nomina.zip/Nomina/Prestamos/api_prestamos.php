<?php
session_start();
error_reporting(0); // Evita que advertencias rompan la respuesta JSON

if (function_exists('mysqli_report')) {
    mysqli_report(MYSQLI_REPORT_OFF);
}

require_once '../../conexion.php';

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'msg' => 'Sesi��n expirada']);
    exit;
}

// Intentamos agregar las columnas silenciando posibles errores si ya existen
@mysqli_query($conexion, "ALTER TABLE nomina_cuentas ADD COLUMN moneda VARCHAR(10) DEFAULT 'USD'");
@mysqli_query($conexion, "ALTER TABLE nomina_cuentas ADD COLUMN tasa_bcv DECIMAL(15,4) DEFAULT 0.00");
@mysqli_query($conexion, "ALTER TABLE nomina_cuentas ADD COLUMN monto_original DECIMAL(15,2) DEFAULT 0.00");

$action = $_POST['action'] ?? '';

// 1. LISTAR TODOS LOS PR�0�7STAMOS
if ($action === 'listar') {
    $q = mysqli_query($conexion, "
        SELECT c.*, e.nombre, e.apellido, e.cedula 
        FROM nomina_cuentas c 
        INNER JOIN nomina_empleados e ON c.id_empleado = e.id 
        WHERE c.tipo_cuenta = 'Por Cobrar' AND c.estado != 'Archivado'
        ORDER BY c.id DESC
    ");
    $data = [];
    if ($q) {
        while ($r = mysqli_fetch_assoc($q)) {
            $r['fecha_fmt'] = date('d/m/Y', strtotime($r['fecha']));
            $moneda = $r['moneda'] ?? 'USD';
            $monto_orig = floatval(($r['monto_original'] > 0) ? $r['monto_original'] : $r['monto']);
            
            $r['monto_mostrar'] = ($moneda === 'BS' ? 'Bs ' : '$') . number_format($monto_orig, 2);
            
            // Limpieza estricta de c��dula
            $r['cedula'] = "V-" . ltrim(preg_replace('/^[VEJGC]\s*-\s*/i', '', trim($r['cedula'])));
            
            $data[] = $r;
        }
    }
    echo json_encode(['success' => true, 'data' => $data]);
    exit;
}

// 2. GUARDAR O EDITAR VALE
if ($action === 'guardar') {
    $id_vale = intval($_POST['id_vale'] ?? 0);
    $id_emp = intval($_POST['id_empleado'] ?? 0);
    $concepto = mysqli_real_escape_string($conexion, trim($_POST['concepto'] ?? ''));
    $fecha = mysqli_real_escape_string($conexion, trim($_POST['fecha'] ?? ''));
    $moneda = mysqli_real_escape_string($conexion, trim($_POST['moneda'] ?? 'USD'));
    $tasa_bcv = floatval($_POST['tasa_bcv'] ?? 0);
    $monto_original = floatval($_POST['monto'] ?? 0);
    
    if ($id_emp <= 0 || $monto_original <= 0) {
        echo json_encode(['success' => false, 'msg' => 'Debe seleccionar un empleado e indicar un monto v��lido.']);
        exit;
    }

    if ($moneda === 'BS' && $tasa_bcv <= 0) {
        echo json_encode(['success' => false, 'msg' => 'Debe ingresar una Tasa BCV v��lida para pr��stamos en Bol��vares.']);
        exit;
    }

    $monto_usd = $monto_original;
    if ($moneda === 'BS' && $tasa_bcv > 0) {
        $monto_usd = round($monto_original / $tasa_bcv, 2);
    }

    if ($id_vale > 0) {
        // ACTUALIZAR (EDITAR)
        $sql = "UPDATE nomina_cuentas 
                SET id_empleado = $id_emp, 
                    monto = $monto_usd, 
                    concepto = '$concepto', 
                    fecha = '$fecha', 
                    moneda = '$moneda', 
                    tasa_bcv = $tasa_bcv, 
                    monto_original = $monto_original 
                WHERE id = $id_vale AND tipo_cuenta = 'Por Cobrar'";
    } else {
        // INSERTAR (NUEVO)
        $sql = "INSERT INTO nomina_cuentas (id_empleado, tipo_cuenta, monto, concepto, fecha, estado, moneda, tasa_bcv, monto_original) 
                VALUES ($id_emp, 'Por Cobrar', $monto_usd, '$concepto', '$fecha', 'Pendiente', '$moneda', $tasa_bcv, $monto_original)";
    }
            
    $res = mysqli_query($conexion, $sql);

    if ($res) {
        $id_generado = ($id_vale > 0) ? $id_vale : mysqli_insert_id($conexion);
        echo json_encode(['success' => true, 'id_vale' => $id_generado]);
    } else {
        // Fallback robusto por si las columnas nuevas no se crearon
        if ($id_vale == 0) {
            $sql_fallback = "INSERT INTO nomina_cuentas (id_empleado, tipo_cuenta, monto, concepto, fecha, estado) 
                             VALUES ($id_emp, 'Por Cobrar', $monto_usd, '$concepto', '$fecha', 'Pendiente')";
            if (mysqli_query($conexion, $sql_fallback)) {
                $id_generado = mysqli_insert_id($conexion);
                echo json_encode(['success' => true, 'id_vale' => $id_generado]);
                exit;
            }
        }
        echo json_encode(['success' => false, 'msg' => 'Error en base de datos al registrar.']);
    }
    exit;
}

// 3. ELIMINAR VALE
if ($action === 'eliminar') {
    $id_cuenta = intval($_POST['id_cuenta']);
    if (mysqli_query($conexion, "DELETE FROM nomina_cuentas WHERE id = $id_cuenta")) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'msg' => 'Error al eliminar']);
    }
    exit;
}

// 4. ARCHIVAR VALE
if ($action === 'archivar') {
    $id_cuenta = intval($_POST['id_cuenta']);
    if (mysqli_query($conexion, "UPDATE nomina_cuentas SET estado = 'Archivado' WHERE id = $id_cuenta")) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'msg' => 'Error al archivar']);
    }
    exit;
}

// 5. OBTENER VALE PARA EDITAR
if ($action === 'obtener') {
    $id_vale = intval($_POST['id_vale']);
    $q = mysqli_query($conexion, "SELECT * FROM nomina_cuentas WHERE id = $id_vale");
    if ($q && $r = mysqli_fetch_assoc($q)) {
        echo json_encode(['success' => true, 'data' => $r]);
    } else {
        echo json_encode(['success' => false, 'msg' => 'No se encontr�� el vale solicitado.']);
    }
    exit;
}
?>