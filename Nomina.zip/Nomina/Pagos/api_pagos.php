<?php
session_start();
error_reporting(0);

if (function_exists('mysqli_report')) {
    mysqli_report(MYSQLI_REPORT_OFF);
}

require_once '../../conexion.php';

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'msg' => 'Sesión expirada']);
    exit;
}

@mysqli_query($conexion, "CREATE TABLE IF NOT EXISTS nomina_lotes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fecha_inicio DATE NOT NULL,
    fecha_fin DATE NOT NULL,
    fecha_pago DATE NOT NULL,
    tasa_bcv DECIMAL(15,4) DEFAULT 0.00,
    total_usd DECIMAL(15,2) DEFAULT 0.00,
    total_bs DECIMAL(15,2) DEFAULT 0.00,
    estado VARCHAR(20) DEFAULT 'Pendiente',
    comprobante_foto VARCHAR(255),
    fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

// ASEGURARNOS DE QUE EXISTE LA TABLA DE ASISTENCIA ANTES DE CONSULTARLA
@mysqli_query($conexion, "CREATE TABLE IF NOT EXISTS asistencia (
  id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  id_empleado int(11) NOT NULL,
  fecha date NOT NULL,
  hora_entrada time DEFAULT NULL,
  hora_salida time DEFAULT NULL,
  estado varchar(20) DEFAULT 'Presente',
  minutos_retardo int(11) DEFAULT 0,
  fecha_registro datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

$action = $_POST['action'] ?? '';

if ($action === 'generar_previa') {
    $q_emp = mysqli_query($conexion, "SELECT * FROM nomina_empleados WHERE estado = 'Activo' ORDER BY cargo ASC, nombre ASC");
    $nomina = [];

    $f_inicio = mysqli_real_escape_string($conexion, $_POST['fecha_inicio'] ?? date('Y-m-01'));
    $f_fin = mysqli_real_escape_string($conexion, $_POST['fecha_fin'] ?? date('Y-m-t'));

    while ($emp = mysqli_fetch_assoc($q_emp)) {
        $id_emp = $emp['id'];

        $sueldo_quincena = floatval($emp['salario_base']);
        $cesta_ticket = floatval($emp['cesta_ticket']);
        $bono_ayuda = floatval($emp['bonos']);

        $total_percibir = $sueldo_quincena + $cesta_ticket + $bono_ayuda;
        $salario_diario = $total_percibir > 0 ? $total_percibir / 15 : 0;
        $valor_hora = $salario_diario > 0 ? $salario_diario / 8 : 0;

        $q_cobrar = mysqli_query($conexion, "SELECT SUM(monto) as total_deuda FROM nomina_cuentas WHERE id_empleado = $id_emp AND tipo_cuenta = 'Por Cobrar' AND estado = 'Pendiente'");
        $r_cobrar = mysqli_fetch_assoc($q_cobrar);
        $vales = floatval($r_cobrar['total_deuda'] ?? 0);

        $q_pagar = mysqli_query($conexion, "SELECT SUM(monto) as total_extra FROM nomina_cuentas WHERE id_empleado = $id_emp AND tipo_cuenta = 'Por Pagar' AND estado = 'Pendiente'");
        $r_pagar = mysqli_fetch_assoc($q_pagar);
        $pago_pendiente = floatval($r_pagar['total_extra'] ?? 0);

        // --- CÁLCULO DE FALTAS Y RETARDOS DESDE EL MÓDULO DE ASISTENCIA ---
        $q_faltas = mysqli_query($conexion, "SELECT COUNT(id) as dias_faltados FROM asistencia WHERE id_empleado = $id_emp AND estado = 'Falta' AND fecha BETWEEN '$f_inicio' AND '$f_fin'");
        $r_faltas = mysqli_fetch_assoc($q_faltas);
        $dias_falta_auto = floatval($r_faltas['dias_faltados'] ?? 0);

        $q_retardos = mysqli_query($conexion, "SELECT SUM(minutos_retardo) as total_minutos FROM asistencia WHERE id_empleado = $id_emp AND estado = 'Presente' AND fecha BETWEEN '$f_inicio' AND '$f_fin'");
        $r_retardos = mysqli_fetch_assoc($q_retardos);
        $minutos_retardo = floatval($r_retardos['total_minutos'] ?? 0);
        $horas_falta_auto = round(($minutos_retardo / 60), 1); 
        // -------------------------------------------------------------------

        $ced_limpia = "V-" . ltrim(preg_replace('/^V\s*-\s*/i', '', trim($emp['cedula'])));

        $nomina[] = [
            'id_empleado' => $id_emp, 
            'cedula' => $ced_limpia, 
            'nombre_completo' => mb_strtoupper($emp['nombre'] . ' ' . $emp['apellido'], 'UTF-8'),
            'cargo' => mb_strtoupper($emp['cargo'] ?: 'SIN CARGO', 'UTF-8'), 

            'sueldo_quincena' => $sueldo_quincena, 
            'cesta_ticket' => $cesta_ticket,
            'bono_ayuda' => $bono_ayuda, 

            'total_percibir' => $total_percibir, 
            'salario_diario' => $salario_diario, 
            'valor_hora' => $valor_hora,

            'qty_sabados' => 0.00,
            'valor_sabados' => 0.00,
            'qty_he_diurna' => 0.00,
            'valor_he_diurna' => 0.00,
            'qty_he_noct' => 0.00,
            'valor_he_noct' => 0.00,
            'bono_prod' => 0.00,
            'pago_pendiente' => $pago_pendiente,

            'total_asignaciones' => $total_percibir + $pago_pendiente,

            'dias_falta' => $dias_falta_auto, 
            'horas_falta' => $horas_falta_auto, 
            'monto_descuento_dias' => 0.00, 
            'monto_descuento_horas' => 0.00,

            'vales' => $vales, 
            'total_deducciones' => $vales, 
            'total_pagar' => ($total_percibir + $pago_pendiente) - $vales > 0 ? ($total_percibir + $pago_pendiente) - $vales : 0
        ];
    }
    echo json_encode(['success' => true, 'data' => $nomina]);
    exit;
}

if ($action === 'procesar_nomina') {
    $id_lote_edit = intval($_POST['id_lote_edit'] ?? 0);
    $fecha_inicio = mysqli_real_escape_string($conexion, $_POST['fecha_inicio'] ?? '');
    $fecha_fin = mysqli_real_escape_string($conexion, $_POST['fecha_fin'] ?? '');
    $fecha_pago = mysqli_real_escape_string($conexion, $_POST['fecha_pago'] ?? '');
    $tasa_bcv = floatval($_POST['tasa_bcv'] ?? 0);
    $datos_nomina = json_decode($_POST['datos_nomina'] ?? '[]', true);

    if (!is_array($datos_nomina) || empty($datos_nomina)) {
        echo json_encode(['success' => false, 'msg' => 'No se recibieron datos válidos de la nómina.']);
        exit;
    }

    mysqli_begin_transaction($conexion);
    try {
        $total_usd_lote = 0;
        foreach ($datos_nomina as $row) { $total_usd_lote += floatval($row['total_pagar']); }
        $total_bs_lote = $total_usd_lote * $tasa_bcv;

        if ($id_lote_edit > 0) {
            $sql_lote = "UPDATE nomina_lotes SET fecha_inicio='$fecha_inicio', fecha_fin='$fecha_fin', fecha_pago='$fecha_pago', tasa_bcv=$tasa_bcv, total_usd=$total_usd_lote, total_bs=$total_bs_lote WHERE id=$id_lote_edit";
            mysqli_query($conexion, $sql_lote);
            $id_lote = $id_lote_edit;
        } else {
            $sql_lote = "INSERT INTO nomina_lotes (fecha_inicio, fecha_fin, fecha_pago, tasa_bcv, total_usd, total_bs, estado) 
                         VALUES ('$fecha_inicio', '$fecha_fin', '$fecha_pago', $tasa_bcv, $total_usd_lote, $total_bs_lote, 'Pendiente')";
            mysqli_query($conexion, $sql_lote);
            $id_lote = mysqli_insert_id($conexion);
        }

        foreach ($datos_nomina as $row) {
            $id_emp = intval($row['id_empleado']);
            $sueldo_quincena = floatval($row['sueldo_quincena']);
            $cesta_ticket = floatval($row['cesta_ticket']);
            $bono_ayuda = floatval($row['bono_ayuda']);
            $total_percibir = floatval($row['total_percibir']);
            $salario_diario = floatval($row['salario_diario']);
            $valor_hora = floatval($row['valor_hora']);

            $qty_sabados = floatval($row['qty_sabados']);
            $valor_sabados = floatval($row['valor_sabados']);
            $qty_he_diurna = floatval($row['qty_he_diurna']);
            $valor_he_diurna = floatval($row['valor_he_diurna']);
            $qty_he_noct = floatval($row['qty_he_noct']);
            $valor_he_noct = floatval($row['valor_he_noct']);
            $bono_prod = floatval($row['bono_prod']);
            $pago_pendiente = floatval($row['pago_pendiente']);
            $total_asignaciones = floatval($row['total_asignaciones']);

            $dias_falta = floatval($row['dias_falta']);
            $horas_falta = floatval($row['horas_falta']);
            $monto_descuento_dias = floatval($row['monto_descuento_dias']);
            $monto_descuento_horas = floatval($row['monto_descuento_horas']);
            $vales = floatval($row['vales']);
            $total_deducciones = floatval($row['total_deducciones']);

            $total_pagar = floatval($row['total_pagar']);
            $pago_bs = $total_pagar * $tasa_bcv;

            if ($id_lote_edit > 0) {
                $q_check = mysqli_query($conexion, "SELECT id FROM nomina_pagos WHERE id_lote=$id_lote AND id_empleado=$id_emp");
                if (mysqli_num_rows($q_check) > 0) {
                    $sql_pago = "UPDATE nomina_pagos SET 
                        fecha_inicio_periodo='$fecha_inicio', fecha_fin_periodo='$fecha_fin', fecha_pago='$fecha_pago', 
                        sueldo_quincena=$sueldo_quincena, cesta_ticket=$cesta_ticket, bono_ayuda=$bono_ayuda, total_percibir=$total_percibir, 
                        salario_diario=$salario_diario, valor_hora=$valor_hora, qty_sabados=$qty_sabados, valor_sabados=$valor_sabados, 
                        qty_he_diurna=$qty_he_diurna, valor_he_diurna=$valor_he_diurna, qty_he_noct=$qty_he_noct, valor_he_noct=$valor_he_noct, 
                        bono_prod=$bono_prod, pago_pendiente=$pago_pendiente, total_asignaciones=$total_asignaciones, 
                        dias_falta=$dias_falta, horas_falta=$horas_falta, monto_descuento_dias=$monto_descuento_dias, monto_descuento_horas=$monto_descuento_horas, 
                        vales=$vales, total_deducciones=$total_deducciones, total_pagado=$total_pagar, pago_bs=$pago_bs, tasa_bcv=$tasa_bcv 
                        WHERE id_lote=$id_lote AND id_empleado=$id_emp";
                } else {
                    $sql_pago = "INSERT INTO nomina_pagos (id_lote, id_empleado, fecha_inicio_periodo, fecha_fin_periodo, fecha_pago, sueldo_quincena, cesta_ticket, bono_ayuda, total_percibir, salario_diario, valor_hora, qty_sabados, valor_sabados, qty_he_diurna, valor_he_diurna, qty_he_noct, valor_he_noct, bono_prod, pago_pendiente, total_asignaciones, dias_falta, horas_falta, monto_descuento_dias, monto_descuento_horas, vales, total_deducciones, total_pagado, pago_bs, tasa_bcv, estado) VALUES ($id_lote, $id_emp, '$fecha_inicio', '$fecha_fin', '$fecha_pago', $sueldo_quincena, $cesta_ticket, $bono_ayuda, $total_percibir, $salario_diario, $valor_hora, $qty_sabados, $valor_sabados, $qty_he_diurna, $valor_he_diurna, $qty_he_noct, $valor_he_noct, $bono_prod, $pago_pendiente, $total_asignaciones, $dias_falta, $horas_falta, $monto_descuento_dias, $monto_descuento_horas, $vales, $total_deducciones, $total_pagar, $pago_bs, $tasa_bcv, 'Pagado')";
                }
            } else {
                $sql_pago = "INSERT INTO nomina_pagos (id_lote, id_empleado, fecha_inicio_periodo, fecha_fin_periodo, fecha_pago, sueldo_quincena, cesta_ticket, bono_ayuda, total_percibir, salario_diario, valor_hora, qty_sabados, valor_sabados, qty_he_diurna, valor_he_diurna, qty_he_noct, valor_he_noct, bono_prod, pago_pendiente, total_asignaciones, dias_falta, horas_falta, monto_descuento_dias, monto_descuento_horas, vales, total_deducciones, total_pagado, pago_bs, tasa_bcv, estado) VALUES ($id_lote, $id_emp, '$fecha_inicio', '$fecha_fin', '$fecha_pago', $sueldo_quincena, $cesta_ticket, $bono_ayuda, $total_percibir, $salario_diario, $valor_hora, $qty_sabados, $valor_sabados, $qty_he_diurna, $valor_he_diurna, $qty_he_noct, $valor_he_noct, $bono_prod, $pago_pendiente, $total_asignaciones, $dias_falta, $horas_falta, $monto_descuento_dias, $monto_descuento_horas, $vales, $total_deducciones, $total_pagar, $pago_bs, $tasa_bcv, 'Pagado')";
            }
            mysqli_query($conexion, $sql_pago);
            mysqli_query($conexion, "UPDATE nomina_cuentas SET estado = 'Procesado' WHERE id_empleado = $id_emp AND estado = 'Pendiente'");
        }
        mysqli_commit($conexion);
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        mysqli_rollback($conexion); 
        echo json_encode(['success' => false, 'msg' => 'Error al guardar: ' . $e->getMessage()]);
    }
    exit;
}

if ($action === 'listar_historial_lotes') {
    $q = mysqli_query($conexion, "SELECT * FROM nomina_lotes ORDER BY id DESC");
    $data = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $r['fecha_pago_fmt'] = date('d/m/Y', strtotime($r['fecha_pago']));
        $r['periodo_fmt'] = date('d/m/Y', strtotime($r['fecha_inicio'])) . ' al ' . date('d/m/Y', strtotime($r['fecha_fin']));
        $data[] = $r;
    }
    echo json_encode(['success' => true, 'data' => $data]);
    exit;
}

if ($action === 'cargar_lote_editar') {
    $id_lote = intval($_POST['id_lote']);
    $q_lote = mysqli_query($conexion, "SELECT * FROM nomina_lotes WHERE id = $id_lote");
    $lote = mysqli_fetch_assoc($q_lote);

    $q_pagos = mysqli_query($conexion, "
        SELECT p.*, e.nombre, e.apellido, e.cedula, e.cargo 
        FROM nomina_pagos p 
        INNER JOIN nomina_empleados e ON p.id_empleado = e.id 
        WHERE p.id_lote = $id_lote 
        ORDER BY e.cargo ASC, e.nombre ASC
    ");
    $nomina = [];
    while ($p = mysqli_fetch_assoc($q_pagos)) {
        $ced_limpia = "V-" . ltrim(preg_replace('/^V\s*-\s*/i', '', trim($p['cedula'])));
        $nomina[] = [
            'id_empleado' => $p['id_empleado'],
            'cedula' => $ced_limpia,
            'nombre_completo' => mb_strtoupper($p['nombre'] . ' ' . $p['apellido'], 'UTF-8'),
            'cargo' => mb_strtoupper($p['cargo'] ?: 'SIN CARGO', 'UTF-8'),
            'sueldo_quincena' => floatval($p['sueldo_quincena']),
            'cesta_ticket' => floatval($p['cesta_ticket']),
            'bono_ayuda' => floatval($p['bono_ayuda']),
            'total_percibir' => floatval($p['total_percibir']),
            'salario_diario' => floatval($p['salario_diario']),
            'valor_hora' => floatval($p['valor_hora']),
            'qty_sabados' => floatval($p['qty_sabados']),
            'valor_sabados' => floatval($p['valor_sabados']),
            'qty_he_diurna' => floatval($p['qty_he_diurna']),
            'valor_he_diurna' => floatval($p['valor_he_diurna']),
            'qty_he_noct' => floatval($p['qty_he_noct']),
            'valor_he_noct' => floatval($p['valor_he_noct']),
            'bono_prod' => floatval($p['bono_prod']),
            'pago_pendiente' => floatval($p['pago_pendiente']),
            'total_asignaciones' => floatval($p['total_asignaciones']),
            'dias_falta' => floatval($p['dias_falta']),
            'horas_falta' => floatval($p['horas_falta']),
            'monto_descuento_dias' => floatval($p['monto_descuento_dias']),
            'monto_descuento_horas' => floatval($p['monto_descuento_horas']),
            'vales' => floatval($p['vales']),
            'total_deducciones' => floatval($p['total_deducciones']),
            'total_pagar' => floatval($p['total_pagado'])
        ];
    }
    echo json_encode(['success' => true, 'lote' => $lote, 'data' => $nomina]);
    exit;
}

if ($action === 'listar_detalles_lote') {
    $id_lote = intval($_POST['id_lote']);
    $q = mysqli_query($conexion, "SELECT p.*, e.nombre, e.apellido, e.cedula, e.cargo FROM nomina_pagos p INNER JOIN nomina_empleados e ON p.id_empleado = e.id WHERE p.id_lote = $id_lote ORDER BY e.cargo ASC, e.nombre ASC");
    $data = [];
    while ($r = mysqli_fetch_assoc($q)) {
        $r['cedula'] = "V-" . ltrim(preg_replace('/^V\s*-\s*/i', '', trim($r['cedula'])));
        $data[] = $r;
    }
    echo json_encode(['success' => true, 'data' => $data]);
    exit;
}

if ($action === 'subir_comprobante') {
    $id_pago = intval($_POST['id_pago']);
    $q_exist = mysqli_query($conexion, "SELECT comprobante_foto FROM nomina_pagos WHERE id=$id_pago");
    $row_exist = mysqli_fetch_assoc($q_exist);
    $existentes = (!empty($row_exist['comprobante_foto'])) ? explode(',', $row_exist['comprobante_foto']) : [];

    $nuevos_archivos = [];
    $ruta_directorio = '../../uploads';
    if (!is_dir($ruta_directorio)) { mkdir($ruta_directorio, 0777, true); }

    if (isset($_FILES['comprobantes'])) {
        $total_files = count($_FILES['comprobantes']['name']);
        for($i = 0; $i < $total_files; $i++) {
            if ($_FILES['comprobantes']['error'][$i] == 0) {
                $ext = pathinfo($_FILES['comprobantes']['name'][$i], PATHINFO_EXTENSION);
                $filename = 'aval_empleado_' . $id_pago . '_' . time() . '_' . $i . '.' . $ext;
                if (move_uploaded_file($_FILES['comprobantes']['tmp_name'][$i], $ruta_directorio . '/' . $filename)) {
                    $nuevos_archivos[] = $filename;
                }
            }
        }
    }

    if (!empty($nuevos_archivos)) {
        $todos_archivos = array_merge($existentes, $nuevos_archivos);
        $archivos_str = implode(',', $todos_archivos);
        mysqli_query($conexion, "UPDATE nomina_pagos SET comprobante_foto='$archivos_str' WHERE id=$id_pago");
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'msg' => 'No se subió ningún archivo.']);
    }
    exit;
}

if ($action === 'limpiar_comprobantes') {
    $id_pago = intval($_POST['id_pago']);
    if(mysqli_query($conexion, "UPDATE nomina_pagos SET comprobante_foto=NULL WHERE id=$id_pago")) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'msg' => 'Error al borrar.']);
    }
    exit;
}

if ($action === 'finalizar_lote') {
    $id_lote = intval($_POST['id_lote']);
    if (mysqli_query($conexion, "UPDATE nomina_lotes SET estado = 'Finalizada' WHERE id = $id_lote")) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'msg' => mysqli_error($conexion)]);
    }
    exit;
}

if ($action === 'eliminar_lote') {
    $id_lote = intval($_POST['id_lote']);
    mysqli_query($conexion, "DELETE FROM nomina_pagos WHERE id_lote = $id_lote");
    if (mysqli_query($conexion, "DELETE FROM nomina_lotes WHERE id = $id_lote")) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'msg' => mysqli_error($conexion)]);
    }
    exit;
}
?>