<?php
session_start();
error_reporting(0);

require_once '../../conexion.php';

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'msg' => 'Sesión expirada']);
    exit;
}

$action = $_POST['action'] ?? '';

if ($action === 'listar_dia') {
    $fecha = mysqli_real_escape_string($conexion, $_POST['fecha']);
    
    // Lista a todos los empleados "Activos", y cruza con la tabla de asistencia para esa fecha
    $sql = "SELECT e.id as id_empleado, e.nombre, e.apellido, 
                   a.id as id_asistencia, a.hora_entrada, a.hora_salida, a.estado, a.minutos_retardo 
            FROM nomina_empleados e 
            LEFT JOIN asistencia a ON e.id = a.id_empleado AND a.fecha = '$fecha'
            WHERE e.estado = 'Activo'
            ORDER BY e.nombre ASC";
            
    $q = mysqli_query($conexion, $sql);
    $data = [];
    while ($r = mysqli_fetch_assoc($q)) {
        // Si no hay registro de ese día en la BD, lo forzamos a Presente visualmente para que se llene rápido
        if (empty($r['estado'])) {
            $r['estado'] = 'Presente';
            $r['hora_entrada'] = '';
            $r['hora_salida'] = '';
            $r['minutos_retardo'] = 0;
        }
        $data[] = $r;
    }
    echo json_encode(['success' => true, 'data' => $data]);
    exit;
}

if ($action === 'guardar_lote') {
    $fecha = mysqli_real_escape_string($conexion, $_POST['fecha']);
    $registros = json_decode($_POST['registros'], true);

    mysqli_begin_transaction($conexion);
    try {
        foreach($registros as $reg) {
            $id_emp = intval($reg['id_empleado']);
            $estado = mysqli_real_escape_string($conexion, $reg['estado']);
            
            $entrada = empty($reg['hora_entrada']) ? "NULL" : "'" . mysqli_real_escape_string($conexion, $reg['hora_entrada']) . "'";
            $salida = empty($reg['hora_salida']) ? "NULL" : "'" . mysqli_real_escape_string($conexion, $reg['hora_salida']) . "'";
            $retardo = intval($reg['minutos_retardo']);

            $q_existe = mysqli_query($conexion, "SELECT id FROM asistencia WHERE id_empleado = $id_emp AND fecha = '$fecha'");
            
            if (mysqli_num_rows($q_existe) > 0) {
                // Si existe el registro y el empleado lo marcan como "Falta", borramos las horas de entrada y salida
                if ($estado !== 'Presente') {
                    $entrada = "NULL";
                    $salida = "NULL";
                    $retardo = 0;
                }
                
                $r = mysqli_fetch_assoc($q_existe);
                $id_reg = $r['id'];
                $sql = "UPDATE asistencia SET 
                        hora_entrada = $entrada, 
                        hora_salida = $salida, 
                        estado = '$estado', 
                        minutos_retardo = $retardo 
                        WHERE id = $id_reg";
            } else {
                // Si es un día perdido y no tenía hora, no es necesario insertarlo con horas
                if ($estado !== 'Presente') {
                    $entrada = "NULL";
                    $salida = "NULL";
                    $retardo = 0;
                }
                
                $sql = "INSERT INTO asistencia (id_empleado, fecha, hora_entrada, hora_salida, estado, minutos_retardo) 
                        VALUES ($id_emp, '$fecha', $entrada, $salida, '$estado', $retardo)";
            }
            mysqli_query($conexion, $sql);
        }
        mysqli_commit($conexion);
        echo json_encode(['success' => true]);
    } catch(Exception $e) {
        mysqli_rollback($conexion);
        echo json_encode(['success' => false, 'msg' => $e->getMessage()]);
    }
    exit;
}
?>