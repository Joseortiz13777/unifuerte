<div id="vistaOrdenes" class="vista-spa" style="display: none;">
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-2">
        <div class="d-flex align-items-center gap-3">
            <h3 class="fw-bold m-0" style="color: #0B4C8C;"><i class="bi bi-clipboard2-pulse me-2"></i> Órdenes de Fábrica</h3>
            <?php if(tieneVector(54) || $rol_actual === 'master'): ?>
            <div class="form-check form-switch mt-1">
                <input class="form-check-input" type="checkbox" id="switch_ver_todas_ordenes" checked onchange="if(typeof window.cargarListaOrdenes === 'function') window.cargarListaOrdenes()">
                <label class="form-check-label small fw-bold text-muted" for="switch_ver_todas_ordenes">Ver de Todos los Asesores</label>
            </div>
            <?php endif; ?>
        </div>
        <?php if(tieneVector(11)): ?>
        <button class="btn text-white fw-bold shadow-sm" style="background-color: #FF7518;" onclick="abrirModalNuevaOrden()">
            <i class="bi bi-plus-lg me-1"></i> Generar Orden
        </button>
        <?php endif; ?>
    </div>
    <div class="row g-2 mb-3">
        <div class="col-md-8 col-lg-6">
            <label for="buscarOrdenesFabrica" class="form-label small fw-bold text-muted mb-1">Buscar órdenes</label>
            <div class="input-group">
                <input type="search" id="buscarOrdenesFabrica" class="form-control" placeholder="Cliente, orden o números de cotización">
                <button type="button" class="btn btn-primary fw-bold" id="btnFiltrarOrdenesFabrica"><i class="bi bi-search me-1"></i>Filtrar</button>
            </div>
            <small class="text-muted">Para buscar por cotización u orden, escribe sus números (ej.: 00211).</small>
        </div>
    </div>
    <div class="bg-white p-3 rounded shadow-sm border table-responsive">
        <table class="table table-hover align-middle">
            <thead class="table-light"><tr><th>Nro. Orden</th><th>Cotización</th><th>Emisión</th><th>Entrega</th><th>Cliente</th><th class="text-center">Acciones</th></tr></thead>
            <tbody id="tablaOrdenesBody"><tr><td colspan="6" class="text-center text-muted">Cargando órdenes...</td></tr></tbody>
        </table>
    </div>
</div>

<?php if(tieneVector(11)): ?>
<div class="modal fade" id="modalNuevaOrden" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-xl modal-dialog-scrollable">
        <div class="modal-content border-0 shadow">
            <div class="modal-header text-white" style="background-color: #0B4C8C;">
                <h5 class="modal-title fw-bold"><i class="bi bi-scissors"></i> Nueva Orden de Corte / Confección</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body bg-light">
                <form id="formGuardarOrden" enctype="multipart/form-data">
                    <input type="hidden" id="id_cliente_orden">
                    
                    <div class="row g-3 mb-3 bg-white p-3 rounded border">
                        <div class="col-md-6">
                            <label class="small fw-bold text-muted">Cotización Base (Enviada a Logística)</label>
                            <select id="select_cotizacion_orden" class="form-select border-primary fw-bold" style="color:#0B4C8C;" onchange="cargarDatosCotizacionOrden(this.value)"><option value="">Cargando...</option></select>
                        </div>
                        <div class="col-md-3">
                            <label class="small fw-bold text-muted">Fecha de Entrega Estimada</label>
                            <input type="date" id="orden_fecha_entrega" class="form-control">
                        </div>
                        <div class="col-md-3 d-flex flex-column justify-content-end gap-2">
                            <div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="orden_express"><label class="form-check-label small fw-bold text-danger" for="orden_express">Pedido Express</label></div>
                            <div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="orden_parciales"><label class="form-check-label small fw-bold" for="orden_parciales">Acepta Entregas Parciales</label></div>
                        </div>
                    </div>

                    <div class="bg-white p-3 rounded border mb-3">
                        <div class="row">
                            <div class="col-md-8">
                                <h6 class="fw-bold text-dark mb-3"><i class="bi bi-list-check text-primary"></i> 1. Asignación de Telas por Prenda Física (Heredadas de Cotización)</h6>
                                <div class="table-responsive">
                                    <table class="table table-sm align-middle">
                                        <thead class="table-light"><tr><th>Prenda Física</th><th class="text-center" style="width:70px;">Cant</th><th>Muestra Textil (Tela)</th></tr></thead>
                                        <tbody id="tbody_prendas_orden"><tr><td colspan="3" class="text-center text-muted">Seleccione una cotización para cargar las prendas.</td></tr></tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <h6 class="fw-bold text-dark mb-3"><i class="bi bi-image text-primary"></i> 2. Foto Referencial del Diseño</h6>
                                <input type="file" id="orden_foto_referencial" name="orden_foto[]" class="form-control form-control-sm border-primary" accept="image/*,application/pdf" multiple>
                                <small class="text-muted">Adjunte imágenes adicionales si las hay (las de la cotización se incluyen automáticamente).</small>
                                <div id="fotos_previas_container" class="mt-2"></div>
                            </div>
                        </div>
                    </div>

                    <div class="bg-white p-3 rounded border mb-3" id="seccion_artes_posiciones" style="display: none;">
                        <h6 class="fw-bold text-dark mb-3"><i class="bi bi-geo-alt-fill text-danger"></i> 3. Posiciones de Arte en las Prendas</h6>
                        <div class="table-responsive">
                            <table class="table table-sm align-middle">
                                <thead class="table-light"><tr><th>Elemento de Arte</th><th class="text-center" style="width:60px;">Cant</th><th>Prenda de Destino</th><th>Ubicación Específica</th></tr></thead>
                                <tbody id="tbody_artes_orden"></tbody>
                            </table>
                        </div>
                    </div>

                    <div class="bg-white p-3 rounded border mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h6 class="fw-bold text-dark m-0"><i class="bi bi-person-lines-fill text-danger"></i> 4. Tallas, Cantidades, Telas y Nombres (Cargados desde la Cotización)</h6>
                            <div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="check_asignar_tallas" checked style="transform: scale(1.3);"></div>
                        </div>
                        
                        <div id="seccion_asignacion_tallas">
                            <div class="alert alert-warning py-2 small fw-bold d-flex flex-wrap justify-content-between align-items-center gap-2" style="background-color: #fff3cd;">
                                <span><i class="bi bi-info-circle"></i> Las especificaciones de la cotización han sido cargadas automáticamente. Puedes revisarlas o ajustarlas antes de emitir.</span>
                                <button type="button" class="btn btn-sm btn-primary fw-bold" onclick="autogenerarFilasTallas()"><i class="bi bi-magic"></i> Re-cargar desde Cotización</button>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-bordered table-sm align-middle" style="font-size: 0.85rem;">
                                    <thead class="table-light text-center align-middle">
                                        <tr><th>Prenda</th><th style="width:70px;">Cant.</th><th>Nombre (Opcional)</th><th>Género</th><th>Talla</th><th>Tela Asignada</th><th>Observación</th><th></th></tr>
                                    </thead>
                                    <tbody id="tbody_medidas_personales"></tbody>
                                </table>
                            </div>
                            <button type="button" class="btn btn-sm btn-secondary fw-bold mt-2" onclick="agregarFilaMedida()">+ Añadir Fila Manual</button>
                        </div>
                    </div>

                    <div class="bg-white p-3 rounded border mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h6 class="fw-bold text-dark m-0"><i class="bi bi-rulers text-primary"></i> 5. Medidas Exactas de Sastrería</h6>
                            <div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="check_sastreria" style="transform: scale(1.3);"></div>
                        </div>
                        
                        <div id="seccion_sastreria" style="display: none;">
                            <div class="alert alert-info py-2 small fw-bold d-flex flex-wrap justify-content-between align-items-center gap-2">
                                <span><i class="bi bi-info-circle"></i> Si agregaste medidas personales en la regla azul ya aparecen aquí, o puedes autocargar desde los nombres del Paso 4.</span>
                                <button type="button" class="btn btn-sm btn-info text-white fw-bold" onclick="autogenerarSastreria()"><i class="bi bi-arrow-down-circle-fill"></i> Autocargar Nombres Asignados</button>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-bordered table-sm align-middle" style="font-size: 0.8rem; min-width: 1200px;">
                                    <thead class="table-light text-center align-middle">
                                        <tr>
                                            <th rowspan="2">Prenda</th>
                                            <th rowspan="2">Nombre Exacto</th>
                                            <th colspan="6" style="background-color: #e6f0fa;">Medidas Superiores</th>
                                            <th colspan="5" style="background-color: #fce4d6; border-left: 2px solid #FF7518;">Medidas Pantalón</th>
                                            <th rowspan="2"></th>
                                        </tr>
                                        <tr style="font-size: 0.75rem;">
                                            <th>Hombro</th><th>Busto / Tórax</th><th>Cintura</th><th>Cadera</th><th>Largo Camisa</th><th>Largo Brazo</th>
                                            <th style="border-left: 2px solid #FF7518;">Largo Pantalón</th><th>Tiro Total</th><th>Ancho Muslo</th><th>Ancho Rodilla</th><th>Ancho Talón</th>
                                        </tr>
                                    </thead>
                                    <tbody id="tbody_sastreria"></tbody>
                                </table>
                            </div>
                            <button type="button" class="btn btn-sm btn-outline-info fw-bold mt-2" onclick="agregarFilaSastreria()">+ Añadir Fila Manual</button>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="small fw-bold text-muted">Observaciones Globales de Producción (Heredadas de Cotización)</label>
                        <textarea id="orden_notas_globales" class="form-control" rows="2" placeholder="Ej: Todas las camisas llevan doble costura..."></textarea>
                    </div>

                    <div class="text-end border-top pt-3">
                        <button type="button" class="btn btn-outline-secondary me-2 fw-bold" data-bs-dismiss="modal">Cancelar</button>
                        <button type="button" class="btn fw-bold text-white shadow" style="background-color: #0B4C8C;" id="btnGuardarOrdenFinal" disabled><i class="bi bi-save"></i> Emitir Orden de Fábrica</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- ========================================================================================= -->
<!-- MODAL: EDITAR / ALTERAR ORDEN DE FÁBRICA (Vector 53 o Master) -->
<!-- ========================================================================================= -->
<?php if(tieneVector(53) || $rol_actual === 'master'): ?>
<div class="modal fade" id="modalEditarOrden" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-xl modal-dialog-scrollable">
        <div class="modal-content border-0 shadow">
            <div class="modal-header text-white" style="background-color: #dc3545;">
                <h5 class="modal-title fw-bold"><i class="bi bi-tools"></i> Editar / Alterar Orden de Fábrica</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body bg-light">
                <form id="formEditarOrden" enctype="multipart/form-data">
                    <input type="hidden" id="edit_id_orden" name="id_orden">
                    <input type="hidden" id="edit_id_cotizacion" name="id_cotizacion">
                    
                    <div class="alert alert-warning py-2 small fw-bold">
                        <i class="bi bi-exclamation-triangle-fill"></i> Atención: Estás editando una orden ya generada. Los cambios se reflejarán de inmediato en el PDF de la orden y en Envíos.
                    </div>

                    <div class="row g-3 mb-3 bg-white p-3 rounded border">
                        <div class="col-md-6">
                            <label class="small fw-bold text-muted">Cliente / Cotización Base</label>
                            <input type="text" id="edit_orden_cliente" class="form-control bg-light fw-bold text-primary" readonly>
                        </div>
                        <div class="col-md-3">
                            <label class="small fw-bold text-muted">Fecha de Entrega</label>
                            <input type="date" id="edit_orden_fecha_entrega" name="fecha_entrega" class="form-control" required>
                        </div>
                        <div class="col-md-3 d-flex flex-column justify-content-end gap-2">
                            <div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="edit_orden_express" name="es_express" value="1"><label class="form-check-label small fw-bold text-danger" for="edit_orden_express">Pedido Express</label></div>
                            <div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="edit_orden_parciales" name="acepta_parciales" value="1"><label class="form-check-label small fw-bold" for="edit_orden_parciales">Entregas Parciales</label></div>
                        </div>
                    </div>

                    <!-- 1. PRENDAS FÍSICAS Y TELAS -->
                    <div class="bg-white p-3 rounded border mb-3">
                        <div class="row">
                            <div class="col-md-8">
                                <h6 class="fw-bold text-dark mb-3"><i class="bi bi-list-check text-primary"></i> 1. Ajustar Telas por Prenda</h6>
                                <div class="table-responsive">
                                    <table class="table table-sm align-middle">
                                        <thead class="table-light"><tr><th>Prenda Física</th><th class="text-center" style="width:60px;">Cant</th><th>Muestra Textil (Tela)</th></tr></thead>
                                        <tbody id="edit_tbody_prendas_orden"></tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <h6 class="fw-bold text-dark mb-3"><i class="bi bi-image text-primary"></i> 2. Añadir Más Fotos (Opcional)</h6>
                                <input type="file" name="orden_foto_extra[]" class="form-control form-control-sm border-primary" accept="image/*,application/pdf" multiple>
                                <small class="text-muted">Las fotos anteriores se mantendrán almacenadas.</small>
                                <div id="edit_fotos_previas_container" class="mt-2 d-flex flex-wrap gap-2"></div>
                            </div>
                        </div>
                    </div>

                    <!-- 3. ARTES -->
                    <div class="bg-white p-3 rounded border mb-3" id="edit_seccion_artes_posiciones" style="display: none;">
                        <h6 class="fw-bold text-dark mb-3"><i class="bi bi-geo-alt-fill text-danger"></i> 3. Posiciones de Arte en las Prendas</h6>
                        <div class="table-responsive">
                            <table class="table table-sm align-middle">
                                <thead class="table-light"><tr><th>Elemento de Arte</th><th class="text-center" style="width:60px;">Cant</th><th>Prenda de Destino</th><th>Ubicación Específica</th></tr></thead>
                                <tbody id="edit_tbody_artes_orden"></tbody>
                            </table>
                        </div>
                    </div>

                    <!-- 4. TALLAS -->
                    <div class="bg-white p-3 rounded border mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h6 class="fw-bold text-dark m-0"><i class="bi bi-person-lines-fill text-danger"></i> 4. Alterar Tallas y Nombres</h6>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-bordered table-sm align-middle" style="font-size: 0.85rem;">
                                <thead class="table-light text-center align-middle">
                                    <tr><th>Prenda</th><th style="width:70px;">Cant.</th><th>Nombre</th><th>Género</th><th>Talla</th><th>Tela Asignada</th><th>Observación</th><th></th></tr>
                                </thead>
                                <tbody id="edit_tbody_medidas_personales"></tbody>
                            </table>
                        </div>
                        <button type="button" class="btn btn-sm btn-secondary fw-bold mt-2" onclick="agregarFilaMedidaEdit()">+ Añadir Fila Manual</button>
                    </div>

                    <!-- 5. SASTRERIA -->
                    <div class="bg-white p-3 rounded border mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h6 class="fw-bold text-dark m-0"><i class="bi bi-rulers text-primary"></i> 5. Alterar Medidas de Sastrería</h6>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-bordered table-sm align-middle" style="font-size: 0.8rem; min-width: 1200px;">
                                <thead class="table-light text-center align-middle">
                                    <tr>
                                        <th rowspan="2">Prenda</th><th rowspan="2">Nombre Exacto</th>
                                        <th colspan="6" style="background-color: #e6f0fa;">Medidas Superiores</th>
                                        <th colspan="5" style="background-color: #fce4d6; border-left: 2px solid #FF7518;">Medidas Pantalón</th>
                                        <th rowspan="2"></th>
                                    </tr>
                                    <tr style="font-size: 0.75rem;">
                                        <th>Hombro</th><th>Busto / Tórax</th><th>Cintura</th><th>Cadera</th><th>Largo Camisa</th><th>Largo Brazo</th>
                                        <th style="border-left: 2px solid #FF7518;">Largo Pantalón</th><th>Tiro Total</th><th>Ancho Muslo</th><th>Ancho Rodilla</th><th>Ancho Talón</th>
                                    </tr>
                                </thead>
                                <tbody id="edit_tbody_sastreria"></tbody>
                            </table>
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-info fw-bold mt-2" onclick="agregarFilaSastreriaEdit()">+ Añadir Fila Sastrería</button>
                    </div>
                    
                    <div class="mb-3">
                        <label class="small fw-bold text-muted">Observaciones Globales de Producción</label>
                        <textarea id="edit_orden_notas_globales" name="descripcion_global" class="form-control" rows="2"></textarea>
                    </div>

                    <div class="text-end border-top pt-3">
                        <button type="button" class="btn btn-outline-secondary me-2 fw-bold" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn fw-bold text-white shadow" style="background-color: #dc3545;" id="btnGuardarEdicionOrdenFinal"><i class="bi bi-check-circle"></i> Guardar Alteración</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>