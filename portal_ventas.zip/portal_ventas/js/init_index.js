// LEYENDO CONSTANTES GLOBALES DE PRIVILEGIOS DESDE LOS CAMPOS OCULTOS DEL INDEX
const inputOmitir60 = document.getElementById('permiso_omitir_60');
const inputEditarBloq = document.getElementById('permiso_editar_bloq');

const PERMISO_OMITIR_60 = (inputOmitir60 && inputOmitir60.value === '1');
const PERMISO_EDITAR_BLOQUEADAS = (inputEditarBloq && inputEditarBloq.value === 'true');

document.addEventListener("DOMContentLoaded", function() {
    const btnTogglePc = document.getElementById('btnToggleSidebarPc');
    const sidebar = document.getElementById('sidebar');
    const btnHamburguesa = document.getElementById('btnHamburguesa');
    const overlay = document.getElementById('sidebarOverlay');

    // =========================================================
    // 1. L�0�7GICA DE COMPUTADORA (Totalmente intacta)
    // =========================================================
    if (btnTogglePc && sidebar) {
        btnTogglePc.addEventListener('click', function(e) {
            e.preventDefault();
            sidebar.classList.toggle('collapsed');
            
            // Guardar en el navegador si lo dej�� abierto o cerrado
            if (sidebar.classList.contains('collapsed')) {
                localStorage.setItem('sidebar_pc_collapsed', 'true');
            } else {
                localStorage.setItem('sidebar_pc_collapsed', 'false');
            }
        });

        // Revisar al recargar si lo hab��a dejado cerrado en la ��ltima sesi��n
        if (localStorage.getItem('sidebar_pc_collapsed') === 'true') {
            sidebar.classList.add('collapsed');
        }
    }

    // =========================================================
    // 2. L�0�7GICA PARA TEL�0�7FONOS M�0�7VILES (Nueva)
    // =========================================================
    if (btnHamburguesa && sidebar && overlay) {
        // Abrir el men�� al tocar el bot��n de hamburguesa
        btnHamburguesa.addEventListener('click', function(e) {
            e.preventDefault();
            sidebar.classList.add('active'); 
            overlay.classList.add('active');
        });

        // Cerrar el men�� al tocar el fondo oscuro (overlay)
        overlay.addEventListener('click', function() {
            sidebar.classList.remove('active');
            overlay.classList.remove('active');
        });

        // Cerrar el men�� autom��ticamente al seleccionar una opci��n (solo en m��viles)
        const navLinks = sidebar.querySelectorAll('a');
        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth < 768) { // Verifica que est�� en pantalla de celular
                    sidebar.classList.remove('active');
                    overlay.classList.remove('active');
                }
            });
        });
    }
});