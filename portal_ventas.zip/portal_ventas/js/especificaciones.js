let archivosSpecsMemoria = [];
let enviarLogisticaDespuesDeGuardarSpecs = false;
window.forzarEnvioMasterSinPago = false;
window.datosCxpMasterPendiente = null;

// ================= ESTILOS DINÁMICOS PARA LA ALERTA DE WHATSAPP =================
if ($('#animacion-wa').length === 0) {
    $('head').append('<style id="animacion-wa">@keyframes pulseWA { 0% { transform: scale(1); } 50% { transform: scale(1.15); box-shadow: 0 0 10px rgba(220,53,69,0.7); } 100% { transform: scale(1); } } .pulse-wa { animation: pulseWA 1.5s infinite; }</style>');
}

// ================= RENDERIZAR LISTA DE FOTOS PARA LA REGLA AZUL =================
window.renderizarListaFotosSpecs = function() {
    if($('#lista_fotos_seleccionadas_specs').length === 0) {
        $('#fotos_diseno_specs').after('<div id="lista_fotos_seleccionadas_specs"></div>');
    }
    let listHtml = '';
    if (archivosSpecsMemoria.length > 0) {
        listHtml += '<div class="mt-2 p-2 border border-primary rounded bg-white shadow-sm">';
        listHtml += '<strong class="small text-primary"><i class="bi bi-paperclip"></i> Nuevos archivos en cola para subir ('+archivosSpecsMemoria.length+'):</strong>';
        listHtml += '<ul class="list-group mb-0 mt-1" style="font-size: 0.8rem;">';
        archivosSpecsMemoria.forEach((file, index) => {
            listHtml += `<li class="list-group-item d-flex justify-content-between align-items-center py-1 px-2 text-dark">
                <span class="text-truncate" style="max-width: 85%;"><i class="bi bi-file-earmark-image me-2 text-danger"></i>${file.name}</span>
                <button type="button" class="btn btn-sm btn-danger py-0 px-2 rounded-pill shadow-sm" onclick="window.eliminarFotoSpec(${index})" title="Quitar de la lista"><i class="bi bi-trash"></i></button>
            </li>`;
        });
        listHtml += '</ul></div>';
    }
    $('#lista_fotos_seleccionadas_specs').html(listHtml);
};

window.eliminarFotoSpec = function(index) {
    archivosSpecsMemoria.splice(index, 1);
    window.renderizarListaFotosSpecs();
};

$(document).on('change', '#fotos_diseno_specs', function(e) {
    let files = e.target.files;
    if(files.length > 0) {
        for(let i=0; i<files.length; i++) {
            archivosSpecsMemoria.push(files[i]);
        }
        window.renderizarListaFotosSpecs();
    }
    $(this).val(''); 
});

// ================= REGLAS ESTRICTAS DE BLOQUEO Y TALLAS =================

// FUNCIÓN MEJORADA: Filtra para mostrar SOLO TELAS y prioriza según la categoría de la prenda
window.generarInputTelasLocal = function(telaActual, tipoPrenda) {
    let p = (tipoPrenda || '').toLowerCase();
    let catSugerida = '';
    
    // 1. Inferir categoría de la prenda en base a su nombre
    if(p.includes('deportiv') || p.includes('sport') || p.includes('jersey') || p.includes('atletic') || p.includes('basket')) catSugerida = 'deportiva';
    else if(p.includes('ejecutiv') || p.includes('columbia') || p.includes('oxford') || p.includes('unioffice') || p.includes('racing') || p.includes('chemis') || p.includes('camisa')) catSugerida = 'empresarial';
    else if(p.includes('braga') || p.includes('jean') || p.includes('seguridad') || p.includes('industrial') || p.includes('chambray') || p.includes('dril')) catSugerida = 'industrial';
    else if(p.includes('medico') || p.includes('médico') || p.includes('enfermer') || p.includes('quirurg') || p.includes('filipina') || p.includes('bata')) catSugerida = 'médica';
    else if(p.includes('chef') || p.includes('delantal') || p.includes('cocin') || p.includes('gastron')) catSugerida = 'gastronómica';
    else if(p.includes('escolar') || p.includes('colegio')) catSugerida = 'escolar';

    // Generamos un ID único para el datalist de este renglón específico
    let datalistId = 'dl_telas_' + Math.random().toString(36).substr(2, 9);
    
    let priorizadas = [];
    let resto = [];
    
    // 2. Extraer y filtrar desde la lista maestra (que carga index.php)
    $('#lista_telas_inteligente option').each(function() {
        let val = $(this).attr('value');
        let text = $(this).text(); // Ej: "Cat: Empresarial"
        let textLower = text.toLowerCase();
        
        // Excluir todo lo que NO sea tela (Hilos, botones, cierres, empaques, etc)
        let esTela = true;
        if (textLower.includes('hilo') || textLower.includes('boton') || textLower.includes('botón') || 
            textLower.includes('cierre') || textLower.includes('empaque') || textLower.includes('entretela') || 
            textLower.includes('bordado') || textLower.includes('pelón') || textLower.includes('pelon')) {
            esTela = false;
        }
        
        if(esTela) {
            if (catSugerida !== '' && textLower.includes(catSugerida)) {
                priorizadas.push(`<option value="${val}">⭐ Recomendada - ${val} - ${text}</option>`);
            } else {
                resto.push(`<option value="${val}">${val} - ${text}</option>`);
            }
        }
    });
    
    let finalOptions = priorizadas.join('') + resto.join('');
    
    return `
        <datalist id="${datalistId}">${finalOptions}</datalist>
        <input type="text" list="${datalistId}" class="form-control form-control-sm spec-tela border-primary" value="${telaActual}" placeholder="Buscar tela..." required>
    `;
};

window.esPrendaPantalon = function(tipoPrenda) {
    const n = String(tipoPrenda || '').toLowerCase();
    return n.includes('pantalon') || n.includes('pantalón') || n.includes('jean');
};

window.obtenerOpcionesTallaLocal = function(genero, tipoPrenda = '') {
    if (window.esPrendaPantalon(tipoPrenda)) {
        if (genero === 'Caballero') {
            return '<optgroup label="Normales Caballero"><option value="28">28</option><option value="30">30</option><option value="32" selected>32</option><option value="34">34</option><option value="36">36</option></optgroup><optgroup label="Tallas Extras Caballero"><option value="38">38</option><option value="40">40</option><option value="42">42</option><option value="44">44</option></optgroup>';
        }
        if (genero === 'Dama') {
            return '<optgroup label="Normales Dama"><option value="8">8</option><option value="10">10</option><option value="12" selected>12</option><option value="14">14</option></optgroup><optgroup label="Tallas Extras Dama"><option value="16">16</option><option value="18">18</option><option value="20">20</option><option value="22">22</option></optgroup>';
        }
    }
    // ELIMINADA LA TALLA 2 PARA NIÑAS Y NIÑOS DE RAÍZ
    if(genero === 'Dama') return '<option value="XS">XS</option><option value="S">S</option><option value="M" selected>M</option><option value="L">L</option><option value="XL">XL</option><option value="2XL">2XL</option><option value="3XL">3XL</option><option value="4XL">4XL</option>';
    if(genero === 'Caballero') return '<option value="XS">XS</option><option value="S">S</option><option value="M" selected>M</option><option value="L">L</option><option value="XL">XL</option><option value="2XL">2XL</option><option value="3XL">3XL</option><option value="4XL">4XL</option><option value="5XL">5XL</option>';
    if(genero === 'Niña' || genero === 'Niño') return '<option value="4">4</option><option value="6" selected>6</option><option value="8">8</option><option value="10">10</option><option value="12">12</option><option value="14">14</option><option value="16">16</option>';
    return '<option value="U" selected>Única / Ajustable</option><option value="S">S</option><option value="M">M</option><option value="L">L</option><option value="XL">XL</option>';
};

const GENEROS_REGLA_TALLER = ['Dama', 'Caballero', 'Niña', 'Niño'];

function normalizarGeneroReglaTaller(genero) {
    return GENEROS_REGLA_TALLER.includes(String(genero || '').trim()) ? String(genero).trim() : '';
}

function generoValidoParaReglaTaller(tipoPrenda, genero) {
    const nombre = String(tipoPrenda || '').toLocaleLowerCase();
    if (nombre.includes('gorra') || nombre.includes('visera') || nombre.includes('vicera')) {
        return genero === 'Accesorio';
    }
    if (nombre.includes('bota')) {
        return genero === 'No aplica';
    }
    return GENEROS_REGLA_TALLER.includes(genero);
}

window.generarOpcionesTallaEspecificas = function(tipoPrenda, rangoCotizado, generoSeleccionado, generoCotizado) {
    let nombreP = (tipoPrenda || '').toLowerCase();
    
    // Regla 1: Gorras y Viseras
    if (nombreP.includes('gorra') || nombreP.includes('visera') || nombreP.includes('vicera')) {
        return `<option value="Única">Única</option>`;
    }
    
    // Regla 2: Botas
    if (nombreP.includes('bota')) {
        let opts = '';
        for(let i = 35; i <= 46; i++) opts += `<option value="${i}">${i}</option>`;
        return opts;
    }

    const origenGeneroExtra = String(generoCotizado || '');
    const esRenglonExtra = /talla\s*extra/i.test(origenGeneroExtra) || /2xl|3xl|4xl|5xl/i.test(rangoCotizado || '');

    // Regla 2.5: Pantalones (Caballero: 28-36 normales / 38-44 extras | Dama: 8-14 normales / 16-22 extras)
    if (window.esPrendaPantalon(nombreP)) {
        if (!generoSeleccionado) {
            return '<option value="">Selecciona primero el género</option>';
        }
        if (generoSeleccionado === 'Caballero') {
            if (esRenglonExtra) {
                return ['38', '40', '42', '44'].map(t => `<option value="${t}">${t}</option>`).join('');
            }
            return `<optgroup label="Normales Caballero (28-36)">` +
                   ['28', '30', '32', '34', '36'].map(t => `<option value="${t}">${t}</option>`).join('') +
                   `</optgroup><optgroup label="Extras Caballero (38-44)">` +
                   ['38', '40', '42', '44'].map(t => `<option value="${t}">${t}</option>`).join('') +
                   `</optgroup>`;
        }
        if (generoSeleccionado === 'Dama') {
            if (esRenglonExtra) {
                return ['16', '18', '20', '22'].map(t => `<option value="${t}">${t}</option>`).join('');
            }
            return `<optgroup label="Normales Dama (8-14)">` +
                   ['8', '10', '12', '14'].map(t => `<option value="${t}">${t}</option>`).join('') +
                   `</optgroup><optgroup label="Extras Dama (16-22)">` +
                   ['16', '18', '20', '22'].map(t => `<option value="${t}">${t}</option>`).join('') +
                   `</optgroup>`;
        }
        if (generoSeleccionado === 'Niña' || generoSeleccionado === 'Niño') {
            return ['4', '6', '8', '10', '12', '14', '16'].map(t => `<option value="${t}">${t}</option>`).join('');
        }
    }

    const tallasExtra = ['2XL', '3XL', '4XL', '5XL'];
    const tallasEnRango = tallasExtra.filter(talla => new RegExp(talla, 'i').test(rangoCotizado || ''));
    if (tallasEnRango.length || /talla\s*extra/i.test(origenGeneroExtra)) {
        const tallasDelGenero = tallasExtra.filter(talla => new RegExp(talla, 'i').test(origenGeneroExtra));
        const tallasDisponibles = tallasEnRango.length
            ? tallasEnRango
            : (tallasDelGenero.length ? tallasDelGenero : tallasExtra);
        return tallasDisponibles.map(talla => `<option value="${talla}">${talla}</option>`).join('');
    }

    // Regla 3: Resto de prendas (Obligar a respetar la cotización sin tallas extra)
    if (rangoCotizado && rangoCotizado.includes('-')) {
        let tallasPermitidas = rangoCotizado.split('-').map(t => t.trim()).filter(t => t !== '' && t !== '2' && t !== 'Única / No Aplica');
        if (tallasPermitidas.length > 0) {
            let opts = '';
            tallasPermitidas.forEach(t => {
                opts += `<option value="${t}">${t}</option>`;
            });
            return opts;
        }
    }
    return null; // Fallback
};

window.generarCamposMedidasPersonalesSpec = function(medidas) {
    const campos = [
        ['hombro', 'Hombro'],
        ['busto_torax', 'Busto / tórax'],
        ['cintura', 'Cintura'],
        ['cadera', 'Cadera'],
        ['largo_camisa', 'Largo camisa'],
        ['largo_brazo', 'Largo brazo'],
        ['largo_pantalon', 'Largo pantalón'],
        ['tiro_total', 'Tiro total'],
        ['ancho_muslo', 'Ancho muslo'],
        ['ancho_rodilla', 'Ancho rodilla'],
        ['ancho_talon', 'Ancho talón']
    ];
    const valores = medidas || {};
    const tieneMedidas = campos.some(([key]) => Number(valores[key]) > 0);

    return `
        <tr class="fila-medidas-personales ${tieneMedidas ? '' : 'd-none'}">
            <td colspan="7">
                <div class="p-2 rounded border border-primary bg-light">
                    <div class="small fw-bold text-primary mb-2"><i class="bi bi-rulers me-1"></i> Medidas personales (cm)</div>
                    <div class="row g-2">
                        ${campos.map(([key, label]) => {
                            const value = Number(valores[key]);
                            const safeValue = Number.isFinite(value) && value > 0 ? value : '';
                            return `<div class="col-6 col-md-3">
                                <label class="form-label small mb-1">${label}</label>
                                <input type="number" min="0" step="0.1" class="form-control form-control-sm spec-medida" data-medida="${key}" value="${safeValue}" placeholder="cm">
                            </div>`;
                        }).join('')}
                    </div>
                </div>
            </td>
        </tr>`;
};

window.extraerArtesPorPrendaCotizacion = function(items) {
    const mapaPorPrenda = {};
    const artesGenerales = [];
    const prendasFisicas = (items || []).filter(it => {
        const esArte = (it.detalle_diseno && it.detalle_diseno.includes('Ubicación:')) || /^(bordado|serigraf|dtf|vinil|sublimaci)/i.test(String(it.tipo_prenda || '').trim());
        const esExtra = /^tallas?\s+extras?\b/i.test(String(it.tipo_prenda || '').trim());
        return !esArte && !esExtra;
    });

    (items || []).forEach(it => {
        const diseno = String(it.detalle_diseno || '');
        const nombreArte = String(it.tipo_prenda || '').trim();
        const esArte = diseno.includes('Ubicación:') || /^(bordado|serigraf|dtf|vinil)/i.test(nombreArte);
        if (!esArte) return;

        let vinculo = '';
        let ubicacion = '';
        if (diseno.includes('[Para: ')) {
            const partes = diseno.split('] - Ubicación:');
            vinculo = partes[0].replace('[Para:', '').trim();
            ubicacion = (partes[1] || '').trim();
        } else if (diseno.includes('Ubicación:')) {
            ubicacion = diseno.split('Ubicación:').pop().trim();
        }

        const textoArte = ubicacion ? `${nombreArte} (${ubicacion})` : nombreArte;
        if (vinculo) {
            const clave = vinculo.toLowerCase().trim();
            if (!mapaPorPrenda[clave]) mapaPorPrenda[clave] = [];
            if (!mapaPorPrenda[clave].includes(textoArte)) mapaPorPrenda[clave].push(textoArte);
        } else {
            if (!artesGenerales.includes(textoArte)) artesGenerales.push(textoArte);
        }
    });

    return {
        obtenerTextoParaPrenda: function(tipoPrenda, genero) {
            const pLower = String(tipoPrenda || '').toLowerCase().trim();
            const gLower = String(genero || '').toLowerCase().trim();
            const claveCompleta = gLower && gLower !== 'no especificado' ? `${pLower} (${gLower})` : pLower;
            const claveSinGenero = `${pLower} (no especificado)`;

            let encontrados = [];
            if (mapaPorPrenda[claveCompleta]) encontrados = encontrados.concat(mapaPorPrenda[claveCompleta]);
            if (mapaPorPrenda[pLower]) encontrados = encontrados.concat(mapaPorPrenda[pLower]);
            if (mapaPorPrenda[claveSinGenero]) encontrados = encontrados.concat(mapaPorPrenda[claveSinGenero]);

            if (artesGenerales.length > 0) {
                const esPrendaSuperior = /(camisa|chemis|chemise|franela|jersey|filipina|bata|chaqueta|chaleco|sueter|delantal|gorra)/i.test(pLower);
                if (prendasFisicas.length === 1 || esPrendaSuperior) {
                    encontrados = encontrados.concat(artesGenerales);
                }
            }
            return [...new Set(encontrados)].join(' + ');
        }
    };
};

// ================= MODAL DE LA REGLA AZUL =================
window.abrirModalEspecificarDetalles = function(id_cot, nro, enviarALogistica = false, forzarSinPagoMaster = false, datosCxpMaster = null) {
    enviarLogisticaDespuesDeGuardarSpecs = enviarALogistica;
    window.forzarEnvioMasterSinPago = Boolean(forzarSinPagoMaster);
    window.datosCxpMasterPendiente = datosCxpMaster || null;

    $('#id_cotizacion_especificar').val(id_cot);
    $('#cuerpoEspecificaciones').html('<div class="text-center py-4"><div class="spinner-border text-primary"></div></div>');
    $('#btnGuardarSpecs').html(enviarALogistica
        ? '<i class="bi bi-check2-circle"></i> Guardar reglas y enviar a logística'
        : '<i class="bi bi-floppy-fill"></i> Guardar Tallas y Telas');
    $('#modalEspecificarDetalles .modal-title').html(enviarALogistica
        ? '<i class="bi bi-rulers"></i> Revisión final de reglas antes de logística'
        : '<i class="bi bi-rulers"></i> Especificar Tallas y Telas para Taller');
    
    $('#fotos_diseno_specs').val('');
    $('#fotos_diseno_previas_regla').empty();
    archivosSpecsMemoria = [];
    if($('#lista_fotos_seleccionadas_specs').length > 0) {
        $('#lista_fotos_seleccionadas_specs').empty();
    }

    new bootstrap.Modal(document.getElementById('modalEspecificarDetalles')).show();

    $.get('api/api_cotizaciones.php', { accion: 'detalles_y_recursos', id_cotizacion: id_cot }, function(res) {
        if(res.success) {
            if(res.fotos_diseno && res.fotos_diseno !== '') {
                let fArr = res.fotos_diseno.split(',');
                let fHtml = '<div class="w-100 mb-1"><strong class="small text-success"><i class="bi bi-check-circle-fill"></i> Imágenes/Documentos ya guardados en este pedido:</strong></div>';
                fArr.forEach(f => {
                    if (f.trim() !== '') {
                        let ext = f.split('.').pop().toLowerCase();
                        if (ext === 'pdf') {
                            fHtml += `<div class="position-relative shadow-sm me-2 mb-2 p-1 border rounded" style="background:#f0f8ff;">
                                        <a href="../images/ordenes/${f}" target="_blank" class="text-decoration-none text-primary" style="font-size: 0.8rem; font-weight:bold;">
                                            <i class="bi bi-file-pdf-fill text-danger fs-4 align-middle"></i> Documento PDF
                                        </a>
                                      </div>`;
                        } else {
                            fHtml += `<div class="position-relative shadow-sm me-2 mb-2">
                                        <a href="../images/ordenes/${f}" target="_blank">
                                            <img src="../images/ordenes/${f}" style="height: 60px; object-fit: cover; border-radius: 6px; border: 2px solid #0B4C8C;" title="Clic para ampliar">
                                        </a>
                                      </div>`;
                        }
                    }
                });
                $('#fotos_diseno_previas_regla').html(fHtml);
            }

            const buscadorArtes = window.extraerArtesPorPrendaCotizacion(res.data || []);

            let html = '';
            res.data.forEach((item, index) => {
                let esArte = (item.detalle_diseno && item.detalle_diseno.includes('Ubicación:')) || /^(bordado|serigraf|dtf|vinil)/i.test(String(item.tipo_prenda || '').trim());
                if (esArte) return; 
                if (/^tallas?\s+extras?\b/i.test(String(item.tipo_prenda || '').trim())) return;

                let nombreP = (item.tipo_prenda || '').toLowerCase();
                let esGorra = nombreP.includes('gorra') || nombreP.includes('visera') || nombreP.includes('vicera');
                let esBota = nombreP.includes('bota');

                let rangoCotizado = '';
                if (item.detalle_diseno && item.detalle_diseno.includes('Talla:')) {
                    let match = item.detalle_diseno.match(/Talla:\s*([^|]+)/);
                    if (match && match[1]) rangoCotizado = match[1].trim();
                }

                let telaCotizada = '';
                let matchTela = String(item.detalle_diseno || '').match(/\bTela:\s*([^|]+)/i);
                if (matchTela && matchTela[1]) {
                    let telaDetectada = matchTela[1].trim();
                    if (!/^(n\/a|no aplica|no especificada)$/i.test(telaDetectada)) {
                        telaCotizada = telaDetectada;
                    }
                }

                const textoBordadoVinculado = buscadorArtes.obtenerTextoParaPrenda(item.tipo_prenda, item.genero);

                let specs = [];
                try { specs = JSON.parse(item.especificaciones_tallas); } catch(e) {}
                const generoOriginal = String(item.genero || '');
                const generoReglaCotizada = normalizarGeneroReglaTaller(generoOriginal);
                if (!specs || specs.length === 0) {
                    specs = [{ cantidad: '', genero: generoReglaCotizada, talla: '', tela: telaCotizada, nombre: '', obs: textoBordadoVinculado }];
                } else if (textoBordadoVinculado) {
                    specs.forEach(s => {
                        const obsActual = String(s.obs || '').trim();
                        if (!obsActual) {
                            s.obs = textoBordadoVinculado;
                        } else if (!obsActual.toLowerCase().includes('bordado') && !obsActual.toLowerCase().includes(textoBordadoVinculado.toLowerCase())) {
                            s.obs = obsActual + ' | ' + textoBordadoVinculado;
                        }
                    });
                }

                const badgeBordado = textoBordadoVinculado
                    ? `<div class="small text-danger fw-bold mt-1"><i class="bi bi-award-fill me-1"></i>Arte/Bordado relacionado: ${textoBordadoVinculado}</div>`
                    : '';

                html += `
                <div class="mb-4 bg-white p-3 border rounded shadow-sm">
                    <div class="d-flex justify-content-between align-items-center mb-2 border-bottom pb-2">
                        <div>
                            <h6 class="fw-bold m-0" style="color: #0B4C8C;"><i class="bi bi-box-seam text-warning"></i> ${item.tipo_prenda} (${item.genero}) - Cantidad Facturada: <span class="badge bg-danger">${item.cantidad}</span></h6>
                            ${badgeBordado}
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-primary fw-bold" onclick="window.agregarFilaSpec(${item.ID}, '${item.genero}', '${item.tipo_prenda.replace(/'/g, "\\'")}', '${rangoCotizado.replace(/'/g, "\\'")}', '${textoBordadoVinculado.replace(/'/g, "\\'")}')">+ Añadir Línea</button>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-sm table-borderless align-middle m-0" id="tabla_specs_${item.ID}" data-cant-facturada="${item.cantidad}" data-bordado-vinculado="${textoBordadoVinculado.replace(/"/g, '&quot;')}">
                            <thead class="text-muted small border-bottom"><tr><th>Cant.</th><th>Género</th><th>Talla</th><th>Tela / Color</th><th>Nombre (Opcional)</th><th>Observación</th><th></th></tr></thead>
                            <tbody>`;
                
                specs.forEach(s => {
                    let genSel = normalizarGeneroReglaTaller(s.genero);
                    let telaVal = telaCotizada || s.tela || '';

                    if (esGorra) { genSel = 'Accesorio'; telaVal = 'No aplica'; }
                    if (esBota) { genSel = 'No aplica'; telaVal = 'No aplica'; }

                    let selectGeneroHtml = `
                        <select class="form-select form-select-sm spec-genero" onchange="window.actualizarTallaSpec(this)" required ${esGorra || esBota ? 'style="pointer-events:none; background-color:#e9ecef;" tabindex="-1"' : ''}>
                            ${esGorra ? `<option value="Accesorio" selected>Accesorio</option>` : ''}
                            ${esBota ? `<option value="No aplica" selected>No aplica</option>` : ''}
                            ${(!esGorra && !esBota) ? `
                            <option value="" ${genSel===''?'selected':''}>Seleccionar género</option>
                            <option value="Dama" ${genSel==='Dama'?'selected':''}>Dama</option>
                            <option value="Caballero" ${genSel==='Caballero'?'selected':''}>Caballero</option>
                            <option value="Niña" ${genSel==='Niña'?'selected':''}>Niña</option>
                            <option value="Niño" ${genSel==='Niño'?'selected':''}>Niño</option>` : ''}
                        </select>
                    `;

                    let inputTelaHtml = (esGorra || esBota) ? 
                        `<input type="text" class="form-control form-control-sm spec-tela" value="No aplica" readonly tabindex="-1">` : 
                        (telaCotizada
                            ? `<input type="text" class="form-control form-control-sm spec-tela border-primary" value="${telaCotizada.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;')}" readonly required>`
                            : window.generarInputTelasLocal(telaVal, item.tipo_prenda));

                    let obsSafe = String(s.obs || '').replace(/"/g, '&quot;');

                    html += `
                        <tr class="fila-spec" data-id-detalle="${item.ID}" data-tipo-prenda="${item.tipo_prenda.replace(/"/g, '&quot;')}" data-rango-cotizado="${rangoCotizado.replace(/"/g, '&quot;')}" data-genero-cotizado="${generoOriginal.replace(/"/g, '&quot;')}">
                            <td style="width: 80px;"><input type="number" class="form-control form-control-sm text-center spec-cant border-primary fw-bold" value="${s.cantidad}" placeholder="0" min="1" required></td>
                            <td style="width: 130px;">${selectGeneroHtml}</td>
                            <td style="width: 100px;"><select class="form-select form-select-sm border-primary fw-bold spec-talla" data-talla-actual="${s.talla}" required></select></td>
                            <td style="width: 250px;">${inputTelaHtml}</td>
                            <td><input type="text" class="form-control form-control-sm spec-nombre" value="${s.nombre||''}" placeholder="Ej: Juan P."></td>
                            <td><input type="text" class="form-control form-control-sm spec-obs" value="${obsSafe}" placeholder="Sin bolsillos..."></td>
                            <td class="text-center">
                                <button type="button" class="btn btn-sm btn-outline-primary btn-toggle-medidas" title="Especificar medidas personales"><i class="bi bi-rulers"></i></button>
                                <button type="button" class="btn btn-sm text-danger" onclick="$(this).closest('tr').next('.fila-medidas-personales').remove(); $(this).closest('tr').remove()"><i class="bi bi-x-circle-fill"></i></button>
                            </td>
                        </tr>${window.generarCamposMedidasPersonalesSpec(s.medidas_personales)}`;
                });
                html += `</tbody></table></div></div>`;
            });

            if (html === '') { html = '<div class="alert alert-warning text-center fw-bold">No hay prendas facturadas en esta cotización (solo artes o extras).</div>'; }
            if (enviarLogisticaDespuesDeGuardarSpecs) {
                html = '<div class="alert alert-info fw-bold"><i class="bi bi-clipboard-check me-1"></i> Revisa cada talla, cantidad y tela. Al guardar, el sistema validará las reglas y enviará la cotización a logística.</div>' + html;
            }
            $('#cuerpoEspecificaciones').html(html);
            $('.spec-genero').each(function() { window.actualizarTallaSpec(this, true); });
        } else { $('#cuerpoEspecificaciones').html('<div class="alert alert-danger text-center">Error al cargar los detalles: ' + (res.msg || 'respuesta inválida') + '</div>'); }
    }, 'json').fail(function() {
        $('#cuerpoEspecificaciones').html('<div class="alert alert-danger text-center">No se pudo cargar la cotización. Cierra esta ventana e intenta nuevamente.</div>');
    });
};

window.agregarFilaSpec = function(idDetalle, generoDefecto, tipoPrenda, rangoCotizado, obsPorDefecto = '') {
    let bordadoTabla = obsPorDefecto || $(`#tabla_specs_${idDetalle}`).attr('data-bordado-vinculado') || '';
    let nombreP = (tipoPrenda || '').toLowerCase();
    let esGorra = nombreP.includes('gorra') || nombreP.includes('visera') || nombreP.includes('vicera');
    let esBota = nombreP.includes('bota');

    let tbody = $(`#tabla_specs_${idDetalle} tbody`);
    let gen = normalizarGeneroReglaTaller(generoDefecto);
    
    if (esGorra) gen = 'Accesorio';
    if (esBota) gen = 'No aplica';

    let selectGeneroHtml = `
        <select class="form-select form-select-sm spec-genero" onchange="window.actualizarTallaSpec(this)" required ${esGorra || esBota ? 'style="pointer-events:none; background-color:#e9ecef;" tabindex="-1"' : ''}>
            ${esGorra ? `<option value="Accesorio" selected>Accesorio</option>` : ''}
            ${esBota ? `<option value="No aplica" selected>No aplica</option>` : ''}
            ${(!esGorra && !esBota) ? `
            <option value="" ${gen===''?'selected':''}>Seleccionar género</option>
            <option value="Dama" ${gen==='Dama'?'selected':''}>Dama</option>
            <option value="Caballero" ${gen==='Caballero'?'selected':''}>Caballero</option>
            <option value="Niña" ${gen==='Niña'?'selected':''}>Niña</option>
            <option value="Niño" ${gen==='Niño'?'selected':''}>Niño</option>` : ''}
        </select>
    `;

    let inputTelaHtml = (esGorra || esBota) ? 
        `<input type="text" class="form-control form-control-sm spec-tela" value="No aplica" readonly tabindex="-1">` : 
        window.generarInputTelasLocal('', tipoPrenda);

    let html = `
        <tr class="fila-spec" data-id-detalle="${idDetalle}" data-tipo-prenda="${(tipoPrenda||'').replace(/"/g, '&quot;')}" data-rango-cotizado="${(rangoCotizado||'').replace(/"/g, '&quot;')}" data-genero-cotizado="${(generoDefecto||'').replace(/"/g, '&quot;')}">
            <td style="width: 80px;"><input type="number" class="form-control form-control-sm text-center spec-cant border-primary fw-bold" value="1" min="1" required></td>
            <td style="width: 130px;">${selectGeneroHtml}</td>
            <td style="width: 100px;"><select class="form-select form-select-sm border-primary fw-bold spec-talla" required></select></td>
            <td style="width: 250px;">${inputTelaHtml}</td>
            <td><input type="text" class="form-control form-control-sm spec-nombre" placeholder="Ej: Juan P."></td>
            <td><input type="text" class="form-control form-control-sm spec-obs" value="${String(bordadoTabla).replace(/"/g, '&quot;')}" placeholder="Sin bolsillos..."></td>
            <td class="text-center">
                <button type="button" class="btn btn-sm btn-outline-primary btn-toggle-medidas" title="Especificar medidas personales"><i class="bi bi-rulers"></i></button>
                <button type="button" class="btn btn-sm text-danger" onclick="$(this).closest('tr').next('.fila-medidas-personales').remove(); $(this).closest('tr').remove()"><i class="bi bi-x-circle-fill"></i></button>
            </td>
        </tr>${window.generarCamposMedidasPersonalesSpec({})}`;
    tbody.append(html);
    window.actualizarTallaSpec(tbody.find('.fila-spec').last().find('.spec-genero')[0], false);
};

$(document).on('click', '.btn-toggle-medidas', function() {
    $(this).closest('tr').next('.fila-medidas-personales').toggleClass('d-none');
});

window.actualizarTallaSpec = function(selectElem, init = false) {
    let genero = $(selectElem).val();
    let $tr = $(selectElem).closest('tr');
    let $tallaSelect = $tr.find('.spec-talla');
    let tallaActual = $tallaSelect.data('talla-actual'); 
    
    let tipoPrenda = $tr.data('tipo-prenda') || '';
    let rangoCotizado = $tr.data('rango-cotizado') || '';
    
    let generoCotizado = $tr.data('genero-cotizado') || genero;
    let opcionesEspecificas = window.generarOpcionesTallaEspecificas(tipoPrenda, rangoCotizado, genero, generoCotizado);
    
    if (opcionesEspecificas !== null) {
        $tallaSelect.html(opcionesEspecificas);
    } else {
        let fallbackHTML = genero
            ? window.obtenerOpcionesTallaLocal(genero, tipoPrenda)
            : '<option value="">Selecciona primero el género</option>';
        $tallaSelect.html(fallbackHTML);
    }
    
    if (init && tallaActual) { 
        if ($tallaSelect.find(`option[value="${tallaActual}"]`).length === 0) {
            $tallaSelect.append(`<option value="${tallaActual}">${tallaActual}</option>`);
        }
        $tallaSelect.val(tallaActual); 
    }
};

$(document).on('submit', '#formGuardarEspecificaciones', function(e) {
    e.preventDefault();
    $('#btnGuardarSpecs').prop('disabled', true).html('<span class="spinner-border spinner-border-sm"></span>');

    let payload = [];
    let grupos = {};
    let validacionExitosa = true;
    let mensajeError = '';

    $('.fila-spec').each(function() {
        let idDetalle = $(this).data('id-detalle');
        if(!grupos[idDetalle]) grupos[idDetalle] = { specs: [], totalAsignado: 0 };
        
        let cantAsignada = parseInt($(this).find('.spec-cant').val()) || 0;
        let genero = $(this).find('.spec-genero').val();
        let talla = $(this).find('.spec-talla').val();
        let tela = $(this).find('.spec-tela').val();
        const tipoPrenda = $(this).data('tipo-prenda');
        if (cantAsignada < 1 || !generoValidoParaReglaTaller(tipoPrenda, genero) || !talla || !String(tela || '').trim()) {
            validacionExitosa = false;
            mensajeError = 'Selecciona género, talla y tela, y completa una cantidad mayor que cero en todas las líneas antes de guardar.';
            $(this).addClass('table-danger');
        } else {
            $(this).removeClass('table-danger');
        }
        grupos[idDetalle].specs.push({
            cantidad: cantAsignada,
            genero: genero,
            talla: talla,
            tela: tela,
            nombre: $(this).find('.spec-nombre').val().trim(),
            obs: $(this).find('.spec-obs').val().trim(),
            medidas_personales: (function($row) {
                const medidas = {};
                $row.next('.fila-medidas-personales').find('.spec-medida').each(function() {
                    medidas[$(this).data('medida')] = $(this).val() || 0;
                });
                return medidas;
            })($(this))
        });
        grupos[idDetalle].totalAsignado += cantAsignada;
    });

    $('#cuerpoEspecificaciones table[id^="tabla_specs_"]').each(function() {
        let idDetalle = String(this.id).replace('tabla_specs_', '');
        if (!grupos[idDetalle] || grupos[idDetalle].specs.length === 0) {
            validacionExitosa = false;
            mensajeError = 'Hay prendas sin líneas de talla y tela. Añade al menos una línea para cada prenda.';
        }
    });

    for (let id in grupos) {
        let cantFacturada = parseInt($(`#tabla_specs_${id}`).data('cant-facturada'));
        if (grupos[id].totalAsignado !== cantFacturada) {
            validacionExitosa = false;
            mensajeError = `La cantidad que has especificado (${grupos[id].totalAsignado}) no coincide con la cantidad que el cliente compró (${cantFacturada}) en uno de los renglones. Ajusta los números.`;
            break;
        }
        payload.push({ id_detalle: id, especificaciones: JSON.stringify(grupos[id].specs) });
    }

    if (!validacionExitosa) {
        $('#btnGuardarSpecs').prop('disabled', false).html('<i class="bi bi-floppy-fill"></i> Guardar Tallas y Telas');
        return Swal.fire('Error de Cantidades', mensajeError, 'error');
    }

    let formData = new FormData(this);
    formData.append('accion', 'guardar_especificaciones');
    formData.append('id_cotizacion', $('#id_cotizacion_especificar').val());
    formData.append('data', JSON.stringify(payload));

    if (archivosSpecsMemoria && archivosSpecsMemoria.length > 0) {
        for (let i = 0; i < archivosSpecsMemoria.length; i++) {
            formData.append('fotos_diseno[]', archivosSpecsMemoria[i]);
        }
    }

    $.ajax({
        url: 'api/api_cotizaciones.php',
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        dataType: 'json',
        success: function(res) {
            if(res.success) {
                if (enviarLogisticaDespuesDeGuardarSpecs) {
                    let postParams = {
                        accion: 'enviar_logistica',
                        id_cotizacion: $('#id_cotizacion_especificar').val(),
                        forzar_sin_pago_master: window.forzarEnvioMasterSinPago ? 1 : 0
                    };
                    if (window.datosCxpMasterPendiente) {
                        postParams.generar_cxp_master = 1;
                        postParams.cxp_id_proveedor = window.datosCxpMasterPendiente.id_proveedor || 0;
                        postParams.cxp_monto = window.datosCxpMasterPendiente.monto || 0;
                        postParams.cxp_descripcion = window.datosCxpMasterPendiente.descripcion || '';
                    }
                    $.post('api/api_cotizaciones.php', postParams, function(resEnvio) {
                        if (resEnvio.success) {
                            enviarLogisticaDespuesDeGuardarSpecs = false;
                            window.forzarEnvioMasterSinPago = false;
                            window.datosCxpMasterPendiente = null;
                            $('#modalEspecificarDetalles').modal('hide');
                            Swal.fire('¡Enviado!', resEnvio.msg || 'Las reglas fueron revisadas y la cotización se envió a logística.', 'success');
                            if (typeof window.cargarHistorial === 'function') window.cargarHistorial();
                            if (typeof window.chequearCotizacionesPendientes === 'function') window.chequearCotizacionesPendientes();
                        } else {
                            Swal.fire('No se pudo enviar', (resEnvio.msg || '') + '\nCorrige las reglas mostradas y vuelve a guardar.', 'warning');
                        }
                    }, 'json').fail(function() {
                        Swal.fire('Error de conexión', 'Las reglas se guardaron, pero no se pudo confirmar el envío. Intenta enviar nuevamente.', 'error');
                    });
                } else {
                    Swal.fire({icon: 'success', title: 'Especificaciones e Imágenes Guardadas', timer: 1500, showConfirmButton: false});
                    $('#modalEspecificarDetalles').modal('hide');
                }
            } else { Swal.fire('Error', res.msg, 'error'); }
        },
        complete: function() {
            $('#btnGuardarSpecs').prop('disabled', false).html(enviarLogisticaDespuesDeGuardarSpecs
                ? '<i class="bi bi-check2-circle"></i> Guardar reglas y enviar a logística'
                : '<i class="bi bi-floppy-fill"></i> Guardar Tallas y Telas');
        }
    });
});

$(document).on('hidden.bs.modal', '#modalEspecificarDetalles', function() {
    enviarLogisticaDespuesDeGuardarSpecs = false;
    window.forzarEnvioMasterSinPago = false;
    window.datosCxpMasterPendiente = null;
    $('#btnGuardarSpecs').html('<i class="bi bi-floppy-fill"></i> Guardar Tallas y Telas');
    $('#modalEspecificarDetalles .modal-title').html('<i class="bi bi-rulers"></i> Especificar Tallas y Telas para Taller');
});


// ==============================================================================
// CÁLCULO DINÁMICO DE COMISIÓN EN BOLÍVARES
// ==============================================================================
function calcularComisionBsGlobal() {
    setTimeout(() => {
        let netoTexto = $('#com_neto_pagar').text().replace(/[^0-9.-]/g, '');
        let montoUsd = netoTexto !== '' ? (parseFloat(netoTexto) || 0) : (parseFloat($('#com_monto_calculado').val()) || 0);
        let tasa = parseFloat($('#com_tasa').val()) || 0;
        let totalBs = montoUsd * tasa;
        if (totalBs > 0) {
            $('#com_monto_bs').val(totalBs.toLocaleString('es-VE', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' Bs');
        } else {
            $('#com_monto_bs').val('');
        }
    }, 50); 
}
$(document).on('input', '#com_porc, #com_tasa', function() { calcularComisionBsGlobal(); });
$(document).on('shown.bs.modal', '#modalComision', function () { calcularComisionBsGlobal(); });


// ==============================================================================
// WHATSAPP
// ==============================================================================
window.enviarWAAvance = function(tlfRaw, nombreCliente, hash, idCotizacion) {
    let tlf = window.formatearNumeroWA(tlfRaw);
    if(!tlf) return Swal.fire('Error', 'El cliente no tiene un número válido.', 'warning');
    
    let urlTrack = window.location.origin + window.location.pathname.replace('portal_ventas/index.php', '') + 'envios/tracking.php?h=' + hash;
    let msj = `Hola *${nombreCliente}*. Le enviamos un cordial saludo desde *Unifuerte*.\n\nLe notificamos que ha habido un avance en la producción de su pedido.\n\nPuede ver el progreso en tiempo real y las fotografías del proceso en el siguiente enlace:\n🔗 ${urlTrack}\n\n¡Gracias por su confianza!`;
    
    $.post('api/api_cotizaciones.php', {accion: 'limpiar_noti_wa', id: idCotizacion}, function(){ window.cargarHistorial(); });
    window.open(`https://api.whatsapp.com/send?phone=${tlf}&text=${encodeURIComponent(msj)}`, '_blank');
};

window.enviarWACobro = function(tlfRaw, nombreCliente, nroCotizacion, idCotizacion) {
    let tlf = window.formatearNumeroWA(tlfRaw);
    if(!tlf) return Swal.fire('Error', 'El cliente no tiene un número válido.', 'warning');
    
    let msj = `Estimado(a) *${nombreCliente}*, reciba un cordial y respetuoso saludo de parte de todo el equipo de *Unifuerte*.\n\nNos complace informarle que la producción de su orden *${nroCotizacion}* ha sido concluida exitosamente y se encuentra lista para su entrega.\n\nPara poder proceder con el despacho o retiro de su mercancía, le agradecemos muy amablemente realizar la cancelación de la totalidad del saldo pendiente.\n\nQuedamos a su entera disposición y atentos a su comprobante de pago para concretar la entrega. ¡Muchas gracias por su confianza y preferencia!`;
    
    $.post('api/api_cotizaciones.php', {accion: 'limpiar_noti_wa', id: idCotizacion}, function(){ window.cargarHistorial(); });
    window.open(`https://api.whatsapp.com/send?phone=${tlf}&text=${encodeURIComponent(msj)}`, '_blank');
};

window.enviarWAFinalizado = function(tlfRaw, nombreCliente, hash, idCotizacion) {
    let tlf = window.formatearNumeroWA(tlfRaw);
    if(!tlf) return Swal.fire('Error', 'El cliente no tiene un número válido.', 'warning');
    
    let urlTrack = window.location.origin + window.location.pathname.replace('portal_ventas/index.php', '') + 'envios/tracking.php?h=' + hash;
    let msj = `Estimado(a) *${nombreCliente}*. Le notificamos desde *Unifuerte* que la producción de su orden ha concluido exitosamente y está lista.\n\nPuede ver el resumen final aquí:\n🔗 ${urlTrack}\n\nQuedamos a su entera disposición para coordinar la entrega.`;
    
    $.post('api/api_cotizaciones.php', {accion: 'limpiar_noti_wa', id: idCotizacion}, function(){ window.cargarHistorial(); });
    window.open(`https://api.whatsapp.com/send?phone=${tlf}&text=${encodeURIComponent(msj)}`, '_blank');
};

window.enviarWAGarantiaProceso = function(tlfRaw, nombreCliente, nroCotizacion, hash, idCotizacion) {
    let tlf = window.formatearNumeroWA(tlfRaw);
    if(!tlf) return Swal.fire('Error', 'El cliente no tiene un número válido.', 'warning');
    
    let urlTrack = window.location.origin + window.location.pathname.replace('portal_ventas/index.php', '') + 'envios/tracking.php?h=' + hash;
    let msj = `Estimado(a) *${nombreCliente}*, reciba un cordial y respetuoso saludo de parte del equipo de *Unifuerte*.\n\nLe informamos que hemos recibido su solicitud de Garantía Textil para la orden *${nroCotizacion}*. Nuestro equipo de taller ya se encuentra trabajando cuidadosamente en las modificaciones requeridas, para asegurar que sus prendas cumplan con nuestros más altos estándares de calidad.\n\nPuede ver el progreso y fotografías de la reparación en el siguiente enlace:\n🔗 ${urlTrack}\n\nLe mantendremos informado(a) de los avances. ¡Agradecemos inmensamente su paciencia y su confianza en nosotros!`;
    
    $.post('api/api_cotizaciones.php', {accion: 'limpiar_noti_wa', id: idCotizacion}, function(){ window.cargarHistorial(); });
    window.open(`https://api.whatsapp.com/send?phone=${tlf}&text=${encodeURIComponent(msj)}`, '_blank');
};

window.enviarWAGarantiaLista = function(tlfRaw, nombreCliente, nroCotizacion, hash, idCotizacion) {
    let tlf = window.formatearNumeroWA(tlfRaw);
    if(!tlf) return Swal.fire('Error', 'El cliente no tiene un número válido.', 'warning');
    
    let urlTrack = window.location.origin + window.location.pathname.replace('portal_ventas/index.php', '') + 'envios/tracking.php?h=' + hash;
    let msj = `Estimado(a) *${nombreCliente}*, reciba un cordial y respetuoso saludo de parte de *Unifuerte*.\n\nNos complace notificarle que los trabajos correspondientes a su Garantía Textil en la orden *${nroCotizacion}* han concluido de manera exitosa y las prendas han superado nuevamente nuestra estricta auditoría de calidad.\n\nPuede ver el resultado final y las fotografías en el siguiente enlace:\n🔗 ${urlTrack}\n\nSu pedido se encuentra totalmente listo. Quedamos a su entera disposición para coordinar la entrega o el retiro del mismo. ¡Muchas gracias por su preferencia!`;
    
    $.post('api/api_cotizaciones.php', {accion: 'limpiar_noti_wa', id: idCotizacion}, function(){ window.cargarHistorial(); });
    window.open(`https://api.whatsapp.com/send?phone=${tlf}&text=${encodeURIComponent(msj)}`, '_blank');
};

// ================= GORRAS Y BOTAS EN EL COTIZADOR (CATÁLOGO) =================
$(document).on('shown.bs.modal', '#modalAgregarPrenda', function () {
    let nombreP = ($('#modal_nombre_prod').text() || '').toLowerCase();
    let $gen = $('#modal_genero');
    let $talla = $('#modal_talla');
    let $tela = $('#modal_tela');

    if ($('#modal_categoria_prod').val() === 'Arte Final') return;

    if (nombreP.includes('gorra') || nombreP.includes('visera') || nombreP.includes('vicera')) {
        $gen.html('<option value="Accesorio">Accesorio</option>').val('Accesorio').css('pointer-events', 'none').css('background-color', '#e9ecef');
        $talla.val('Única').prop('readonly', true).css('pointer-events', 'none');
        $tela.val('No aplica').prop('readonly', true).css('pointer-events', 'none');
    } else if (nombreP.includes('bota')) {
        $gen.html('<option value="No aplica">No aplica</option>').val('No aplica').css('pointer-events', 'none').css('background-color', '#e9ecef');
        $talla.val('35 - 46').prop('readonly', true).css('pointer-events', 'none');
        $tela.val('No aplica').prop('readonly', true).css('pointer-events', 'none');
    } else {
        // RESTAURAR OPCIONES ORIGINALES
        if ($gen.find('option[value="Adulto (Dama o Caballero)"]').length === 0) {
            $gen.html(`
                <option value="Adulto (Dama o Caballero)">Adulto (Dama o Caballero)</option>
                <option value="Infantil (Unisex)">Infantil (Unisex)</option>
                <option value="Juvenil (Unisex)">Juvenil (Unisex)</option>
            `);
        }
        $gen.css('pointer-events', 'auto').css('background-color', '').val('Adulto (Dama o Caballero)');
        $talla.prop('readonly', true).css('pointer-events', 'none');
        $tela.prop('readonly', false).css('pointer-events', 'auto').val('');
        
        if(typeof window.actualizarTallaModalPrenda === 'function') {
            window.actualizarTallaModalPrenda($gen[0]);
        }
    }
});

// ================= EVENTOS PARA ACTIVAR SECCIONES DE TALLAS Y SASTRERÍA =================
$(document).on('change', '#check_asignar_tallas', function() {
    if ($(this).is(':checked')) {
        $('#seccion_asignacion_tallas').slideDown(300);
        if ($('#tbody_medidas_personales tr').length === 0 && typeof window.autogenerarFilasTallas === 'function') {
            window.autogenerarFilasTallas(true);
        }
    } else {
        $('#seccion_asignacion_tallas').slideUp(300);
    }
});

$(document).on('change', '#check_sastreria', function() {
    if ($(this).is(':checked')) {
        $('#seccion_sastreria').slideDown(300);
        if ($('#tbody_sastreria tr').length === 0 && typeof window.autogenerarSastreria === 'function') {
            let tieneNombres = false;
            $('.med-nombre').each(function() { if ($(this).val().trim() !== '') tieneNombres = true; });
            if (tieneNombres) window.autogenerarSastreria();
        }
    } else {
        $('#seccion_sastreria').slideUp(300);
    }
});

// ==============================================================================
// REVERTIR ORDEN A VENTAS (VECTOR 43)
// ==============================================================================
window.revertirOrden = function(id_orden) {
    Swal.fire({
        title: '¿Revertir Orden a Ventas?',
        html: "Esta acción <b>eliminará la orden de producción</b> actual y devolverá la cotización al vendedor.<br><br>Las últimas reglas de tallas, telas y diseños <b>se conservarán en la cotización</b> para que puedas revisarlas o corregirlas antes de generar otra orden.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Sí, Destruir y Revertir',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire({ title: 'Revertiendo...', allowOutsideClick: false, didOpen: () => { Swal.showLoading() } });
            $.post('api/api_ordenes.php', { accion: 'revertir_orden', id: id_orden }, function(res) {
                if(res.success) {
                    Swal.fire('¡Orden Revertida!', 'La orden fue eliminada y la cotización regresó a Ventas. Las últimas reglas se conservaron para su revisión.', 'success');
                    if (typeof window.cargarListaOrdenes === 'function') window.cargarListaOrdenes();
                    if (typeof window.chequearCotizacionesPendientes === 'function') window.chequearCotizacionesPendientes();
                } else {
                    Swal.fire('Error', res.msg, 'error');
                }
            }, 'json').fail(function() {
                Swal.fire('Error', 'Fallo de conexión con el servidor.', 'error');
            });
        }
    });
};