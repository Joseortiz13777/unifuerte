<?php
session_start();
session_write_close(); 
error_reporting(0);
require_once '../conexion.php';
require_once __DIR__ . '/portal_documento_auth.php';

if (!isset($_GET['id'])) {
    die("Acceso denegado.");
}

$id_orden = intval($_GET['id']);
$accesoPortal = validarTokenDocumentoPortal($conexion, 'orden', $id_orden);
if (!isset($_SESSION['usuario_id']) && !$accesoPortal) {
    http_response_code(isset($_GET['portal_token']) ? 403 : 401);
    die(isset($_GET['portal_token']) ? 'El enlace del portal venció o no corresponde a esta orden.' : 'Acceso denegado.');
}

// Usamos LEFT JOIN en caso de que el cliente o vendedor hayan sido borrados
$sql = "SELECT o.*, cli.nombre AS cliente_nombre, u.nombre AS v_nombre, u.apellido AS v_apellido
        FROM orden_fabrica o 
        LEFT JOIN cliente cli ON o.id_cliente = cli.ID 
        LEFT JOIN usuario u ON o.id_usuario_vendedor = u.ID
        WHERE o.ID = $id_orden";
$res = mysqli_query($conexion, $sql);
$orden = mysqli_fetch_assoc($res);

if(!$orden) die("Orden no encontrada.");

$vendedor = trim($orden['v_nombre'] . ' ' . $orden['v_apellido']);
if(empty($vendedor)) $vendedor = "Vendedor Eliminado";
$cliente_nombre = $orden['cliente_nombre'] ?? "Cliente Eliminado";

// ==============================================================================
// CÁLCULO ESTRICTO DE FECHAS (SOBRESCRIBE LA BASE DE DATOS A 20 DÍAS)
// ==============================================================================
$fecha_emision_val = $orden['fecha_emision'];
if (empty($fecha_emision_val) || strpos($fecha_emision_val, '0000') !== false || strpos($fecha_emision_val, '-0001') !== false) {
    $fecha_emision_mostrar = 'Por definir';
    $fecha_mostrar = 'Por definir'; 
} else {
    $fecha_emision_mostrar = date('d/m/Y', strtotime($fecha_emision_val));
    $fecha_mostrar = date('d/m/Y', strtotime($fecha_emision_val . ' + 20 days'));
}
// ==============================================================================

function es_prenda_fisica_orden($tipo_prenda) {
    $nombre = mb_strtolower(trim((string)$tipo_prenda), 'UTF-8');
    $conceptos_no_fisicos = [
        'arte final', 'bordado', 'vinil', 'dtf', 'serigraf', 'servicio',
        'matriz', 'ponchado', 'delivery', 'flete', 'descuento',
        'cobro adicional', 'parche',
        'empaque', 'impresion', 'impresión'
    ];

    if (strpos($nombre, 'diseño') === 0) return false;
    if (preg_match('/^tallas?\s+extras?\b/u', $nombre) === 1) return false;

    foreach ($conceptos_no_fisicos as $concepto) {
        if (strpos($nombre, $concepto) !== false) return false;
    }

    return $nombre !== '';
}

$q_det = mysqli_query($conexion, "
    SELECT d.*, m.nombre as tela_nombre, m.color as tela_color 
    FROM detalle_orden_fabrica d 
    LEFT JOIN materia_prima m ON d.id_materia = m.ID 
    WHERE d.id_orden_fabrica = $id_orden
");

$prendas = [];
$id_detalles = [];
$total_todas_prendas = 0;

// RECOPILACIÓN DE FOTOS PARA LA HOJA DE ANEXOS AL FINAL
$todas_las_fotos = [];
$fotos_array = [];
if (!empty($orden['foto'])) {
    $fotos_array = explode(',', $orden['foto']);
}

if (!empty($fotos_array)) {
    foreach($fotos_array as $img) {
        $img = trim($img);
        if(empty($img)) continue;
        
        $ruta_img = '../images/ordenes/' . $img; 
        if(!file_exists($ruta_img)) { $ruta_img = '../images/uploads/' . $img; }
        if(!file_exists($ruta_img)) { continue; }
        
        $todas_las_fotos[] = $ruta_img;
    }
}

// LOGICA DE FOTO PRINCIPAL PARA LA PAGINA 1
$primera_foto = '../img/unifuerte.jpg';
$primera_foto_es_referencia = false;
if (!empty($todas_las_fotos)) {
    foreach($todas_las_fotos as $ruta_img) {
        $ext = strtolower(pathinfo($ruta_img, PATHINFO_EXTENSION));
        if ($ext !== 'pdf') {
            $primera_foto = $ruta_img;
            $primera_foto_es_referencia = true;
            break; 
        }
    }
}

if (empty($todas_las_fotos)) {
    while($r = mysqli_fetch_assoc($q_det)) {
        if (!es_prenda_fisica_orden($r['tipo_prenda'])) continue;
        $nombre_limpio = preg_replace('/\s*\([^)]*\)$/', '', $r['tipo_prenda']);
        $q_foto = mysqli_query($conexion, "SELECT foto FROM productos WHERE nombre LIKE '%" . mysqli_real_escape_string($conexion, $nombre_limpio) . "%' AND foto IS NOT NULL LIMIT 1");
        if ($r_foto = mysqli_fetch_assoc($q_foto)) {
            if (file_exists('../../images/uploads/' . $r_foto['foto'])) {
                $ruta_cat = '../../images/uploads/' . $r_foto['foto'];
                $todas_las_fotos[] = $ruta_cat;
                if ($primera_foto === '../img/unifuerte.jpg') {
                    $primera_foto = $ruta_cat;
                    $primera_foto_es_referencia = true;
                }
            }
        }
    }
    mysqli_data_seek($q_det, 0); 
}

if (empty($todas_las_fotos)) {
    $todas_las_fotos[] = '../img/unifuerte.jpg';
}

$fotos_anexo = $todas_las_fotos;
if ($primera_foto_es_referencia) {
    $indiceFotoPrincipal = array_search($primera_foto, $fotos_anexo, true);
    if ($indiceFotoPrincipal !== false) {
        array_splice($fotos_anexo, $indiceFotoPrincipal, 1);
    }
}

while($r = mysqli_fetch_assoc($q_det)) {
    if (!es_prenda_fisica_orden($r['tipo_prenda'])) continue;
    $prendas[] = $r;
    $id_detalles[] = $r['ID'];
}

$mediciones = [];
$tiene_medidas_sastreria = false;

// INTENTO 1: BUSCAR MEDIDAS EN LA ORDEN DE FÁBRICA
if (!empty($id_detalles)) {
    $ids_str = implode(',', $id_detalles);
    $q_med = mysqli_query($conexion, "
        SELECT mp.*, d.tipo_prenda 
        FROM medicion_personal mp 
        JOIN detalle_orden_fabrica d ON mp.id_detalle_orden_fabrica = d.ID 
        WHERE mp.id_detalle_orden_fabrica IN ($ids_str) 
        ORDER BY mp.genero ASC, mp.nombre ASC
    ");
    while($m = mysqli_fetch_assoc($q_med)) {
        $mediciones[] = $m;
        $total_todas_prendas += intval($m['cantidad'] > 0 ? $m['cantidad'] : 1);
        if (
            floatval($m['hombro'] ?? 0) > 0 ||
            floatval($m['busto_torax'] ?? 0) > 0 ||
            floatval($m['cintura'] ?? 0) > 0 ||
            floatval($m['cadera'] ?? 0) > 0 ||
            floatval($m['largo_camisa'] ?? 0) > 0 ||
            floatval($m['largo_brazo'] ?? 0) > 0 ||
            floatval($m['largo_pantalon'] ?? 0) > 0 ||
            floatval($m['tiro_total'] ?? 0) > 0 ||
            floatval($m['ancho_muslo'] ?? 0) > 0 ||
            floatval($m['ancho_rodilla'] ?? 0) > 0 ||
            floatval($m['ancho_talon'] ?? 0) > 0
        ) {
            $tiene_medidas_sastreria = true; 
        }
    }
}

// ==============================================================================
// INTENTO 2: FALLBACK MÁGICO DE TALLAS
// Si la BD de 'medicion_personal' está vacía (por error de sincronización de la API), 
// jalamos las tallas directamente de la regla azul de la Cotización Original.
// ==============================================================================
if (empty($mediciones) && !empty($orden['id_cotizacion'])) {
    $id_cot = intval($orden['id_cotizacion']);
    $q_cot_det = mysqli_query($conexion, "SELECT * FROM detalle_cotizacion WHERE id_cotizacion = $id_cot");
    while ($cd = mysqli_fetch_assoc($q_cot_det)) {
        if (!es_prenda_fisica_orden($cd['tipo_prenda'])) continue;
        if (!empty($cd['especificaciones_tallas']) && $cd['especificaciones_tallas'] !== '[]') {
            $specs = json_decode($cd['especificaciones_tallas'], true);
            if (is_array($specs)) {
                foreach ($specs as $s) {
                    $medidas_personales = is_array($s['medidas_personales'] ?? null) ? $s['medidas_personales'] : [];
                    $medidas_personales = array_merge([
                        'hombro' => 0,
                        'busto_torax' => 0,
                        'cintura' => 0,
                        'cadera' => 0,
                        'largo_camisa' => 0,
                        'largo_brazo' => 0,
                        'largo_pantalon' => 0,
                        'tiro_total' => 0,
                        'ancho_muslo' => 0,
                        'ancho_rodilla' => 0,
                        'ancho_talon' => 0
                    ], $medidas_personales);
                    $mediciones[] = [
                        'tipo_prenda' => $cd['tipo_prenda'],
                        'nombre' => $s['nombre'] ?? '',
                        'genero' => $s['genero'] ?? 'No especificado',
                        'talla_asignada' => $s['talla'] ?? '',
                        'cantidad' => $s['cantidad'] ?? 1,
                        'tela' => $s['tela'] ?? '',
                        'observacion' => $s['obs'] ?? '',
                        'hombro' => floatval($medidas_personales['hombro']),
                        'busto_torax' => floatval($medidas_personales['busto_torax']),
                        'cintura' => floatval($medidas_personales['cintura']),
                        'cadera' => floatval($medidas_personales['cadera']),
                        'largo_camisa' => floatval($medidas_personales['largo_camisa']),
                        'largo_brazo' => floatval($medidas_personales['largo_brazo']),
                        'largo_pantalon' => floatval($medidas_personales['largo_pantalon']),
                        'tiro_total' => floatval($medidas_personales['tiro_total']),
                        'ancho_muslo' => floatval($medidas_personales['ancho_muslo']),
                        'ancho_rodilla' => floatval($medidas_personales['ancho_rodilla']),
                        'ancho_talon' => floatval($medidas_personales['ancho_talon'])
                    ];
                    foreach ($medidas_personales as $medida) {
                        if (floatval($medida) > 0) {
                            $tiene_medidas_sastreria = true;
                            break;
                        }
                    }
                    $total_todas_prendas += intval($s['cantidad'] > 0 ? $s['cantidad'] : 1);
                }
            }
        }
    }
}

// Si todo falla, contar solo las prendas generales
if (empty($mediciones)) {
    foreach($prendas as $p) { $total_todas_prendas += intval($p['cantidad']); }
}
// ==============================================================================

$artes_posiciones = [];
if (!empty($id_detalles)) {
    $ids_str = implode(',', $id_detalles);
    $q_pos = mysqli_query($conexion, "SELECT p.*, d.tipo_prenda FROM posicion p JOIN detalle_orden_fabrica d ON p.id_detalle_orden_fabrica = d.ID WHERE p.id_detalle_orden_fabrica IN ($ids_str)");
    while($pos = mysqli_fetch_assoc($q_pos)) {
        $artes_posiciones[] = "PRENDA: " . $pos['tipo_prenda'] . " - LLEVA: " . $pos['elemento'] . " EN UBICACIÓN: " . $pos['ubicacion'];
    }
}

// ARREGLOS DE TALLAS INDIVIDUALES
$tallas_infantil = ['2','4','6','8','10','12','14','16'];
$tallas_dama = ['XS','S','M','L','XL','2XL','3XL','4XL'];
$tallas_caballero = ['XS','S','M','L','XL','2XL','3XL','4XL','5XL'];

$colspan_infantil = count($tallas_infantil) + 1;
$colspan_dama = count($tallas_dama) + 1;
$colspan_caballero = count($tallas_caballero) + 1;

$resumen = ['Infantil' => [], 'Dama' => [], 'Caballero' => []];

foreach($mediciones as $m) {
    $gen = $m['genero'];
    $grupo = 'Caballero';
    
    if (strpos($gen, 'Dama') !== false) $grupo = 'Dama';
    if (strpos($gen, 'Niñ') !== false || stripos($m['tipo_prenda'], 'Infantil') !== false || stripos($m['tipo_prenda'], 'Juvenil') !== false) {
        $grupo = 'Infantil';
    }
    
    $prenda = $m['tipo_prenda'];
    $tela = !empty($m['tela']) ? $m['tela'] : 'No especificada';
    $talla = strtoupper(trim($m['talla_asignada']));
    $cant = intval($m['cantidad']);
    if ($cant <= 0) $cant = 1;

    $key = $prenda . '|' . $tela;

    if(!isset($resumen[$grupo][$key])) {
        $resumen[$grupo][$key] = [
            'descripcion' => $prenda,
            'tela' => $tela,
            'total' => 0,
            'tallas' => []
        ];
    }

    if(!isset($resumen[$grupo][$key]['tallas'][$talla])) {
        $resumen[$grupo][$key]['tallas'][$talla] = 0;
    }

    $resumen[$grupo][$key]['tallas'][$talla] += $cant;
    $resumen[$grupo][$key]['total'] += $cant;
}

$detalles_importantes = array_merge($artes_posiciones);
if (!empty($orden['descripcion'])) {
    array_unshift($detalles_importantes, "NOTA GLOBAL: " . $orden['descripcion']); 
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Orden de Fábrica <?= htmlspecialchars($orden['nro_orden_fabrica']) ?></title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        * {
            -webkit-print-color-adjust: exact !important; 
            print-color-adjust: exact !important; 
            box-sizing: border-box;
        }

        body { 
            background: #525659; 
            margin: 0; 
            font-family: 'Helvetica', 'Arial', sans-serif; 
            color: #000;
        }

        .top-bar {
            background-color: #13131A;
            padding: 15px;
            text-align: center;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
            box-shadow: 0 4px 6px rgba(0,0,0,0.3);
            display: flex;
            justify-content: center;
            gap: 15px;
        }

        .btn-print { 
            padding: 12px 30px; 
            font-size: 16px; 
            font-weight: bold; 
            background: #FF7518; 
            color: #FFF; 
            border: none; 
            cursor: pointer; 
            border-radius: 8px; 
            box-shadow: 0 4px 10px rgba(0,0,0,0.3); 
            transition: 0.3s;
        }
        .btn-print:hover { background: #e05e00; transform: scale(1.05); }

        .vista-previa {
            width: 100%;
            overflow-x: auto; 
            padding: 80px 10px 40px 10px; 
            text-align: center;
        }

        #documento_pdf {
            width: 790px; 
            max-width: 790px; 
            margin: 0 auto; 
            text-align: left;
            background: transparent;
        }

        .hoja-a4 { 
            background: white; 
            width: 100%; 
            padding: 20px; 
            box-shadow: 0 5px 15px rgba(0,0,0,0.5); 
            margin-bottom: 20px;
        }

        @media print { 
            @page { size: letter portrait; margin: 5mm; }
            body { background: white !important; padding: 0 !important; margin: 0 !important; display: block !important;}
            .vista-previa { padding: 0 !important; overflow: visible !important; }
            #documento_pdf { width: 100% !important; max-width: 100% !important; min-width: auto !important; margin: 0 !important; }
            .hoja-a4 { width: 100% !important; box-shadow: none !important; margin: 0 !important; padding: 10px !important; border: none !important; page-break-after: always; }
            .hoja-a4:last-child { page-break-after: auto; }
            .no-print { display: none !important; } 
        }
        
        .evitar-salto { page-break-inside: avoid; break-inside: avoid; }
        .anexo-titulo { page-break-after: avoid; break-after: avoid; }
        .anexo-imagen { page-break-inside: avoid; break-inside: avoid; }
        .anexo-imagen img { max-width: 100%; max-height: 220px; object-fit: contain; }
        
        table { width: 100%; border-collapse: collapse; border: 1px solid #000; margin-bottom: 0; page-break-inside: auto; }
        th, td { border: 1px solid #000; padding: 2px 4px; font-size: 10px; }
        tr { page-break-inside: avoid; break-inside: avoid; }
        thead { display: table-header-group; }
        tfoot { display: table-footer-group; }
        
        .header-main td { font-size: 11px; font-weight: bold; padding: 3px; }
        .logo-img { max-height: 45px; }
        
        .nro-box { color: #b30015; font-size: 20px !important; font-weight: 900 !important; text-align: center; vertical-align: middle;}
        
        .section-title { font-size: 12px; font-weight: bold; text-align: center; background-color: #f0f0f0; letter-spacing: 1px; padding: 4px; border: 2px solid #000; margin-top: 0; border-top: none;}
        .detalles-box { padding: 5px; font-size: 11px; font-weight: bold; text-align: left; text-transform: uppercase; min-height: 20px; border: 2px solid #000; border-top: none; }
        .nombres-table { width: 100%; border-collapse: collapse; border: 2px solid #000; border-top: none; }
        .nombres-table th { background-color: #ffc000 !important; font-weight: bold; text-align: center; border: 1px solid #000; padding: 3px; }
        .nombres-table td { font-weight: bold; font-size: 10px; border: 1px solid #000; padding: 3px; }
        .nombres-table td:last-child { text-align: right; }
        
        .bg-infantil { background-color: #f4b084 !important; font-weight: bold; text-align: center; color: #000; }
        .bg-dama { background-color: #e6a8d7 !important; font-weight: bold; text-align: center; color: #000; }
        .bg-caballero { background-color: #9dc3e6 !important; font-weight: bold; text-align: center; color: #000; }
        .bg-yellow { background-color: #ffc000 !important; font-weight: bold; text-align: center; }
        
        .talla-cell { text-align: center; font-weight: bold; font-size: 9px; width: 28px; padding: 2px; }
        .desc-cell { font-weight: bold; color: #600000; font-size: 9px; text-transform: uppercase; }
        .highlight-orange { background-color: #fce4d6 !important; } 
    </style>
</head>
<body>

    <div class="top-bar no-print">
        <button class="btn-print" style="background-color: #0B4C8C;" onclick="window.print()">🖨️ Imprimir Directo</button>
        <button id="btnDescargar" class="btn-print" onclick="descargarPDF()">📥 Descargar Hoja Producción PDF</button>
    </div>

    <div class="vista-previa">
        <div id="documento_pdf">
            
            <!-- PÁGINA 1: PRINCIPAL Y ESPECIFICACIONES -->
            <div class="hoja-a4">
                <table class="header-main" style="border: 2px solid #000;">
                    <tr>
                        <td style="width: 25%; text-align: center; padding: 5px;"><img src="../img/unifuerte.jpg" class="logo-img" alt="Unifuerte Logo"></td>
                        <td style="width: 50%; text-align: center; font-size: 13px; font-weight: 900;">ORDEN DE CORTE / SUBLIMACIÓN / CONFECCIÓN</td>
                        <td style="width: 25%;" class="nro-box">Nro. <?= htmlspecialchars(str_replace('OF-', '', $orden['nro_orden_fabrica'])) ?></td>
                    </tr>
                </table>

                <table class="header-main" style="border: 2px solid #000; border-top: none;">
                    <tr>
                        <td style="width: 50%;">Vendedor: <span style="font-weight: normal;"><?= htmlspecialchars($vendedor) ?></span></td>
                        <td style="width: 50%;">¿Es un Pedido Express?: <span style="font-weight: normal;"><?= $orden['es_express'] ? 'SÍ' : 'NO' ?></span></td>
                    </tr>
                    <tr>
                        <td>Cliente: <span style="font-weight: normal;"><?= htmlspecialchars($cliente_nombre) ?></span></td>
                        <td>¿Acepta Entregas Parciales?: <span style="font-weight: normal;"><?= $orden['acepta_entregas_parciales'] ? 'SÍ' : 'NO' ?></span></td>
                    </tr>
                    <tr>
                        <td>Etiquetas: <span style="font-weight: normal; color: #600000;">SENCAMER / TALLA</span></td>
                        <td>Código de Patrones a utilizar: <span style="font-weight: normal;"></span></td>
                    </tr>
                    <tr>
                        <td>Género: <span style="font-weight: normal; color: #600000;">CABALLEROS / DAMAS / INFANTIL</span></td>
                        <td>¿Hay tallas a la Medida?: <span style="font-weight: normal;"><?= $tiene_medidas_sastreria ? 'SÍ' : 'NO' ?></span></td>
                    </tr>
                    <!-- FECHAS INCLUIDAS LIMPIAMENTE EN EL ENCABEZADO -->
                    <tr>
                        <td style="background-color: #f0f0f0;">Fecha de Emisión: <span style="font-weight: bold; color: #0B4C8C;"><?= $fecha_emision_mostrar ?></span></td>
                        <td style="background-color: #f0f0f0;">Entrega Estimada (20 Días): <span style="font-weight: bold; color: #b30015;"><?= $fecha_mostrar ?></span></td>
                    </tr>
                </table>

                <?php if(!empty($detalles_importantes)): ?>
                    <div class="evitar-salto">
                        <div class="section-title">DETALLES IMPORTANTES DE ARTES Y NOTAS GENERALES</div>
                        <div class="detalles-box">
                            <?php foreach($detalles_importantes as $det): ?>
                                <?= htmlspecialchars($det) ?><br>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="evitar-salto">
                    <div class="section-title" style="border-top: none;">RESUMEN DE TALLAS SOLICITADAS</div>

                    <table style="width: 100%; border-collapse: collapse; border: 2px solid #000; border-top: none; margin-bottom: 0;">
                        <tr>
                            <td style="width: 65%; border: none; border-right: 2px solid #000; border-bottom: 2px solid #000; padding: 0; vertical-align: top;">
                                <table style="width: 100%; border: none; margin: 0; border-collapse: collapse;">
                                    <tr><td colspan="<?= $colspan_infantil ?>" class="bg-infantil" style="border-top: none; border-left: none;">PRODUCTO / CANTIDAD - INFANTIL - JUVENIL</td><td class="bg-yellow" style="width: 30px; border-top: none; border-right: none;">T</td></tr>
                                    <tr style="background-color: #f9f9f9;"><td class="desc-cell" style="text-align: center; border-left: none;">DESCRIPCIÓN Y TELA</td><?php foreach($tallas_infantil as $t): ?><td class="talla-cell"><?= $t ?></td><?php endforeach; ?><td class="bg-yellow" style="border-right: none;"></td></tr>
                                    <?php if(empty($resumen['Infantil'])) { echo '<tr><td class="desc-cell" style="border-left: none;">&nbsp;</td>'; foreach($tallas_infantil as $t) echo '<td></td>'; echo '<td class="bg-yellow" style="border-right: none;"></td></tr>'; } else { foreach($resumen['Infantil'] as $fila): ?>
                                    <tr>
                                        <td class="desc-cell" style="border-left: none;">
                                            <?= htmlspecialchars($fila['descripcion']) ?><br>
                                            <span style="color:#b30015; font-size:8px;">Tela: <?= htmlspecialchars($fila['tela']) ?></span>
                                        </td>
                                        <?php foreach($tallas_infantil as $t): ?><td class="talla-cell"><?= isset($fila['tallas'][$t]) && $fila['tallas'][$t] > 0 ? $fila['tallas'][$t] : '' ?></td><?php endforeach; ?>
                                        <td class="bg-yellow" style="border-right: none;"><?= $fila['total'] ?></td>
                                    </tr>
                                    <?php endforeach; } ?>

                                    <tr><td colspan="<?= $colspan_dama ?>" class="bg-dama" style="border-left: none;">PRODUCTO / CANTIDAD - DAMA</td><td class="bg-yellow" style="border-right: none;"></td></tr>
                                    <tr style="background-color: #f9f9f9;"><td class="desc-cell" style="text-align: center; border-left: none;">DESCRIPCIÓN Y TELA</td><?php foreach($tallas_dama as $t): ?><td class="talla-cell"><?= $t ?></td><?php endforeach; ?><td class="bg-yellow" style="border-right: none;"></td></tr>
                                    <?php if(empty($resumen['Dama'])) { echo '<tr><td class="desc-cell" style="border-left: none;">&nbsp;</td>'; foreach($tallas_dama as $t) echo '<td></td>'; echo '<td class="bg-yellow" style="border-right: none;"></td></tr>'; } else { foreach($resumen['Dama'] as $fila): ?>
                                    <tr>
                                        <td class="desc-cell" style="border-left: none;">
                                            <?= htmlspecialchars($fila['descripcion']) ?><br>
                                            <span style="color:#b30015; font-size:8px;">Tela: <?= htmlspecialchars($fila['tela']) ?></span>
                                        </td>
                                        <?php foreach($tallas_dama as $t): ?><td class="talla-cell"><?= isset($fila['tallas'][$t]) && $fila['tallas'][$t] > 0 ? $fila['tallas'][$t] : '' ?></td><?php endforeach; ?>
                                        <td class="bg-yellow" style="border-right: none;"><?= $fila['total'] ?></td>
                                    </tr>
                                    <?php endforeach; } ?>

                                    <tr><td colspan="<?= $colspan_caballero ?>" class="bg-caballero" style="border-left: none;">PRODUCTO / CANTIDAD - CABALLERO Y EXTRAS</td><td class="bg-yellow" style="border-right: none;"></td></tr>
                                    <tr style="background-color: #f9f9f9;"><td class="desc-cell" style="text-align: center; border-left: none;">DESCRIPCIÓN Y TELA</td><?php foreach($tallas_caballero as $t): ?><td class="talla-cell"><?= $t ?></td><?php endforeach; ?><td class="bg-yellow" style="border-right: none;"></td></tr>
                                    <?php if(empty($resumen['Caballero'])) { echo '<tr><td class="desc-cell" style="border-left: none;">&nbsp;</td>'; foreach($tallas_caballero as $t) echo '<td></td>'; echo '<td class="bg-yellow" style="border-right: none;"></td></tr>'; } else { foreach($resumen['Caballero'] as $fila): ?>
                                    <tr>
                                        <td class="desc-cell" style="border-left: none;">
                                            <?= htmlspecialchars($fila['descripcion']) ?><br>
                                            <span style="color:#b30015; font-size:8px;">Tela: <?= htmlspecialchars($fila['tela']) ?></span>
                                        </td>
                                        <?php foreach($tallas_caballero as $t): ?><td class="talla-cell"><?= isset($fila['tallas'][$t]) && $fila['tallas'][$t] > 0 ? $fila['tallas'][$t] : '' ?></td><?php endforeach; ?>
                                        <td class="bg-yellow" style="border-right: none;"><?= $fila['total'] ?></td>
                                    </tr>
                                    <?php endforeach; } ?>
                                    
                                    <tr>
                                        <td colspan="<?= $colspan_caballero ?>" style="text-align: right; font-weight: bold; font-size: 11px; border-left: none;">TOTAL GENERAL DE PIEZAS A CONFECCIONAR:</td>
                                        <td class="bg-yellow" style="font-size: 14px; border-right: none;"><?= $total_todas_prendas ?></td>
                                    </tr>
                                </table>
                            </td>
                            
                            <td style="width: 35%; border: none; border-right: 2px solid #000; border-bottom: 2px solid #000; padding: 5px; vertical-align: middle; text-align: center;">
                                <img src="<?= $primera_foto ?>" style="width: 100%; max-height: 250px; object-fit: contain; border-radius: 4px;">
                            </td>
                        </tr>
                    </table>
                </div>

                <div>
                    <table class="nombres-table">
                        <tr>
                            <th style="width: 5%;">CANT.</th>
                            <th style="width: 10%;">GÉNERO</th>
                            <th style="width: 10%;">TALLA</th>
                            <th style="width: 25%;">PRENDA Y TELA</th>
                            <th style="width: 25%;">NOMBRE</th>
                            <th style="width: 25%;">OBSERVACIÓN</th>
                        </tr>
                        <?php if(!empty($mediciones)): ?>
                            <?php foreach($mediciones as $m): ?>
                            <tr>
                                <td class="highlight-orange" style="text-align: center; font-size:12px;"><?= intval($m['cantidad']) > 0 ? $m['cantidad'] : 1 ?></td>
                                <td class="highlight-orange" style="text-align: center;"><?= htmlspecialchars($m['genero']) ?></td>
                                <td class="highlight-orange" style="text-align: center; font-size:12px;"><?= htmlspecialchars($m['talla_asignada']) ?></td>
                                <td style="text-align: left;">
                                    <?= htmlspecialchars($m['tipo_prenda']) ?><br>
                                    <span style="color:#b30015; font-size:8px;">Tela: <?= htmlspecialchars($m['tela']) ?></span>
                                </td>
                                <td><?= htmlspecialchars($m['nombre'] === '-' ? '' : $m['nombre']) ?></td>
                                <td><?= htmlspecialchars($m['observacion']) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="6" style="text-align: center; font-weight: normal;">No se registró listado para esta orden.</td></tr>
                        <?php endif; ?>
                    </table>
                </div>
            
            <!-- MEDIDAS DE SASTRERÍA INTEGRADAS A LA HOJA DE ESPECIFICACIONES -->
            <?php if($tiene_medidas_sastreria): ?>
                <div class="section-title" style="margin-top: 6px;">MEDIDAS EXACTAS DE SASTRERÍA — <?= htmlspecialchars($cliente_nombre) ?></div>
                
                <?php 
                $generos_sas = ['Dama' => 'bg-dama', 'Caballero' => 'bg-caballero', 'Niña' => 'bg-dama', 'Niño' => 'bg-caballero'];
                
                foreach($generos_sas as $gen => $claseCSS): 
                    $has_sup = false; 
                    $has_inf = false; 
                    $has_mid = false;

                    $med_sas = array_filter($mediciones, function($v) use ($gen, &$has_sup, &$has_inf, &$has_mid) { 
                        if ($v['genero'] != $gen) return false;
                        
                        $p = strtolower($v['tipo_prenda']);
                        $esPantalon = (strpos($p, 'pantalón') !== false || strpos($p, 'pantalon') !== false || strpos($p, 'mono') !== false || strpos($p, 'short') !== false || strpos($p, 'falda') !== false);
                        $esCamisa = (strpos($p, 'camis') !== false || strpos($p, 'chemis') !== false || strpos($p, 'chaqueta') !== false || strpos($p, 'jersey') !== false || strpos($p, 'filipina') !== false || strpos($p, 'bata') !== false || strpos($p, 'abrigo') !== false || strpos($p, 'chaleco') !== false);
                        $esAmbos = (strpos($p, 'braga') !== false || strpos($p, 'conjunto') !== false || (!$esPantalon && !$esCamisa));

                        $aplica_sup = ($esCamisa || $esAmbos);
                        $aplica_inf = ($esPantalon || $esAmbos);

                        if($aplica_sup && ($v['hombro']>0 || $v['busto_torax']>0 || $v['largo_camisa']>0 || $v['largo_brazo']>0)) { $has_sup = true; }
                        if($v['cintura']>0 || $v['cadera']>0) { $has_mid = true; }
                        if($aplica_inf && ($v['largo_pantalon']>0 || $v['tiro_total']>0 || $v['ancho_muslo']>0 || $v['ancho_rodilla']>0 || $v['ancho_talon']>0)) { $has_inf = true; }
                        
                        if (
                            floatval($v['hombro'] ?? 0) == 0 &&
                            floatval($v['busto_torax'] ?? 0) == 0 &&
                            floatval($v['cintura'] ?? 0) == 0 &&
                            floatval($v['cadera'] ?? 0) == 0 &&
                            floatval($v['largo_camisa'] ?? 0) == 0 &&
                            floatval($v['largo_brazo'] ?? 0) == 0 &&
                            floatval($v['largo_pantalon'] ?? 0) == 0 &&
                            floatval($v['tiro_total'] ?? 0) == 0 &&
                            floatval($v['ancho_muslo'] ?? 0) == 0 &&
                            floatval($v['ancho_rodilla'] ?? 0) == 0 &&
                            floatval($v['ancho_talon'] ?? 0) == 0
                        ) {
                            return false; 
                        }

                        if($aplica_sup) $has_sup = true;
                        if($aplica_inf) $has_inf = true;
                        $has_mid = true;

                        return true;
                    });

                    if(!empty($med_sas)):
                        $colspan_total = 4;
                        if($has_sup) $colspan_total += 4;
                        if($has_mid) $colspan_total += 2;
                        if($has_inf) $colspan_total += 5;
                ?>
                    <table style="width: 100%; border: 1px solid #000; border-collapse: collapse; margin-bottom: 5px; text-align: center; font-size: 8px;">
                        <thead>
                            <tr>
                                <td colspan="<?= $colspan_total ?>" class="<?= $claseCSS ?>" style="font-weight: bold; padding: 4px; border: 1px solid #000;">TALLAJE DE <?= strtoupper($gen) ?>S</td>
                            </tr>
                            <tr style="background-color: #f0f0f0;">
                                <th rowspan="2" style="border: 1px solid #000; padding: 3px;">Nro</th>
                                <th rowspan="2" style="border: 1px solid #000; padding: 3px;">Nombre Exacto</th>
                                <th rowspan="2" style="border: 1px solid #000; padding: 3px;">Prenda y Tela</th>
                                <th rowspan="2" style="border: 1px solid #000; padding: 3px;">Talla</th>
                                
                                <?php if($has_sup): ?><th colspan="4" style="border: 1px solid #000; background-color: #e6f0fa !important; padding: 3px;">Medidas Superiores</th><?php endif; ?>
                                <?php if($has_mid): ?><th colspan="2" style="border: 1px solid #000; background-color: #e2efda !important; padding: 3px;">Cintura/Cadera</th><?php endif; ?>
                                <?php if($has_inf): ?><th colspan="5" style="border: 1px solid #000; background-color: #fce4d6 !important; padding: 3px;">Medidas Inferiores (Pantalón)</th><?php endif; ?>
                            </tr>
                            <tr style="background-color: #f0f0f0;">
                                <?php if($has_sup): ?>
                                    <th style="border: 1px solid #000;">Hombro</th>
                                    <th style="border: 1px solid #000;"><?= ($gen == 'Dama' || $gen == 'Niña') ? 'Busto' : 'Tórax' ?></th>
                                    <th style="border: 1px solid #000;">L. Camisa</th>
                                    <th style="border: 1px solid #000;">L. Brazo</th>
                                <?php endif; ?>
                                <?php if($has_mid): ?>
                                    <th style="border: 1px solid #000;">Cintura</th>
                                    <th style="border: 1px solid #000;">Cadera</th>
                                <?php endif; ?>
                                <?php if($has_inf): ?>
                                    <th style="border: 1px solid #000; border-left: 2px solid #FF7518;">L. Pantalón</th>
                                    <th style="border: 1px solid #000;">Tiro</th>
                                    <th style="border: 1px solid #000;">Ancho Muslo</th>
                                    <th style="border: 1px solid #000;">Ancho Rodilla</th>
                                    <th style="border: 1px solid #000;">Ancho Talón</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i=1; foreach($med_sas as $per): 
                                $p_str = strtolower($per['tipo_prenda']);
                                $esPantalon = (strpos($p_str, 'pantalón') !== false || strpos($p_str, 'pantalon') !== false || strpos($p_str, 'mono') !== false || strpos($p_str, 'short') !== false || strpos($p_str, 'falda') !== false);
                                $esCamisa = (strpos($p_str, 'camis') !== false || strpos($p_str, 'chemis') !== false || strpos($p_str, 'chaqueta') !== false || strpos($p_str, 'jersey') !== false || strpos($p_str, 'filipina') !== false || strpos($p_str, 'bata') !== false || strpos($p_str, 'abrigo') !== false || strpos($p_str, 'chaleco') !== false);
                                $esAmbos = (strpos($p_str, 'braga') !== false || strpos($p_str, 'conjunto') !== false || (!$esPantalon && !$esCamisa));
                            ?>
                            <tr>
                                <td style="border: 1px solid #000; padding: 3px;"><?= $i++ ?></td>
                                <td style="border: 1px solid #000; padding: 3px; font-weight:bold; text-align: left;"><?= htmlspecialchars($per['nombre']) ?></td>
                                <td style="border: 1px solid #000; padding: 3px; text-align: left;">
                                    <?= htmlspecialchars($per['tipo_prenda']) ?><br>
                                    <span style="color:#b30015; font-size:8px;">Tela: <?= htmlspecialchars($per['tela']) ?></span>
                                </td>
                                <td style="border: 1px solid #000; padding: 3px; font-weight:bold;"><?= htmlspecialchars($per['talla_asignada']) ?></td>
                                
                                <?php if($has_sup): ?>
                                    <td style="border: 1px solid #000; padding: 3px; background-color:<?= ($esCamisa||$esAmbos)?'#fff':'#e9ecef !important' ?>"><?= ($esCamisa||$esAmbos) && $per['hombro'] > 0 ? $per['hombro'] : '-' ?></td>
                                    <td style="border: 1px solid #000; padding: 3px; background-color:<?= ($esCamisa||$esAmbos)?'#fff':'#e9ecef !important' ?>"><?= ($esCamisa||$esAmbos) && $per['busto_torax'] > 0 ? $per['busto_torax'] : '-' ?></td>
                                    <td style="border: 1px solid #000; padding: 3px; background-color:<?= ($esCamisa||$esAmbos)?'#fff':'#e9ecef !important' ?>"><?= ($esCamisa||$esAmbos) && $per['largo_camisa'] > 0 ? $per['largo_camisa'] : '-' ?></td>
                                    <td style="border: 1px solid #000; padding: 3px; background-color:<?= ($esCamisa||$esAmbos)?'#fff':'#e9ecef !important' ?>"><?= ($esCamisa||$esAmbos) && $per['largo_brazo'] > 0 ? $per['largo_brazo'] : '-' ?></td>
                                <?php endif; ?>
                                
                                <?php if($has_mid): ?>
                                    <td style="border: 1px solid #000; padding: 3px;"><?= $per['cintura'] > 0 ? $per['cintura'] : '-' ?></td>
                                    <td style="border: 1px solid #000; padding: 3px;"><?= $per['cadera'] > 0 ? $per['cadera'] : '-' ?></td>
                                <?php endif; ?>

                                <?php if($has_inf): ?>
                                    <td style="border: 1px solid #000; padding: 3px; border-left: 2px solid #FF7518; background-color:<?= ($esPantalon||$esAmbos)?'#fff':'#e9ecef !important' ?>"><?= ($esPantalon||$esAmbos) && $per['largo_pantalon'] > 0 ? $per['largo_pantalon'] : '-' ?></td>
                                    <td style="border: 1px solid #000; padding: 3px; background-color:<?= ($esPantalon||$esAmbos)?'#fff':'#e9ecef !important' ?>"><?= ($esPantalon||$esAmbos) && $per['tiro_total'] > 0 ? $per['tiro_total'] : '-' ?></td>
                                    <td style="border: 1px solid #000; padding: 3px; background-color:<?= ($esPantalon||$esAmbos)?'#fff':'#e9ecef !important' ?>"><?= ($esPantalon||$esAmbos) && $per['ancho_muslo'] > 0 ? $per['ancho_muslo'] : '-' ?></td>
                                    <td style="border: 1px solid #000; padding: 3px; background-color:<?= ($esPantalon||$esAmbos)?'#fff':'#e9ecef !important' ?>"><?= ($esPantalon||$esAmbos) && $per['ancho_rodilla'] > 0 ? $per['ancho_rodilla'] : '-' ?></td>
                                    <td style="border: 1px solid #000; padding: 3px; background-color:<?= ($esPantalon||$esAmbos)?'#fff':'#e9ecef !important' ?>"><?= ($esPantalon||$esAmbos) && $per['ancho_talon'] > 0 ? $per['ancho_talon'] : '-' ?></td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; endforeach; ?>
            <?php endif; ?>
            <?php if(count($fotos_anexo) > 0): ?>
                <div class="anexo-titulo section-title" style="margin-top: 12px;">REFERENCIAS GRÁFICAS ADICIONALES DEL DISEÑO</div>
                <div style="display: flex; flex-wrap: wrap; gap: 10px; justify-content: center; padding: 8px 0;">
                <?php foreach($fotos_anexo as $ruta_img):
                    $ext = strtolower(pathinfo($ruta_img, PATHINFO_EXTENSION));
                    if ($ext === 'pdf'): ?>
                        <div class="anexo-imagen" style="width: 100%; border: 2px dashed #0B4C8C; padding: 10px; border-radius: 8px; background-color: #f0f8ff; text-align: center; margin-bottom: 8px;">
                            <a href="<?= $ruta_img ?>" target="_blank" style="font-size: 16px; font-weight: bold; color: #0B4C8C; text-decoration: none;">📄 Documento PDF Adjunto (Clic para ver original)</a>
                        </div>
                    <?php else: ?>
                        <div class="anexo-imagen" style="width: 45%; border: 1px solid #ccc; padding: 4px; border-radius: 8px; text-align: center; background-color: #fff; box-shadow: 2px 2px 5px rgba(0,0,0,0.1);">
                            <img src="<?= $ruta_img ?>" alt="Referencia adicional del diseño" style="border-radius: 4px;">
                        </div>
                    <?php endif; 
                endforeach; ?>
                </div>
            <?php endif; ?>

            </div>
        </div>
    </div>

    <script>
    function descargarPDF() {
        const btn = document.getElementById('btnDescargar');
        btn.innerHTML = '⏳ Generando PDF...';
        btn.disabled = true;

        const elemento = document.getElementById('documento_pdf');
        
        const hojas = document.querySelectorAll('.hoja-a4');
        hojas.forEach(h => { 
            h.style.boxShadow = 'none'; 
            h.style.marginBottom = '0'; 
            h.style.border = 'none';
            h.style.padding = '0';
        });

        const opciones = {
            margin:       [5, 5, 5, 5], 
            filename:     'Orden_<?= str_replace("OF-", "", $orden["nro_orden_fabrica"]) ?>.pdf',
            image:        { type: 'jpeg', quality: 0.98 },
            html2canvas:  { scale: 2, useCORS: true }, 
            jsPDF:        { unit: 'mm', format: 'letter', orientation: 'portrait' },
            pagebreak:    { mode: ['css', 'legacy'] }
        };

        html2pdf().set(opciones).from(elemento).save().then(() => {
            btn.innerHTML = '📥 Descargar Hoja Producción PDF';
            btn.disabled = false;
            
            hojas.forEach(h => { 
                h.style.boxShadow = '0 5px 15px rgba(0,0,0,0.5)'; 
                h.style.marginBottom = '20px'; 
                h.style.padding = '20px';
            });
        });
    }
    </script>
</body>
</html>