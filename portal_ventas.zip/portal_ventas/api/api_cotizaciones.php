<?php
session_start();
error_reporting(0);
require_once '../../conexion.php';
require_once '../../garantia_textil.php';

// LIBERAMOS LA SESIÓN INMEDIATAMENTE PARA QUE EL SISTEMA NUNCA SE PONGA LENTO
$id_usuario = isset($_SESSION['usuario_id']) ? intval($_SESSION['usuario_id']) : 0;
session_write_close(); 

header('Content-Type: application/json; charset=utf-8');

if ($id_usuario === 0) {
    ob_clean();
    echo json_encode(['success' => false, 'msg' => 'Sesión expirada']); 
    exit;
}

// AUTO-PARCHE DE BASE DE DATOS
mysqli_query($conexion, "ALTER TABLE cotizacion ADD COLUMN IF NOT EXISTS noti_wa INT DEFAULT 0");
mysqli_query($conexion, "ALTER TABLE cotizacion ADD COLUMN IF NOT EXISTS pausado TINYINT(1) DEFAULT 0");
mysqli_query($conexion, "ALTER TABLE cotizacion ADD COLUMN IF NOT EXISTS prealerta_produccion TINYINT NOT NULL DEFAULT 0 COMMENT '0 sin prealerta, 1 pendiente, 2 revisada'");
mysqli_query($conexion, "ALTER TABLE cotizacion ADD COLUMN IF NOT EXISTS comision_descuento_prestamo DECIMAL(15,2) NOT NULL DEFAULT 0.00");
mysqli_query($conexion, "ALTER TABLE cotizacion ADD COLUMN IF NOT EXISTS comision_pago_neto DECIMAL(15,2) NOT NULL DEFAULT 0.00");
mysqli_query($conexion, "ALTER TABLE cotizacion ADD COLUMN IF NOT EXISTS pago_retenciones TEXT DEFAULT NULL");
mysqli_query($conexion, "ALTER TABLE cotizacion ADD COLUMN IF NOT EXISTS cuenta_por_cobrar TINYINT(1) NOT NULL DEFAULT 0");
mysqli_query($conexion, "
    CREATE TABLE IF NOT EXISTS nomina_prestamos_vendedores (
        id INT AUTO_INCREMENT PRIMARY KEY,
        id_vendedor INT NOT NULL,
        monto_original DECIMAL(15,2) NOT NULL,
        saldo_pendiente DECIMAL(15,2) NOT NULL,
        concepto VARCHAR(255) NOT NULL,
        fecha DATE NOT NULL,
        moneda VARCHAR(10) NOT NULL DEFAULT 'USD',
        tasa_bcv DECIMAL(15,4) NOT NULL DEFAULT 0.00,
        estado VARCHAR(20) NOT NULL DEFAULT 'Pendiente',
        KEY idx_vendedor_estado (id_vendedor, estado)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");
mysqli_query($conexion, "
    CREATE TABLE IF NOT EXISTS nomina_prestamo_vendedor_abonos (
        id INT AUTO_INCREMENT PRIMARY KEY,
        id_cotizacion INT NOT NULL,
        id_prestamo INT NOT NULL,
        id_vendedor INT NOT NULL,
        monto DECIMAL(15,2) NOT NULL,
        fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_comision_prestamo (id_cotizacion, id_prestamo),
        KEY idx_vendedor_fecha (id_vendedor, fecha)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");
mysqli_query($conexion, "
    CREATE TABLE IF NOT EXISTS factura_fiscal_secuencia (
        id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
        siguiente_numero BIGINT UNSIGNED NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");
mysqli_query($conexion, "
    CREATE TABLE IF NOT EXISTS factura_fiscal_cotizacion (
        id INT AUTO_INCREMENT PRIMARY KEY,
        id_cotizacion INT NOT NULL,
        numero_factura BIGINT UNSIGNED NOT NULL UNIQUE,
        numero_control VARCHAR(60) NOT NULL,
        tasa_bcv DECIMAL(15,4) NOT NULL,
        id_usuario INT NOT NULL,
        fecha_emision DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        numero_orden_compra VARCHAR(100) DEFAULT NULL,
        estado VARCHAR(20) NOT NULL DEFAULT 'Activa',
        motivo_anulacion VARCHAR(255) DEFAULT NULL,
        fecha_anulacion DATETIME DEFAULT NULL,
        id_usuario_anulo INT DEFAULT NULL,
        KEY idx_cotizacion_estado (id_cotizacion, estado)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");
// Migrar tabla si aún tiene id_cotizacion como PRIMARY KEY único (permite múltiples facturas por cotización si se anulan)
$q_col_id_fac = mysqli_query($conexion, "SHOW COLUMNS FROM factura_fiscal_cotizacion LIKE 'id'");
if ($q_col_id_fac && mysqli_num_rows($q_col_id_fac) === 0) {
    mysqli_query($conexion, "ALTER TABLE factura_fiscal_cotizacion DROP PRIMARY KEY, ADD COLUMN id INT AUTO_INCREMENT PRIMARY KEY FIRST, ADD INDEX idx_id_cotizacion (id_cotizacion)");
}
mysqli_query($conexion, "ALTER TABLE factura_fiscal_cotizacion ADD COLUMN IF NOT EXISTS numero_orden_compra VARCHAR(100) DEFAULT NULL");
mysqli_query($conexion, "ALTER TABLE factura_fiscal_cotizacion ADD COLUMN IF NOT EXISTS estado VARCHAR(20) NOT NULL DEFAULT 'Activa'");
mysqli_query($conexion, "ALTER TABLE factura_fiscal_cotizacion ADD COLUMN IF NOT EXISTS motivo_anulacion VARCHAR(255) DEFAULT NULL");
mysqli_query($conexion, "ALTER TABLE factura_fiscal_cotizacion ADD COLUMN IF NOT EXISTS fecha_anulacion DATETIME DEFAULT NULL");
mysqli_query($conexion, "ALTER TABLE factura_fiscal_cotizacion ADD COLUMN IF NOT EXISTS id_usuario_anulo INT DEFAULT NULL");
mysqli_query($conexion, "INSERT IGNORE INTO factura_fiscal_secuencia (id, siguiente_numero) VALUES (1, 290)");

$q_usr = mysqli_query($conexion, "SELECT permisos, rol FROM usuario WHERE ID = $id_usuario");
$datos_usr = mysqli_fetch_assoc($q_usr);
$permisos_arr = explode(',', $datos_usr['permisos'] ?? '');
$rol_actual = strtolower(trim($datos_usr['rol'] ?? ''));

$puede_ver_propias = in_array('6', $permisos_arr);
$puede_ver_todas = in_array('7', $permisos_arr);
$puede_editar = in_array('8', $permisos_arr);
$puede_eliminar = in_array('9', $permisos_arr);
$puede_comisiones = in_array('35', $permisos_arr); 
$es_master = $rol_actual === 'master';

function parsearSeriePagosCotizacion($valor): array {
    $texto = str_replace(['ert{}', '<br>', '<br/>', '<br />', "\r", "\n"], '|', (string)$valor);
    return preg_split('/\s*\|\s*/', trim($texto, " |\t\n\r\0\x0B"), -1, PREG_SPLIT_NO_EMPTY) ?: [];
}

function totalRetencionesUsdCotizacion($retencionesJson, $tasa): ?float {
    $retencionesJson = trim((string)$retencionesJson);
    if ($retencionesJson === '') {
        return 0.0;
    }
    $retencionesRaiz = json_decode($retencionesJson);
    if (!is_array($retencionesRaiz) || json_last_error() !== JSON_ERROR_NONE) {
        error_log('Ventas: datos de retenciones con formato inválido.');
        return null;
    }
    $retenciones = json_decode($retencionesJson, true);

    $totalUsd = 0.0;
    foreach ($retenciones as $retencion) {
        if (!is_array($retencion)) {
            error_log('Ventas: un registro de retención tiene un formato inválido.');
            return null;
        }
        $tasaItem = (float)$tasa > 0 ? (float)$tasa : (float)($retencion['tasa_bcv'] ?? 0);
        $montoRegistro = 0.0;
        foreach (['iva_bs', 'islr_bs', 'municipal_bs'] as $campo) {
            $valor = $retencion[$campo] ?? 0;
            if (!is_numeric($valor) || !is_finite((float)$valor) || (float)$valor < 0) {
                error_log('Ventas: un monto de retención tiene un valor inválido.');
                return null;
            }
            $montoRegistro += (float)$valor;
        }
        if ($montoRegistro > 0 && $tasaItem <= 0) {
            error_log('Ventas: un registro de retención no tiene tasa BCV válida.');
            return null;
        }
        if ($tasaItem > 0) {
            $totalUsd += $montoRegistro / $tasaItem;
        }
    }
    return round($totalUsd, 2);
}

function registrar_auditoria($con, $id_usr, $accion, $tabla, $id_reg, $detalle) {
    $acc = mysqli_real_escape_string($con, $accion);
    $tab = mysqli_real_escape_string($con, $tabla);
    $det = mysqli_real_escape_string($con, $detalle);
    mysqli_query($con, "INSERT INTO historial_actividad (id_usuario, accion, tabla_afectada, id_registro_afectado, fecha_hora, detalle_cambio) VALUES ($id_usr, '$acc', '$tab', $id_reg, NOW(), '$det')");
}

function es_cargo_talla_extra_cotizacion($tipo_prenda): bool {
    return preg_match('/^tallas?\s+extras?\b/i', trim((string)$tipo_prenda)) === 1;
}

function genero_especificacion_valido_cotizacion($tipo_prenda, $genero): bool {
    $genero = trim((string)$genero);
    $nombre = mb_strtolower(trim((string)$tipo_prenda), 'UTF-8');
    if (strpos($nombre, 'gorra') !== false || strpos($nombre, 'visera') !== false || strpos($nombre, 'vicera') !== false) {
        return $genero === 'Accesorio';
    }
    if (strpos($nombre, 'bota') !== false) {
        return $genero === 'No aplica';
    }
    return in_array($genero, ['Dama', 'Caballero', 'Niña', 'Niño'], true);
}

function obtener_tela_base_cotizacion($detalle_diseno): string {
    if (!preg_match('/\bTela:\s*([^|]+)/i', (string)$detalle_diseno, $matches)) {
        return '';
    }

    $tela = trim($matches[1]);
    return in_array(mb_strtolower($tela, 'UTF-8'), ['n/a', 'no aplica', 'no especificada'], true) ? '' : $tela;
}

function validar_especificaciones_cotizacion(mysqli $conexion, int $id_cotizacion): array {
    $q = mysqli_query($conexion, "
        SELECT tipo_prenda, cantidad, detalle_diseno, especificaciones_tallas
        FROM detalle_cotizacion
        WHERE id_cotizacion = $id_cotizacion
    ");
    if (!$q) {
        return ['success' => false, 'msg' => 'No se pudieron revisar las reglas de la cotización.'];
    }

    $errores = [];
    while ($detalle = mysqli_fetch_assoc($q)) {
        if (
            stripos($detalle['detalle_diseno'] ?? '', 'Ubicación:') !== false
            || preg_match('/^(bordado|serigraf|dtf|vinil)/i', trim((string)($detalle['tipo_prenda'] ?? ''))) === 1
            || es_cargo_talla_extra_cotizacion($detalle['tipo_prenda'])
        ) {
            continue;
        }

        $nombre = trim($detalle['tipo_prenda'] ?? '') ?: 'Renglón sin descripción';
        $esperado = intval($detalle['cantidad'] ?? 0);
        $tela_base = obtener_tela_base_cotizacion($detalle['detalle_diseno'] ?? '');
        $specs = json_decode($detalle['especificaciones_tallas'] ?? '', true);
        if (!is_array($specs) || count($specs) === 0) {
            $errores[] = "$nombre: faltan tallas y telas.";
            continue;
        }

        $asignado = 0;
        $fila_incompleta = false;
        foreach ($specs as $spec) {
            if (!is_array($spec)) {
                $fila_incompleta = true;
                continue;
            }
            $cantidad = intval($spec['cantidad'] ?? 0);
            $asignado += $cantidad;
            if (
                $cantidad < 1
                || trim((string)($spec['talla'] ?? '')) === ''
                || trim((string)($spec['tela'] ?? '')) === ''
                || !genero_especificacion_valido_cotizacion($detalle['tipo_prenda'], $spec['genero'] ?? '')
                || ($tela_base !== '' && mb_strtolower(trim((string)$spec['tela']), 'UTF-8') !== mb_strtolower($tela_base, 'UTF-8'))
            ) {
                $fila_incompleta = true;
            }
        }

        if ($fila_incompleta) {
            $errores[] = $tela_base !== ''
                ? "$nombre: completa género, cantidad y talla, y usa la tela cotizada ($tela_base) en cada línea."
                : "$nombre: completa género, cantidad, talla y tela en cada línea.";
        } elseif ($asignado !== $esperado) {
            $errores[] = "$nombre: las tallas suman $asignado y la cotización requiere $esperado.";
        }
    }

    return empty($errores)
        ? ['success' => true, 'msg' => '']
        : ['success' => false, 'msg' => "Revisa nuevamente las reglas azules antes de enviar a logística:\n- " . implode("\n- ", $errores)];
}

function buscarUsuarioVendedorDeCotizacion($conexion, $idCotizacion) {
    $idCotizacion = intval($idCotizacion);
    $qVendedor = mysqli_query($conexion, "
        SELECT u.ID, u.rol, u.nombre, u.apellido
        FROM cotizacion c
        LEFT JOIN usuario u ON u.ID = c.id_vendedor
        WHERE c.ID = $idCotizacion
    ");
    if (!$qVendedor || !($vendedor = mysqli_fetch_assoc($qVendedor))) {
        return ['success' => false, 'msg' => 'No se pudo obtener el vendedor de la cotización.'];
    }
    if (empty($vendedor['ID']) || !in_array(strtolower($vendedor['rol'] ?? ''), ['ventas', 'jefe_ventas'], true)) {
        return [
            'success' => true,
            'encontrado' => false,
            'saldo' => 0.0,
            'vendedor' => trim(($vendedor['nombre'] ?? '') . ' ' . ($vendedor['apellido'] ?? ''))
        ];
    }

    $qSaldo = mysqli_query($conexion, "
        SELECT COALESCE(SUM(saldo_pendiente), 0) AS saldo
        FROM nomina_prestamos_vendedores
        WHERE id_vendedor = " . intval($vendedor['ID']) . "
          AND estado = 'Pendiente'
          AND saldo_pendiente > 0
    ");
    if (!$qSaldo || !($saldo = mysqli_fetch_assoc($qSaldo))) {
        return ['success' => false, 'msg' => 'No se pudo consultar el saldo pendiente del préstamo.'];
    }

    return [
        'success' => true,
        'encontrado' => true,
        'id_vendedor' => intval($vendedor['ID']),
        'saldo' => round((float)$saldo['saldo'], 2),
        'vendedor' => trim(($vendedor['nombre'] ?? '') . ' ' . ($vendedor['apellido'] ?? ''))
    ];
}

$accion = $_POST['accion'] ?? $_GET['accion'] ?? '';

if ($accion === 'obtener_factura_fiscal') {
    if (!$puede_ver_propias && !$puede_ver_todas) {
        echo json_encode(['success' => false, 'msg' => 'No tienes permiso para facturar cotizaciones.']);
        exit;
    }
    $id_cotizacion = intval($_POST['id'] ?? 0);
    $q_cotizacion = mysqli_query($conexion, "
        SELECT ID, id_vendedor, tipo_cotizacion
        FROM cotizacion
        WHERE ID = $id_cotizacion
        LIMIT 1
    ");
    $cotizacion = $q_cotizacion ? mysqli_fetch_assoc($q_cotizacion) : null;
    if (!$cotizacion) {
        echo json_encode(['success' => false, 'msg' => 'No se encontró la cotización seleccionada.']);
        exit;
    }
    if (!$puede_ver_todas && intval($cotizacion['id_vendedor']) !== $id_usuario) {
        echo json_encode(['success' => false, 'msg' => 'No tienes permiso para facturar esta cotización.']);
        exit;
    }
    if (($cotizacion['tipo_cotizacion'] ?? '') === 'MUESTRA') {
        echo json_encode(['success' => false, 'msg' => 'Las muestras físicas no admiten factura fiscal.']);
        exit;
    }

    $q_factura = mysqli_query($conexion, "
        SELECT numero_factura, numero_control, tasa_bcv, numero_orden_compra, estado, motivo_anulacion, fecha_emision, fecha_anulacion
        FROM factura_fiscal_cotizacion
        WHERE id_cotizacion = $id_cotizacion
        ORDER BY numero_factura DESC
    ");
    if (!$q_factura) {
        echo json_encode(['success' => false, 'msg' => 'No se pudo consultar el registro de facturación.']);
        exit;
    }
    $factura_activa = null;
    $anuladas = [];
    while ($fila_fac = mysqli_fetch_assoc($q_factura)) {
        $item_fac = [
            'numero_raw' => intval($fila_fac['numero_factura']),
            'numero' => str_pad((string)$fila_fac['numero_factura'], 8, '0', STR_PAD_LEFT),
            'control' => $fila_fac['numero_control'],
            'tasa' => $fila_fac['tasa_bcv'],
            'orden_compra' => $fila_fac['numero_orden_compra'] ?? '',
            'estado' => $fila_fac['estado'] ?? 'Activa',
            'motivo_anulacion' => $fila_fac['motivo_anulacion'] ?? '',
            'fecha_emision' => !empty($fila_fac['fecha_emision']) ? date('d/m/Y H:i', strtotime($fila_fac['fecha_emision'])) : '',
            'fecha_anulacion' => !empty($fila_fac['fecha_anulacion']) ? date('d/m/Y H:i', strtotime($fila_fac['fecha_anulacion'])) : ''
        ];
        if (strtoupper($item_fac['estado']) === 'ANULADA') {
            $anuladas[] = $item_fac;
        } elseif ($factura_activa === null) {
            $factura_activa = $item_fac;
        }
    }

    echo json_encode([
        'success' => true,
        'data' => $factura_activa,
        'anuladas' => $anuladas
    ]);
    exit;
}

if ($accion === 'anular_factura_fiscal') {
    if (!$puede_editar && !$es_master && !$puede_ver_todas) {
        echo json_encode(['success' => false, 'msg' => 'No tienes permiso para anular facturas fiscales.']);
        exit;
    }
    $id_cotizacion = intval($_POST['id'] ?? 0);
    $numero_factura = intval($_POST['numero_factura'] ?? 0);
    $motivo = trim((string)($_POST['motivo'] ?? ''));
    if ($id_cotizacion <= 0) {
        echo json_encode(['success' => false, 'msg' => 'Cotización inválida.']);
        exit;
    }
    if ($motivo === '') {
        $motivo = 'Anulada por el usuario';
    }

    mysqli_begin_transaction($conexion);
    $cond_num = $numero_factura > 0 ? "AND numero_factura = $numero_factura" : "";
    $q_fac = mysqli_query($conexion, "
        SELECT numero_factura
        FROM factura_fiscal_cotizacion
        WHERE id_cotizacion = $id_cotizacion AND (estado IS NULL OR estado = 'Activa') $cond_num
        ORDER BY numero_factura DESC
        LIMIT 1
        FOR UPDATE
    ");
    $fac_row = $q_fac ? mysqli_fetch_assoc($q_fac) : null;
    if (!$fac_row) {
        mysqli_rollback($conexion);
        echo json_encode(['success' => false, 'msg' => 'No se encontró una factura activa para anular en esta cotización.']);
        exit;
    }
    $num_anular = intval($fac_row['numero_factura']);
    $motivo_sql = mysqli_real_escape_string($conexion, mb_substr($motivo, 0, 250, 'UTF-8'));

    $upd = mysqli_query($conexion, "
        UPDATE factura_fiscal_cotizacion
        SET estado = 'Anulada',
            motivo_anulacion = '$motivo_sql',
            fecha_anulacion = NOW(),
            id_usuario_anulo = $id_usuario
        WHERE id_cotizacion = $id_cotizacion AND numero_factura = $num_anular
    ");
    if (!$upd || !mysqli_commit($conexion)) {
        mysqli_rollback($conexion);
        echo json_encode(['success' => false, 'msg' => 'No se pudo anular la factura fiscal.']);
        exit;
    }

    $num_fmt = str_pad((string)$num_anular, 8, '0', STR_PAD_LEFT);
    registrar_auditoria(
        $conexion,
        $id_usuario,
        'ANULAR',
        'factura_fiscal_cotizacion',
        $id_cotizacion,
        "Anuló la factura fiscal N° $num_fmt de la cotización ID $id_cotizacion. Motivo: $motivo"
    );

    echo json_encode([
        'success' => true,
        'numero_anulado' => $num_fmt,
        'msg' => "La factura N° $num_fmt fue marcada como ANULADA. El registro queda guardado en el historial y la cotización continúa libre para emitir una nueva factura."
    ]);
    exit;
}

if ($accion === 'guardar_orden_compra_factura_final') {
    if (!$puede_ver_propias && !$puede_ver_todas) {
        echo json_encode(['success' => false, 'msg' => 'No tienes permiso para facturar cotizaciones.']);
        exit;
    }
    $id_cotizacion = intval($_POST['id'] ?? 0);
    $ordenCompra = trim((string)($_POST['orden_compra'] ?? ''));
    if ($ordenCompra === '') {
        $ordenCompra = 'S/N';
    }
    if ($id_cotizacion <= 0 || mb_strlen($ordenCompra, 'UTF-8') > 100) {
        echo json_encode(['success' => false, 'msg' => 'El número de orden de compra no puede superar 100 caracteres.']);
        exit;
    }
    $q_cotizacion = mysqli_query($conexion, "
        SELECT c.id_vendedor, c.tipo_cotizacion, f.numero_factura
        FROM cotizacion c
        LEFT JOIN factura_fiscal_cotizacion f ON f.id_cotizacion = c.ID AND (f.estado IS NULL OR f.estado = 'Activa')
        WHERE c.ID = $id_cotizacion
        LIMIT 1
    ");
    $cotizacion = $q_cotizacion ? mysqli_fetch_assoc($q_cotizacion) : null;
    if (!$cotizacion || $cotizacion['numero_factura'] === null) {
        echo json_encode(['success' => false, 'msg' => 'Primero debes emitir la factura fiscal activa de esta cotización.']);
        exit;
    }
    if (!$puede_ver_todas && intval($cotizacion['id_vendedor']) !== $id_usuario) {
        echo json_encode(['success' => false, 'msg' => 'No tienes permiso para facturar esta cotización.']);
        exit;
    }
    if (($cotizacion['tipo_cotizacion'] ?? '') === 'MUESTRA') {
        echo json_encode(['success' => false, 'msg' => 'Las muestras físicas no admiten factura fiscal.']);
        exit;
    }
    $ordenCompraSql = mysqli_real_escape_string($conexion, $ordenCompra);
    $numFacActiva = intval($cotizacion['numero_factura']);
    if (!mysqli_query($conexion, "UPDATE factura_fiscal_cotizacion SET numero_orden_compra = '$ordenCompraSql' WHERE id_cotizacion = $id_cotizacion AND numero_factura = $numFacActiva")) {
        error_log('Ventas: no se pudo guardar la orden de compra de la factura final: ' . mysqli_error($conexion));
        echo json_encode(['success' => false, 'msg' => 'No se pudo guardar el número de orden de compra.']);
        exit;
    }
    registrar_auditoria($conexion, $id_usuario, 'EDITAR', 'factura_fiscal_cotizacion', $id_cotizacion, 'Actualizó la orden de compra de la factura fiscal final.');
    echo json_encode(['success' => true]);
    exit;
}

if ($accion === 'guardar_factura_fiscal') {
    if (!$puede_ver_propias && !$puede_ver_todas) {
        echo json_encode(['success' => false, 'msg' => 'No tienes permiso para facturar cotizaciones.']);
        exit;
    }
    $id_cotizacion = intval($_POST['id'] ?? 0);
    $numero_control = trim((string)($_POST['control'] ?? ''));
    $tasa = filter_var($_POST['tasa'] ?? null, FILTER_VALIDATE_FLOAT);
    if ($id_cotizacion <= 0 || $numero_control === '' || strlen($numero_control) > 60
        || $tasa === false || !is_finite((float)$tasa) || $tasa <= 0) {
        echo json_encode(['success' => false, 'msg' => 'Ingresa un número de control y una tasa BCV válidos.']);
        exit;
    }

    $q_cotizacion = mysqli_query($conexion, "
        SELECT ID, id_vendedor, tipo_cotizacion
        FROM cotizacion
        WHERE ID = $id_cotizacion
        LIMIT 1
    ");
    $cotizacion = $q_cotizacion ? mysqli_fetch_assoc($q_cotizacion) : null;
    if (!$cotizacion) {
        echo json_encode(['success' => false, 'msg' => 'No se encontró la cotización seleccionada.']);
        exit;
    }
    if (!$puede_ver_todas && intval($cotizacion['id_vendedor']) !== $id_usuario) {
        echo json_encode(['success' => false, 'msg' => 'No tienes permiso para facturar esta cotización.']);
        exit;
    }
    if (($cotizacion['tipo_cotizacion'] ?? '') === 'MUESTRA') {
        echo json_encode(['success' => false, 'msg' => 'Las muestras físicas no admiten factura fiscal.']);
        exit;
    }

    mysqli_begin_transaction($conexion);
    $q_existente = mysqli_query($conexion, "
        SELECT numero_factura
        FROM factura_fiscal_cotizacion
        WHERE id_cotizacion = $id_cotizacion AND (estado IS NULL OR estado = 'Activa')
        ORDER BY numero_factura DESC
        LIMIT 1
        FOR UPDATE
    ");
    if (!$q_existente) {
        mysqli_rollback($conexion);
        echo json_encode(['success' => false, 'msg' => 'No se pudo revisar si la cotización ya tiene factura activa.']);
        exit;
    }
    $factura_existente = mysqli_fetch_assoc($q_existente);

    if ($factura_existente) {
        $numero_factura = intval($factura_existente['numero_factura']);
        $control_sql = mysqli_real_escape_string($conexion, $numero_control);
        $actualizado = mysqli_query($conexion, "
            UPDATE factura_fiscal_cotizacion
            SET numero_control = '$control_sql', tasa_bcv = " . floatval($tasa) . "
            WHERE id_cotizacion = $id_cotizacion AND numero_factura = $numero_factura
        ");
        if (!$actualizado || !mysqli_commit($conexion)) {
            mysqli_rollback($conexion);
            echo json_encode(['success' => false, 'msg' => 'No se pudieron guardar los datos de la factura.']);
            exit;
        }
    } else {
        $q_secuencia = mysqli_query($conexion, "
            SELECT siguiente_numero
            FROM factura_fiscal_secuencia
            WHERE id = 1
            FOR UPDATE
        ");
        $secuencia = $q_secuencia ? mysqli_fetch_assoc($q_secuencia) : null;
        if (!$secuencia) {
            mysqli_rollback($conexion);
            echo json_encode(['success' => false, 'msg' => 'No se pudo obtener el siguiente número correlativo de factura.']);
            exit;
        }
        $numero_factura = intval($secuencia['siguiente_numero']);
        $control_sql = mysqli_real_escape_string($conexion, $numero_control);
        $guardado = mysqli_query($conexion, "
            INSERT INTO factura_fiscal_cotizacion
                (id_cotizacion, numero_factura, numero_control, tasa_bcv, id_usuario, estado)
            VALUES
                ($id_cotizacion, $numero_factura, '$control_sql', " . floatval($tasa) . ", $id_usuario, 'Activa')
        ");
        $secuencia_actualizada = $guardado
            ? mysqli_query($conexion, "UPDATE factura_fiscal_secuencia SET siguiente_numero = siguiente_numero + 1 WHERE id = 1")
            : false;
        if (!$guardado || !$secuencia_actualizada || !mysqli_commit($conexion)) {
            mysqli_rollback($conexion);
            echo json_encode(['success' => false, 'msg' => 'No se pudo emitir la factura; no se consumió el correlativo.']);
            exit;
        }
        registrar_auditoria(
            $conexion,
            $id_usuario,
            'CREAR',
            'factura_fiscal_cotizacion',
            $id_cotizacion,
            'Factura fiscal ' . str_pad((string)$numero_factura, 8, '0', STR_PAD_LEFT) . ' emitida para cotización ' . $id_cotizacion
        );
    }

    echo json_encode([
        'success' => true,
        'numero' => str_pad((string)$numero_factura, 8, '0', STR_PAD_LEFT)
    ]);
    exit;
}

// === PAUSAR COTIZACIÓN ===
if ($accion == 'pausar_cotizacion') {
    if (!$puede_editar) { 
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No tienes el Vector [8] para editar cotizaciones.']); 
        exit; 
    }
    
    $id_cotizacion = intval($_POST['id_cotizacion'] ?? 0);
    $estado_nuevo = intval($_POST['estado_nuevo'] ?? 0);
    
    if (mysqli_query($conexion, "UPDATE cotizacion SET pausado = $estado_nuevo WHERE ID = $id_cotizacion")) {
        $accion_txt = $estado_nuevo == 1 ? "Pausó/Congeló" : "Descongeló";
        registrar_auditoria($conexion, $id_usuario, 'EDITAR', 'cotizacion', $id_cotizacion, "$accion_txt la cotización ID $id_cotizacion");
        ob_clean();
        echo json_encode(['success' => true]);
    } else {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => mysqli_error($conexion)]);
    }
    exit;
}

if ($accion == 'listar') {
    if (!$puede_ver_propias && !$puede_ver_todas && !$es_master) {
        ob_clean();
        echo json_encode(['success' => true, 'data' => [], 'es_master_actual' => $es_master]); 
        exit;
    }

    $desde = mysqli_real_escape_string($conexion, $_GET['desde'] ?? '');
    $hasta = mysqli_real_escape_string($conexion, $_GET['hasta'] ?? '');
    $estado = mysqli_real_escape_string($conexion, $_GET['estado'] ?? '');
    $tracking = mysqli_real_escape_string($conexion, $_GET['tracking'] ?? '');
    $vendedor = intval($_GET['vendedor'] ?? 0);
    $cliente = intval($_GET['cliente'] ?? 0);
    $where = "WHERE 1=1";
    
    if (!$puede_ver_todas && !$es_master) {
        $where .= " AND c.id_vendedor = $id_usuario";
    } else {
        if ($vendedor > 0) $where .= " AND c.id_vendedor = $vendedor";
    }
    if ($cliente > 0) $where .= " AND c.id_cliente = $cliente";
    
    if (!empty($desde)) $where .= " AND DATE(c.fecha_emision) >= '$desde'";
    if (!empty($hasta)) $where .= " AND DATE(c.fecha_emision) <= '$hasta'";
    
    if (!empty($estado)) {
        if ($estado === 'con_pagos') {
            $where .= " AND c.estado_pago IN ('Pago Inicial', 'Pago Medio', 'Pagado')";
        } else if (strtolower($estado) !== 'todos') {
            $where .= " AND c.estado_pago = '$estado'";
        }
    }

    if (!empty($tracking)) {
        if ($tracking === 'sin_tracking') {
            $where .= " AND t.id IS NULL AND o.ID IS NULL";
        } else if (strtolower($tracking) !== 'todos') {
            $where .= " AND t.estado_general = '$tracking'";
        }
    }

    $whereClientes = ($puede_ver_todas || $es_master) ? '' : "WHERE c.id_vendedor = $id_usuario";
    $qClientes = mysqli_query($conexion, "
        SELECT DISTINCT cli.ID, cli.nombre
        FROM cotizacion c
        JOIN cliente cli ON cli.ID = c.id_cliente
        $whereClientes
        ORDER BY cli.nombre");
    if (!$qClientes) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se pudo cargar la lista de clientes del historial.']);
        exit;
    }
    $clientes = [];
    while ($rowCliente = mysqli_fetch_assoc($qClientes)) {
        $clientes[] = ['ID' => intval($rowCliente['ID']), 'nombre' => $rowCliente['nombre']];
    }

    $sql = "SELECT c.ID, c.nro_cotizacion, c.fecha_emision, c.notas, c.sub_total, c.descuento,
                   c.servicio_logistico, c.flete, c.iva, c.total, c.estado_pago, c.id_cliente, 
                   c.referencias_pago, c.fotos_pagos, c.pago_fecha, c.pago_tasa_bcv, c.pago_valor_usd, c.pago_banco, c.pago_retenciones, c.tipo_cotizacion, c.enviado_logistica,
                   c.igtf, c.comision_pagada, c.noti_wa, c.pausado AS cotizacion_pausada, c.cuenta_por_cobrar,
                   f.numero_factura AS numero_factura_fiscal,
                   f.tasa_bcv AS tasa_factura_fiscal,
                   (SELECT GROUP_CONCAT(LPAD(fa.numero_factura, 8, '0') ORDER BY fa.numero_factura DESC SEPARATOR ', ')
                    FROM factura_fiscal_cotizacion fa
                    WHERE fa.id_cotizacion = c.ID AND fa.estado = 'Anulada') AS facturas_anuladas_lista,
                   cli.nombre AS cliente_nombre, cli.tlf AS cliente_tlf, u.nombre AS v_nombre, u.apellido AS v_apellido,
                   t.hash_publico, t.estado_general as tracking_estado 
            FROM cotizacion c 
            JOIN cliente cli ON c.id_cliente = cli.ID 
            LEFT JOIN factura_fiscal_cotizacion f ON f.id_cotizacion = c.ID AND (f.estado IS NULL OR f.estado = 'Activa')
            LEFT JOIN usuario u ON c.id_vendedor = u.ID 
            LEFT JOIN orden_fabrica o ON c.ID = o.id_cotizacion 
            LEFT JOIN tracking_orden t ON o.ID = t.id_orden_fabrica 
            $where ORDER BY c.ID DESC"; 
            
    $query = mysqli_query($conexion, $sql);
    $data = [];
    $hay_notificaciones = false;
    
    if ($query) {
        while ($row = mysqli_fetch_assoc($query)) {
            $row['fecha_emision'] = date('d/m/Y', strtotime($row['fecha_emision']));
            $row['numero_factura_fiscal'] = $row['numero_factura_fiscal'] !== null
                ? str_pad((string)$row['numero_factura_fiscal'], 8, '0', STR_PAD_LEFT)
                : '';
            $row['facturas_anuladas_lista'] = $row['facturas_anuladas_lista'] ?? '';
            $row['vendedor_nombre'] = trim(($row['v_nombre'] ?? '') . ' ' . ($row['v_apellido'] ?? ''));
            if (empty($row['vendedor_nombre'])) $row['vendedor_nombre'] = 'Desconocido';
            
            if (($row['noti_wa'] ?? 0) > 0) { $hay_notificaciones = true; }
            
            // =========================================================================
            // LÓGICA DE AUTOCORRECCIÓN INQUEBRANTABLE (Corrige si la DB está mal)
            // =========================================================================
            $total_cot_float = round(floatval($row['total']), 2);
            $total_abonado = 0;
            
            if (trim((string)($row['pago_valor_usd'] ?? '')) !== '') {
                foreach (parsearSeriePagosCotizacion($row['pago_valor_usd']) as $p) {
                    $num = preg_replace('/[^0-9.-]/', '', $p);
                    if ($num !== '') {
                        $total_abonado += round(floatval($num), 2);
                    }
                }
            }
            $retencionesUsd = totalRetencionesUsdCotizacion($row['pago_retenciones'] ?? '', $row['tasa_factura_fiscal'] ?? 0);
            if ($retencionesUsd === null) {
                $estado_real = 'Revisar retenciones';
                $row['estado_pago'] = $estado_real;
            } else {
                $total_abonado = round($total_abonado + $retencionesUsd, 2);
                $estado_real = 'sin pagar';
                if ($total_abonado > 0) {
                    if ($total_abonado >= ($total_cot_float - 0.50)) {
                        $estado_real = 'Pagado';
                    } else {
                        $estado_real = 'Pago Inicial';
                    }
                }
            }
            
            $estado_actual_db = strtolower(trim($row['estado_pago'] ?? ''));
            $estado_real_low = strtolower($estado_real);
            
            if ($retencionesUsd !== null && $estado_actual_db !== $estado_real_low && !($estado_actual_db === 'pago medio' && $estado_real_low === 'pago inicial')) {
                if (($row['tipo_cotizacion'] ?? '') !== 'MUESTRA') {
                    $row['estado_pago'] = $estado_real;
                    $id_fix = $row['ID'];
                    mysqli_query($conexion, "UPDATE cotizacion SET estado_pago = '$estado_real' WHERE ID = $id_fix");
                }
            }
            // =========================================================================
            
            $data[] = $row;
        }
    }
    
    ob_clean();
    echo json_encode([
        'success' => true,
        'data' => $data,
        'clientes' => $clientes,
        'hay_notificaciones' => $hay_notificaciones,
        'es_master_actual' => $es_master
    ]); 
    exit;
}

if ($accion === 'listar_garantias_textiles') {
    $puedeVerTodasGarantias = $puede_ver_todas || $rol_actual === 'master';
    if (!$puede_ver_propias && !$puedeVerTodasGarantias) {
        ob_clean();
        echo json_encode(['success' => true, 'data' => []]);
        exit;
    }
    if (!asegurarTablaGarantiasTextiles($conexion)) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se pudo preparar el historial de garantías textiles.']);
        exit;
    }

    $whereGarantias = $puedeVerTodasGarantias ? '' : 'WHERE c.id_vendedor = ' . (int)$id_usuario;
    $queryGarantias = mysqli_query(
        $conexion,
        "SELECT g.id, g.id_orden, g.id_cotizacion, g.motivo, g.evidencias_json, g.estado,
                g.aprobacion_estado, g.nota_aprobacion, g.creado_en, g.actualizado_en, g.finalizado_en,
                o.nro_orden_fabrica, c.nro_cotizacion, cli.nombre AS cliente_nombre,
                u.nombre AS vendedor_nombre, u.apellido AS vendedor_apellido,
                t.hash_publico
         FROM garantias_textiles g
         JOIN orden_fabrica o ON o.ID = g.id_orden
         JOIN cotizacion c ON c.ID = g.id_cotizacion
         JOIN cliente cli ON cli.ID = g.id_cliente
         LEFT JOIN usuario u ON c.id_vendedor = u.ID
         LEFT JOIN tracking_orden t ON t.id_orden_fabrica = o.ID
         $whereGarantias
         ORDER BY (g.estado = 'Finalizada') ASC, g.actualizado_en DESC, g.id DESC"
    );
    if (!$queryGarantias) {
        error_log('Ventas: no se pudieron listar garantías textiles: ' . mysqli_error($conexion));
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se pudo cargar el historial de garantías textiles.']);
        exit;
    }
    $garantias = [];
    while ($row = mysqli_fetch_assoc($queryGarantias)) {
        $row['evidencias'] = json_decode((string)$row['evidencias_json'], true);
        if (!is_array($row['evidencias'])) $row['evidencias'] = [];
        $row['vendedor'] = trim(($row['vendedor_nombre'] ?? '') . ' ' . ($row['vendedor_apellido'] ?? ''));
        $garantias[] = $row;
    }
    ob_clean();
    echo json_encode(['success' => true, 'data' => $garantias], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($accion === 'actualizar_aprobacion_garantia') {
    $idGarantia = filter_var($_POST['id_garantia'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    $decision = trim((string)($_POST['decision'] ?? ''));
    $nota = trim((string)($_POST['nota'] ?? ''));
    $puedeGestionarGarantia = $rol_actual === 'master' || $puede_ver_todas || $puede_ver_propias;
    if ($idGarantia === false || $idGarantia === null || !in_array($decision, ['Aprobada', 'Rechazada'], true)
        || ($decision === 'Rechazada' && ($nota === '' || mb_strlen($nota, 'UTF-8') > 1000))
        || !$puedeGestionarGarantia) {
        echo json_encode(['success' => false, 'msg' => 'La decisión o la solicitud no es válida.']);
        exit;
    }
    if (!asegurarTablaGarantiasTextiles($conexion) || !mysqli_begin_transaction($conexion)) {
        error_log('Ventas: no se pudo iniciar la aprobación de garantía: ' . mysqli_error($conexion));
        echo json_encode(['success' => false, 'msg' => 'No se pudo iniciar la revisión de la garantía.']);
        exit;
    }
    $condicionVendedor = ($rol_actual === 'master' || $puede_ver_todas) ? '' : ' AND c.id_vendedor = ' . (int)$id_usuario;
    $query = mysqli_query(
        $conexion,
        "SELECT g.id, g.aprobacion_estado, g.historial_json, g.id_cotizacion
         FROM garantias_textiles g
         JOIN cotizacion c ON c.ID = g.id_cotizacion
         WHERE g.id = " . (int)$idGarantia . $condicionVendedor . " LIMIT 1 FOR UPDATE"
    );
    $garantia = $query ? mysqli_fetch_assoc($query) : null;
    if (!$garantia || $garantia['aprobacion_estado'] !== 'Pendiente') {
        mysqli_rollback($conexion);
        echo json_encode(['success' => false, 'msg' => $garantia ? 'Esta solicitud ya fue revisada.' : 'No tienes acceso a esta solicitud.']);
        exit;
    }
    $historial = json_decode((string)$garantia['historial_json'], true);
    if (!is_array($historial)) $historial = [];
    $historial[] = [
        'estado' => $decision === 'Aprobada' ? 'Aprobada por Ventas' : 'Rechazada por Ventas',
        'fecha' => date('c'),
        'actor' => $rol_actual === 'master' ? 'Master' : 'Vendedor',
        'usuario' => $id_usuario,
        'nota' => $nota
    ];
    $historialJson = json_encode($historial, JSON_UNESCAPED_UNICODE);
    if (!is_string($historialJson)) {
        mysqli_rollback($conexion);
        echo json_encode(['success' => false, 'msg' => 'No se pudo guardar el historial de la decisión.']);
        exit;
    }
    $stmt = mysqli_prepare(
        $conexion,
        "UPDATE garantias_textiles
         SET aprobacion_estado = ?, nota_aprobacion = ?, id_usuario_aprueba = ?, aprobado_en = NOW(), historial_json = ?
         WHERE id = ? AND aprobacion_estado = 'Pendiente'"
    );
    if (!$stmt) {
        mysqli_rollback($conexion);
        error_log('Ventas: no se pudo preparar la actualización de aprobación: ' . mysqli_error($conexion));
        echo json_encode(['success' => false, 'msg' => 'No se pudo guardar la decisión.']);
        exit;
    }
    mysqli_stmt_bind_param($stmt, 'ssisi', $decision, $nota, $id_usuario, $historialJson, $idGarantia);
    $updated = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    if (!$updated) {
        mysqli_rollback($conexion);
        error_log('Ventas: no se pudo confirmar la decisión de garantía: ' . mysqli_error($conexion));
        echo json_encode(['success' => false, 'msg' => 'No se pudo confirmar la decisión.']);
        exit;
    }
    $stmtNotificacion = mysqli_prepare(
        $conexion,
        "UPDATE cotizacion c
         SET c.noti_wa = IF(
             ? = 'Rechazada' AND NOT EXISTS (
                 SELECT 1 FROM garantias_textiles g
                 WHERE g.id_cotizacion = c.ID AND g.id <> ?
                   AND g.estado <> 'Finalizada' AND g.aprobacion_estado <> 'Rechazada'
             ),
             5,
             4
         )
         WHERE c.ID = ?"
    );
    if (!$stmtNotificacion) {
        mysqli_rollback($conexion);
        error_log('Ventas: no se pudo preparar el aviso de decisión de garantía: ' . mysqli_error($conexion));
        echo json_encode(['success' => false, 'msg' => 'No se pudo actualizar el aviso de la cotización.']);
        exit;
    }
    $idCotizacionGarantia = (int)$garantia['id_cotizacion'];
    mysqli_stmt_bind_param($stmtNotificacion, 'sii', $decision, $idGarantia, $idCotizacionGarantia);
    $notificacionActualizada = mysqli_stmt_execute($stmtNotificacion);
    mysqli_stmt_close($stmtNotificacion);
    if (!$notificacionActualizada) {
        mysqli_rollback($conexion);
        error_log('Ventas: no se pudo actualizar el aviso de decisión de garantía: ' . mysqli_error($conexion));
        echo json_encode(['success' => false, 'msg' => 'No se pudo actualizar el aviso de la cotización.']);
        exit;
    }
    if (!mysqli_commit($conexion)) {
        mysqli_rollback($conexion);
        error_log('Ventas: no se pudo confirmar la decisión y su notificación: ' . mysqli_error($conexion));
        echo json_encode(['success' => false, 'msg' => 'No se pudo confirmar la decisión.']);
        exit;
    }
    echo json_encode(['success' => true, 'msg' => $decision === 'Aprobada' ? 'Garantía aprobada y enviada a Logística.' : 'Solicitud rechazada.']);
    exit;
}

if ($accion == 'limpiar_noti_wa') {
    $id = intval($_POST['id'] ?? 0);
    $puedeLimpiarGarantia = $puede_ver_todas || $rol_actual === 'master';
    if ($id <= 0 || (!$puede_ver_propias && !$puedeLimpiarGarantia)) {
        echo json_encode(['success' => false, 'msg' => 'No tienes permiso para actualizar esta notificación.']);
        exit;
    }
    if (!asegurarTablaGarantiasTextiles($conexion)) {
        echo json_encode(['success' => false, 'msg' => 'No se pudo comprobar el estado de la garantía.']);
        exit;
    }
    $whereOwnQuote = $puedeLimpiarGarantia ? '' : " AND id_vendedor = " . (int)$id_usuario;
    $qGarantiaActiva = mysqli_query(
        $conexion,
        "SELECT 1 FROM garantias_textiles
         WHERE id_cotizacion = $id AND estado <> 'Finalizada' AND aprobacion_estado <> 'Rechazada'
           AND EXISTS (
               SELECT 1 FROM cotizacion c
               WHERE c.ID = garantias_textiles.id_cotizacion$whereOwnQuote
           )
         LIMIT 1"
    );
    if (!$qGarantiaActiva) {
        error_log('Ventas: no se pudo comprobar si la garantía sigue abierta: ' . mysqli_error($conexion));
        echo json_encode(['success' => false, 'msg' => 'No se pudo comprobar el estado de la garantía.']);
        exit;
    }
    if (mysqli_num_rows($qGarantiaActiva) > 0) {
        echo json_encode(['success' => false, 'msg' => 'La alerta se mantiene visible mientras la garantía siga abierta.']);
        exit;
    }
    if (!mysqli_query($conexion, "UPDATE cotizacion SET noti_wa = 0 WHERE ID = $id$whereOwnQuote")) {
        error_log('Ventas: no se pudo limpiar la notificación de cotización: ' . mysqli_error($conexion));
        echo json_encode(['success' => false, 'msg' => 'No se pudo actualizar la notificación.']);
        exit;
    }
    echo json_encode(['success' => true]);
    exit;
}

// === ACCIÓN PARA BORRAR PAGOS SI ALGUIEN SE EQUIVOCA ===
if ($accion == 'limpiar_pagos') {
    if (!$puede_editar && !$es_master) { 
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'Permiso denegado para alterar pagos.']); 
        exit; 
    }
    $id = intval($_POST['id'] ?? 0);
    $sql = "UPDATE cotizacion SET estado_pago = 'sin pagar', referencias_pago = NULL, fotos_pagos = NULL, pago_fecha = NULL, pago_tasa_bcv = NULL, pago_valor_usd = NULL, pago_banco = NULL, pago_retenciones = NULL, prealerta_produccion = 0 WHERE ID = $id";
    if (mysqli_query($conexion, $sql)) {
        registrar_auditoria($conexion, $id_usuario, 'EDITAR', 'cotizacion', $id, "Eliminó todos los registros de pago de la cotización y la marcó como Sin Pagar");
        ob_clean();
        echo json_encode(['success' => true]);
    } else {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => mysqli_error($conexion)]);
    }
    exit;
}

// === ACCIÓN EXCLUSIVA MASTER: EDITAR UN PAGO INDIVIDUAL EN LA PASARELA ===
if ($accion === 'editar_pago_individual') {
    if (!$es_master) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'Solo los usuarios Master pueden editar pagos registrados.']);
        exit;
    }

    $id = intval($_POST['id'] ?? 0);
    $idx = intval($_POST['edit_pago_index'] ?? -1);
    $referencia = trim($_POST['referencia'] ?? '');
    $pago_fecha = trim($_POST['pago_fecha'] ?? '');
    $pago_tasa = trim($_POST['pago_tasa_bcv'] ?? '');
    $pago_usd = trim($_POST['pago_valor_usd'] ?? '');
    $pago_banco = trim($_POST['pago_banco'] ?? '');
    $retencionActiva = ($_POST['pago_con_retenciones'] ?? '') === '1';

    if ($id <= 0 || $idx < 0) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'Identificador de cotización o índice de pago inválido.']);
        exit;
    }

    $retencionesPct = [];
    $retencionesBs = [];
    foreach (['iva', 'islr', 'municipal'] as $tipo) {
        $campoPct = 'retencion_' . $tipo . '_pct';
        $valorPct = trim((string)($_POST[$campoPct] ?? '0'));
        $porcentaje = $valorPct === '' ? 0.0 : filter_var($valorPct, FILTER_VALIDATE_FLOAT);
        if ($porcentaje === false || !is_finite((float)$porcentaje) || (float)$porcentaje < 0 || (float)$porcentaje > 100) {
            echo json_encode(['success' => false, 'msg' => 'Los porcentajes de retención deben estar entre 0 y 100.']);
            exit;
        }
        $retencionesPct[$tipo . '_pct'] = round((float)$porcentaje, 2);
        $retencionesBs[$tipo . '_bs'] = 0.0;
    }
    if (!$retencionActiva) {
        $retencionesBs = ['iva_bs' => 0.0, 'islr_bs' => 0.0, 'municipal_bs' => 0.0];
        $retencionesPct = ['iva_pct' => 0.0, 'islr_pct' => 0.0, 'municipal_pct' => 0.0];
    }

    $q_curr = mysqli_query($conexion, "
        SELECT c.total, c.sub_total, c.descuento, c.servicio_logistico, c.flete,
               c.iva, c.igtf, c.tipo_cotizacion, c.enviado_logistica,
               c.prealerta_produccion, c.referencias_pago, c.fotos_pagos, c.pago_fecha,
               c.pago_tasa_bcv, c.pago_valor_usd, c.pago_banco, c.pago_retenciones,
               f.tasa_bcv AS tasa_factura_fiscal,
               (SELECT COUNT(*) FROM orden_fabrica o WHERE o.id_cotizacion = c.ID) AS ordenes_existentes
        FROM cotizacion c
        LEFT JOIN factura_fiscal_cotizacion f ON f.id_cotizacion = c.ID AND (f.estado IS NULL OR f.estado = 'Activa')
        WHERE c.ID = $id
        LIMIT 1
    ");
    $curr = $q_curr ? mysqli_fetch_assoc($q_curr) : null;
    if (!$curr) {
        echo json_encode(['success' => false, 'msg' => 'No se encontró la cotización.']);
        exit;
    }

    $tasaFactura = (float)($curr['tasa_factura_fiscal'] ?? 0);
    $tasaRetencion = $tasaFactura > 0 ? $tasaFactura : (is_numeric($pago_tasa) ? (float)$pago_tasa : 0.0);
    $baseImponibleUsd = max(
        0,
        (float)$curr['sub_total']
        + (float)($curr['servicio_logistico'] ?? 0)
        + (float)($curr['flete'] ?? 0)
        - (float)($curr['descuento'] ?? 0)
    );

    if ($retencionActiva) {
        $hayPorcentajesRetencion = array_sum($retencionesPct) > 0;
        if ($hayPorcentajesRetencion && $tasaRetencion <= 0) {
            echo json_encode(['success' => false, 'msg' => 'Ingresa una tasa BCV válida para calcular las retenciones.']);
            exit;
        }
        if ($tasaRetencion > 0) {
            $basesRetencionBs = [
                'iva' => max(0, (float)$curr['iva']) * $tasaRetencion,
                'islr' => $baseImponibleUsd * $tasaRetencion,
                'municipal' => $baseImponibleUsd * $tasaRetencion
            ];
            foreach ($basesRetencionBs as $tipo => $baseBs) {
                $retencionesBs[$tipo . '_bs'] = round($baseBs * $retencionesPct[$tipo . '_pct'] / 100, 2);
            }
        }
    }

    $totalRetencionBsActual = array_sum($retencionesBs);
    $pagoUsdNumero = $pago_usd === '' ? 0.0 : filter_var($pago_usd, FILTER_VALIDATE_FLOAT);
    if ($pagoUsdNumero === false || !is_finite((float)$pagoUsdNumero) || (float)$pagoUsdNumero < 0) {
        echo json_encode(['success' => false, 'msg' => 'El monto pagado en USD debe ser un número válido igual o mayor que cero.']);
        exit;
    }
    if ((float)$pagoUsdNumero <= 0 && $totalRetencionBsActual <= 0) {
        echo json_encode(['success' => false, 'msg' => 'Registra un pago en USD o un monto de retención mayor que cero.']);
        exit;
    }

    $arrRefs = parsearSeriePagosCotizacion($curr['referencias_pago'] ?? '');
    $arrFechas = parsearSeriePagosCotizacion($curr['pago_fecha'] ?? '');
    $arrTasas = parsearSeriePagosCotizacion($curr['pago_tasa_bcv'] ?? '');
    $arrUsds = parsearSeriePagosCotizacion($curr['pago_valor_usd'] ?? '');
    $arrBancos = parsearSeriePagosCotizacion($curr['pago_banco'] ?? '');

    $maxLen = max(count($arrRefs), count($arrFechas), count($arrTasas), count($arrUsds), count($arrBancos), $idx + 1);
    for ($i = 0; $i < $maxLen; $i++) {
        if (!isset($arrRefs[$i])) $arrRefs[$i] = '-';
        if (!isset($arrFechas[$i])) $arrFechas[$i] = date('d/m/Y');
        if (!isset($arrTasas[$i])) $arrTasas[$i] = 'No aplica';
        if (!isset($arrUsds[$i])) $arrUsds[$i] = '0';
        if (!isset($arrBancos[$i])) $arrBancos[$i] = '-';
    }

    $arrRefs[$idx] = $referencia !== '' ? $referencia : '-';
    $arrFechas[$idx] = $pago_fecha !== '' ? date('d/m/Y', strtotime($pago_fecha)) : $arrFechas[$idx];
    $arrTasas[$idx] = $pago_tasa !== '' ? $pago_tasa : 'No aplica';
    $arrUsds[$idx] = $pago_usd === '' ? '0' : $pago_usd;
    $arrBancos[$idx] = $pago_banco !== '' ? $pago_banco : '-';

    $retencionesActualesRaw = trim((string)($curr['pago_retenciones'] ?? ''));
    $retencionesFinal = $retencionesActualesRaw !== '' ? json_decode($retencionesActualesRaw, true) : [];
    if (!is_array($retencionesFinal)) $retencionesFinal = [];
    for ($i = 0; $i < $maxLen; $i++) {
        if (!isset($retencionesFinal[$i]) || !is_array($retencionesFinal[$i])) {
            $retencionesFinal[$i] = [
                'iva_bs' => 0.0, 'islr_bs' => 0.0, 'municipal_bs' => 0.0,
                'iva_pct' => 0.0, 'islr_pct' => 0.0, 'municipal_pct' => 0.0
            ];
        }
    }
    $retencionesBs['tasa_bcv'] = $tasaRetencion;
    $retencionesFinal[$idx] = array_merge($retencionesBs, $retencionesPct);

    // Subir comprobantes adicionales si se adjuntaron en la edición
    $fotos_nuevas = [];
    if (isset($_FILES['fotos_pago'])) {
        $dir_uploads = "../../images/pagos/";
        if (!is_dir($dir_uploads)) mkdir($dir_uploads, 0777, true);
        $total_archivos = is_array($_FILES['fotos_pago']['name']) ? count($_FILES['fotos_pago']['name']) : 0;
        for ($i = 0; $i < $total_archivos; $i++) {
            if ($_FILES['fotos_pago']['error'][$i] == UPLOAD_ERR_OK) {
                $ext = strtolower(pathinfo($_FILES['fotos_pago']['name'][$i], PATHINFO_EXTENSION));
                $nombre_archivo = "pago_" . time() . "_" . rand(100, 999) . "_" . $i . "." . $ext;
                if (move_uploaded_file($_FILES['fotos_pago']['tmp_name'][$i], $dir_uploads . $nombre_archivo)) {
                    $fotos_nuevas[] = $nombre_archivo;
                }
            }
        }
    }
    $fotos_final = $curr['fotos_pagos'] ?? '';
    if (!empty($fotos_nuevas)) {
        $fotos_str = implode(',', $fotos_nuevas);
        $fotos_final = empty($fotos_final) ? $fotos_str : $fotos_final . "," . $fotos_str;
    }

    $refs_final = mysqli_real_escape_string($conexion, implode(' | ', $arrRefs));
    $fecha_final = mysqli_real_escape_string($conexion, implode(' | ', $arrFechas));
    $tasa_final = mysqli_real_escape_string($conexion, implode(' | ', $arrTasas));
    $usd_final_raw = implode(' | ', $arrUsds);
    $usd_final = mysqli_real_escape_string($conexion, $usd_final_raw);
    $banco_final = mysqli_real_escape_string($conexion, implode(' | ', $arrBancos));
    $fotos_final_sql = mysqli_real_escape_string($conexion, $fotos_final);
    $retencionesFinalJson = mysqli_real_escape_string(
        $conexion,
        json_encode($retencionesFinal, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
    );

    // Recalcular total abonado y estado de la cotización
    $total_cotizacion = round(floatval($curr['total'] ?? 0), 2);
    $total_abonado = 0.0;
    foreach ($arrUsds as $p) {
        $num_limpio = preg_replace('/[^0-9.-]/', '', $p);
        if ($num_limpio !== '') {
            $total_abonado += round(floatval($num_limpio), 2);
        }
    }
    $total_abonado += (float)totalRetencionesUsdCotizacion(json_encode($retencionesFinal), $tasaFactura);
    $total_abonado = round($total_abonado, 2);

    if ($total_abonado <= 0) {
        $estado_calculado = 'sin pagar';
    } elseif ($total_abonado >= ($total_cotizacion - 0.50)) {
        $estado_calculado = 'Pagado';
    } else {
        $estado_calculado = 'Pago Inicial';
    }

    $base_prealerta = max(0, round(floatval($curr['total']) - floatval($curr['iva']) - floatval($curr['igtf']), 2));
    $minimo_prealerta = round($base_prealerta * 0.40, 2);
    $cumple_prealerta = strtoupper(trim($curr['tipo_cotizacion'] ?? '')) !== 'MUESTRA'
        && intval($curr['enviado_logistica'] ?? 0) === 0
        && intval($curr['ordenes_existentes'] ?? 0) === 0
        && $total_abonado > 0
        && $total_abonado >= ($minimo_prealerta - 0.10);
    $estado_prealerta = $cumple_prealerta
        ? (intval($curr['prealerta_produccion'] ?? 0) === 2 ? 2 : 1)
        : 0;

    $sql_update = "UPDATE cotizacion SET
        estado_pago = '$estado_calculado',
        referencias_pago = '$refs_final',
        fotos_pagos = '$fotos_final_sql',
        pago_fecha = '$fecha_final',
        pago_tasa_bcv = '$tasa_final',
        pago_valor_usd = '$usd_final',
        pago_banco = '$banco_final',
        pago_retenciones = '$retencionesFinalJson',
        prealerta_produccion = $estado_prealerta
        WHERE ID = $id";

    if (mysqli_query($conexion, $sql_update)) {
        $numPagoHum = $idx + 1;
        registrar_auditoria($conexion, $id_usuario, 'EDITAR_PAGO', 'cotizacion', $id, "Master editó el pago #$numPagoHum de la cotización ID $id (Monto USD: $pago_usd). Estado recalculado a $estado_calculado");
        ob_clean();
        echo json_encode(['success' => true, 'id_cotizacion' => $id, 'pago_index' => $idx]);
    } else {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => mysqli_error($conexion)]);
    }
    exit;
}

if ($accion == 'obtener') {
    if (!$puede_editar && !$es_master) { 
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No tienes el Vector [8] para editar.']); 
        exit; 
    }
    $id = intval($_GET['id'] ?? 0);
    $q_estado = mysqli_query($conexion, "
        SELECT c.enviado_logistica, o.ID AS id_orden
        FROM cotizacion c
        LEFT JOIN orden_fabrica o ON o.id_cotizacion = c.ID
        WHERE c.ID = $id
        LIMIT 1
    ");
    $estado = $q_estado ? mysqli_fetch_assoc($q_estado) : null;
    if (!$estado) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se encontró la cotización.']);
        exit;
    }
    if (intval($estado['enviado_logistica']) !== 0 || !empty($estado['id_orden'])) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'Esta cotización ya está en logística o tiene una orden. Para modificarla, primero revierte la orden a ventas.']);
        exit;
    }

    if (!$puede_ver_todas && !$es_master) {
        $q_own = mysqli_query($conexion, "SELECT id_vendedor FROM cotizacion WHERE ID=$id");
        $own = mysqli_fetch_assoc($q_own);
        if (($own['id_vendedor'] ?? 0) != $id_usuario) {
            ob_clean();
            echo json_encode(['success' => false, 'msg' => 'No puedes editar una cotización que no es tuya.']); 
            exit;
        }
    }

    $data = mysqli_fetch_assoc(mysqli_query($conexion, "SELECT * FROM cotizacion WHERE ID = $id"));
    $detalles = []; 
    $q = mysqli_query($conexion, "SELECT d.*, c.nombre as categoria FROM detalle_cotizacion d LEFT JOIN productos p ON d.id_producto = p.id LEFT JOIN subcategorias s ON p.id_subcategoria = s.id LEFT JOIN categorias c ON s.id_categoria = c.id WHERE d.id_cotizacion = $id");
    while ($row = mysqli_fetch_assoc($q)) $detalles[] = $row;
    
    ob_clean();
    echo json_encode(['success' => true, 'data' => $data, 'detalles' => $detalles]); 
    exit;
}

if ($accion == 'detalles') {
    $id_cotizacion = intval($_GET['id_cotizacion'] ?? 0);
    $data = []; 
    $q = mysqli_query($conexion, "SELECT * FROM detalle_cotizacion WHERE id_cotizacion = $id_cotizacion");
    while ($row = mysqli_fetch_assoc($q)) $data[] = $row;
    
    ob_clean();
    echo json_encode(['success' => true, 'data' => $data]); 
    exit;
}

if ($accion == 'detalles_y_recursos') {
    $id_cotizacion = intval($_GET['id_cotizacion'] ?? 0);
    $q_cot = mysqli_query($conexion, "SELECT fotos_diseno FROM cotizacion WHERE ID = $id_cotizacion");
    $cot = mysqli_fetch_assoc($q_cot);
    $data = []; 
    $q = mysqli_query($conexion, "SELECT * FROM detalle_cotizacion WHERE id_cotizacion = $id_cotizacion");
    while ($row = mysqli_fetch_assoc($q)) $data[] = $row;
    
    ob_clean();
    echo json_encode(['success' => true, 'data' => $data, 'fotos_diseno' => $cot['fotos_diseno'] ?? '']); 
    exit;
}

if ($accion == 'guardar_especificaciones') {
    $id_cot = intval($_POST['id_cotizacion'] ?? 0);
    $payload = json_decode($_POST['data'] ?? '[]', true);

    if (!in_array('28', $permisos_arr) && !in_array('29', $permisos_arr) && !$es_master) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'Necesitas el Vector [28] para editar reglas o el Vector [29] para revisarlas al enviar a logística.']);
        exit;
    }
    if ($id_cot <= 0 || !is_array($payload)) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se recibieron reglas válidas para guardar.']);
        exit;
    }
    $q_estado_reglas = mysqli_query($conexion, "
        SELECT c.enviado_logistica, o.ID AS id_orden
        FROM cotizacion c
        LEFT JOIN orden_fabrica o ON o.id_cotizacion = c.ID
        WHERE c.ID = $id_cot
        LIMIT 1
    ");
    $estado_reglas = $q_estado_reglas ? mysqli_fetch_assoc($q_estado_reglas) : null;
    if (!$estado_reglas || intval($estado_reglas['enviado_logistica']) !== 0 || !empty($estado_reglas['id_orden'])) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'La cotización ya está en logística o tiene una orden; no se pueden cambiar sus reglas.']);
        exit;
    }

    $q_detalles = mysqli_query($conexion, "
        SELECT ID, tipo_prenda, cantidad, detalle_diseno
        FROM detalle_cotizacion
        WHERE id_cotizacion = $id_cot
    ");
    if (!$q_detalles) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se pudieron consultar los renglones de la cotización.']);
        exit;
    }

    $detalles_fisicos = [];
    while ($detalle = mysqli_fetch_assoc($q_detalles)) {
        if (
            stripos($detalle['detalle_diseno'] ?? '', 'Ubicación:') === false
            && preg_match('/^(bordado|serigraf|dtf|vinil)/i', trim((string)($detalle['tipo_prenda'] ?? ''))) !== 1
            && !es_cargo_talla_extra_cotizacion($detalle['tipo_prenda'])
        ) {
            $detalles_fisicos[intval($detalle['ID'])] = $detalle;
        }
    }

    $payload_por_detalle = [];
    foreach ($payload as $item) {
        if (!is_array($item)) {
            ob_clean();
            echo json_encode(['success' => false, 'msg' => 'El formato de las reglas no es válido. Vuelve a abrir la regla azul.']);
            exit;
        }
        $id_det = intval($item['id_detalle'] ?? 0);
        if (!isset($detalles_fisicos[$id_det]) || isset($payload_por_detalle[$id_det])) {
            ob_clean();
            echo json_encode(['success' => false, 'msg' => 'La cotización cambió mientras editabas las reglas. Vuelve a abrir la regla azul y revisa los renglones.']);
            exit;
        }

        $specs = json_decode($item['especificaciones'] ?? '', true);
        if (!is_array($specs) || empty($specs)) {
            ob_clean();
            echo json_encode(['success' => false, 'msg' => 'Debes ingresar al menos una línea de talla y tela por cada prenda.']);
            exit;
        }

        $suma = 0;
        $tela_base = obtener_tela_base_cotizacion($detalles_fisicos[$id_det]['detalle_diseno'] ?? '');
        foreach ($specs as $spec) {
            if (
                !is_array($spec)
                || intval($spec['cantidad'] ?? 0) < 1
                || trim((string)($spec['talla'] ?? '')) === ''
                || trim((string)($spec['tela'] ?? '')) === ''
                || !genero_especificacion_valido_cotizacion($detalles_fisicos[$id_det]['tipo_prenda'], $spec['genero'] ?? '')
            ) {
                ob_clean();
                echo json_encode(['success' => false, 'msg' => 'Selecciona un género válido y completa cantidad, talla y tela en todas las líneas de la regla azul.']);
                exit;
            }
            if ($tela_base !== '' && mb_strtolower(trim((string)$spec['tela']), 'UTF-8') !== mb_strtolower($tela_base, 'UTF-8')) {
                ob_clean();
                $nombre_prenda = trim((string)$detalles_fisicos[$id_det]['tipo_prenda']);
                echo json_encode(['success' => false, 'msg' => "La prenda \"$nombre_prenda\" debe conservar la tela de la cotización: $tela_base."]);
                exit;
            }
            $suma += intval($spec['cantidad']);
        }

        if ($suma !== intval($detalles_fisicos[$id_det]['cantidad'])) {
            ob_clean();
            echo json_encode(['success' => false, 'msg' => 'La suma de las tallas debe coincidir con la cantidad cotizada en cada renglón.']);
            exit;
        }
        $payload_por_detalle[$id_det] = json_encode($specs, JSON_UNESCAPED_UNICODE);
    }

    if (count($payload_por_detalle) !== count($detalles_fisicos)) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'Faltan prendas por especificar. Revisa todos los renglones en la regla azul.']);
        exit;
    }

    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $transaccion_iniciada = false;
    $archivos_subidos = [];
    try {
        mysqli_begin_transaction($conexion);
        $transaccion_iniciada = true;
        $q_estado_bloqueado = mysqli_query($conexion, "SELECT enviado_logistica FROM cotizacion WHERE ID = $id_cot FOR UPDATE");
        $estado_bloqueado = mysqli_fetch_assoc($q_estado_bloqueado);
        $q_orden_bloqueada = mysqli_query($conexion, "SELECT ID FROM orden_fabrica WHERE id_cotizacion = $id_cot LIMIT 1");
        if (!$estado_bloqueado || intval($estado_bloqueado['enviado_logistica']) !== 0 || mysqli_fetch_assoc($q_orden_bloqueada)) {
            throw new RuntimeException('La cotización ya está en logística o tiene una orden; no se pueden cambiar sus reglas.');
        }
        $q_detalles_bloqueados = mysqli_query($conexion, "SELECT ID, tipo_prenda, cantidad, detalle_diseno FROM detalle_cotizacion WHERE id_cotizacion = $id_cot");
        $detalles_bloqueados = [];
        while ($detalle_bloqueado = mysqli_fetch_assoc($q_detalles_bloqueados)) {
            if (
                stripos($detalle_bloqueado['detalle_diseno'] ?? '', 'Ubicación:') === false
                && preg_match('/^(bordado|serigraf|dtf|vinil)/i', trim((string)($detalle_bloqueado['tipo_prenda'] ?? ''))) !== 1
                && !es_cargo_talla_extra_cotizacion($detalle_bloqueado['tipo_prenda'])
            ) {
                $detalles_bloqueados[intval($detalle_bloqueado['ID'])] = $detalle_bloqueado;
            }
        }
        if (count($detalles_bloqueados) !== count($payload_por_detalle)) {
            throw new RuntimeException('La cotización cambió mientras editabas las reglas. Vuelve a abrir la regla azul y revisa los renglones.');
        }
        foreach ($detalles_bloqueados as $id_det => $detalle_bloqueado) {
            $specs_bloqueadas = json_decode($payload_por_detalle[$id_det] ?? '', true);
            $cantidad_bloqueada = 0;
            foreach (is_array($specs_bloqueadas) ? $specs_bloqueadas : [] as $spec_bloqueada) {
                $cantidad_bloqueada += intval($spec_bloqueada['cantidad'] ?? 0);
            }
            if (!is_array($specs_bloqueadas) || $cantidad_bloqueada !== intval($detalle_bloqueado['cantidad'])) {
                throw new RuntimeException('La cotización cambió mientras editabas las reglas. Vuelve a abrir la regla azul y revisa los renglones.');
            }
        }
        foreach ($payload_por_detalle as $id_det => $specs_json) {
            $specs = mysqli_real_escape_string($conexion, $specs_json);
            mysqli_query($conexion, "UPDATE detalle_cotizacion SET especificaciones_tallas = '$specs' WHERE ID = $id_det AND id_cotizacion = $id_cot");
        }

        $fotos_nuevas = [];
        if (isset($_FILES['fotos_diseno'])) {
            $dir_uploads = "../../images/ordenes/"; 
            if (!is_dir($dir_uploads) && !mkdir($dir_uploads, 0777, true) && !is_dir($dir_uploads)) {
                throw new RuntimeException('No se pudo preparar la carpeta de imágenes de diseño.');
            }
            $total_archivos = is_array($_FILES['fotos_diseno']['name']) ? count($_FILES['fotos_diseno']['name']) : 0;
            for ($i = 0; $i < $total_archivos; $i++) {
                if ($_FILES['fotos_diseno']['error'][$i] === UPLOAD_ERR_NO_FILE) {
                    continue;
                }
                if ($_FILES['fotos_diseno']['error'][$i] !== UPLOAD_ERR_OK) {
                    throw new RuntimeException('No se pudo cargar uno de los archivos de diseño. Vuelve a adjuntarlo e intenta otra vez.');
                }
                $ext = strtolower(pathinfo($_FILES['fotos_diseno']['name'][$i], PATHINFO_EXTENSION));
                $nombre_archivo = "diseno_" . time() . "_" . rand(100, 999) . "_" . $i . "." . $ext;
                if (!move_uploaded_file($_FILES['fotos_diseno']['tmp_name'][$i], $dir_uploads . $nombre_archivo)) {
                    throw new RuntimeException('No se pudo guardar uno de los archivos de diseño. Intenta nuevamente.');
                }
                $fotos_nuevas[] = $nombre_archivo;
                $archivos_subidos[] = $dir_uploads . $nombre_archivo;
            }
        }

        $q_curr = mysqli_query($conexion, "SELECT fotos_diseno FROM cotizacion WHERE ID=$id_cot");
        $curr = mysqli_fetch_assoc($q_curr);
        $fotos_final = $curr['fotos_diseno'] ?? '';
        if (!empty($fotos_nuevas)) {
            $fotos_str = implode(',', $fotos_nuevas);
            $fotos_final = empty($fotos_final) ? $fotos_str : $fotos_final . "," . $fotos_str;
            mysqli_query($conexion, "UPDATE cotizacion SET fotos_diseno='$fotos_final' WHERE ID=$id_cot");
        }
        
        registrar_auditoria($conexion, $id_usuario, 'EDITAR', 'detalle_cotizacion', $id_cot, "Guardó especificaciones y recursos para la cotización ID $id_cot");
        mysqli_commit($conexion);
        $transaccion_iniciada = false;
        mysqli_report(MYSQLI_REPORT_OFF);
        ob_clean();
        echo json_encode(['success' => true]); 
    } catch (Throwable $e) {
        if ($transaccion_iniciada) {
            mysqli_rollback($conexion);
        }
        foreach ($archivos_subidos as $archivo) {
            if (is_file($archivo)) {
                unlink($archivo);
            }
        }
        mysqli_report(MYSQLI_REPORT_OFF);
        error_log('Error al guardar reglas de la cotización ' . $id_cot . ': ' . $e->getMessage());
        ob_clean();
        echo json_encode(['success' => false, 'msg' => $e instanceof RuntimeException ? $e->getMessage() : 'No se pudieron guardar las reglas. No se aplicaron cambios; intenta nuevamente.']);
    }
    exit;
}

if ($accion == 'enviar_logistica') {
    $id_cot = intval($_POST['id_cotizacion'] ?? 0);
    if (!in_array('29', $permisos_arr) && !$es_master) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No tienes el Vector [29] para enviar cotizaciones a logística.']);
        exit;
    }

    // EXCLUSIVO MASTER: Solo si el usuario en sesión es Master se permite el pase sin pago
    $forzar_sin_pago_master = $es_master && (intval($_POST['forzar_sin_pago_master'] ?? 0) === 1);

    $q_cot = mysqli_query($conexion, "
        SELECT c.ID, c.nro_cotizacion, c.id_cliente, c.total, c.iva, c.igtf,
               c.pago_valor_usd, c.pago_retenciones, c.tipo_cotizacion, c.enviado_logistica,
               cli.nombre AS cliente_nombre,
               f.tasa_bcv AS tasa_factura_fiscal
        FROM cotizacion c
        LEFT JOIN cliente cli ON cli.ID = c.id_cliente
        LEFT JOIN factura_fiscal_cotizacion f ON f.id_cotizacion = c.ID AND (f.estado IS NULL OR f.estado = 'Activa')
        WHERE c.ID = $id_cot
        LIMIT 1
    ");
    $cotizacion = $q_cot ? mysqli_fetch_assoc($q_cot) : false;
    if (!$cotizacion) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se encontró la cotización para validar el pago.']);
        exit;
    }
    if (intval($cotizacion['enviado_logistica']) !== 0) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'Esta cotización ya fue enviada a logística. Revisa el historial antes de volver a enviarla.']);
        exit;
    }
    $q_orden_existente = mysqli_query($conexion, "SELECT ID FROM orden_fabrica WHERE id_cotizacion = $id_cot LIMIT 1");
    if (!$q_orden_existente) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se pudo comprobar si la cotización ya tiene una orden. Intenta nuevamente.']);
        exit;
    }
    if (mysqli_fetch_assoc($q_orden_existente)) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'Esta cotización ya tiene una orden de fábrica vinculada. Revisa la orden o usa “Revertir a Ventas” antes de reenviarla.']);
        exit;
    }

    $total_abonado = 0.0;
    $pagos_limpios = str_replace(['ert{}', '<br>', '<br/>', '<br />', "\r", "\n"], '|', $cotizacion['pago_valor_usd'] ?? '');
    foreach (preg_split('/[\s]*\|[\s]*/', $pagos_limpios) as $pago) {
        $monto = preg_replace('/[^0-9.-]/', '', $pago);
        if ($monto !== '') {
            $total_abonado += round((float)$monto, 2);
        }
    }
    $ret_usd = totalRetencionesUsdCotizacion($cotizacion['pago_retenciones'] ?? '', $cotizacion['tasa_factura_fiscal'] ?? 0);
    if ($ret_usd !== null) {
        $total_abonado += $ret_usd;
    }
    $total_abonado = round($total_abonado, 2);

    // Si NO es Muestra y NO es una autorización expresa del Master sin pago, exigir el porcentaje mínimo obligatoriamente
    if (strtoupper(trim($cotizacion['tipo_cotizacion'] ?? '')) !== 'MUESTRA' && !$forzar_sin_pago_master) {
        $base_imponible = round((float)$cotizacion['total'] - (float)$cotizacion['iva'] - (float)$cotizacion['igtf'], 2);
        $porcentaje_minimo = $es_master ? 0.50 : 0.60;
        $minimo_requerido = round($base_imponible * $porcentaje_minimo, 2);
        if ($total_abonado <= 0 || $total_abonado < ($minimo_requerido - 0.10)) {
            $porcentaje_texto = (int)($porcentaje_minimo * 100);
            ob_clean();
            echo json_encode([
                'success' => false,
                'msg' => "Se requiere un pago mínimo del $porcentaje_texto% para enviar esta cotización a logística (Solo el usuario Master puede autorizar el envío sin pago)."
            ]);
            exit;
        }
    }

    $validacion_specs = validar_especificaciones_cotizacion($conexion, $id_cot);
    if (!$validacion_specs['success']) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => $validacion_specs['msg'] . "\nAbre la regla azul, corrige y guarda las especificaciones; después vuelve a enviar."]);
        exit;
    }

    $marcar_cxc = ($es_master && ($forzar_sin_pago_master || intval($_POST['generar_cxp_master'] ?? 0) === 1)) ? 1 : 0;
    $sql_set_cxc = $marcar_cxc === 1 ? ", cuenta_por_cobrar = 1" : "";

    mysqli_begin_transaction($conexion);
    if (!mysqli_query($conexion, "UPDATE cotizacion SET enviado_logistica = 1 $sql_set_cxc WHERE ID = $id_cot AND enviado_logistica = 0")) {
        mysqli_rollback($conexion);
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se pudo registrar el envío a logística. Intenta nuevamente.']);
        exit;
    }
    if (mysqli_affected_rows($conexion) !== 1) {
        mysqli_rollback($conexion);
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'Otra persona ya envió esta cotización a logística. Actualiza el historial antes de continuar.']);
        exit;
    }

    $saldo_pendiente = max(0, round((float)$cotizacion['total'] - $total_abonado, 2));
    $mensaje_respuesta = $forzar_sin_pago_master
        ? "La cotización se envió a logística sin pago (Autorización Master) y quedó registrada en Cuentas por Cobrar por $$saldo_pendiente USD."
        : "Las reglas fueron revisadas y la cotización se envió a logística.";

    $detalle_envio_aud = $forzar_sin_pago_master
        ? "Master envió cotización ID $id_cot a Producción SIN PAGO y generó Cuenta por Cobrar exigible por $$saldo_pendiente USD"
        : "Envió cotización ID $id_cot a Producción";
    registrar_auditoria($conexion, $id_usuario, 'ESTADO_PAGO', 'cotizacion', $id_cot, $detalle_envio_aud);
    mysqli_commit($conexion);

    ob_clean();
    echo json_encode(['success' => true, 'msg' => $mensaje_respuesta]);
    exit;
}

if ($accion == 'enviar_directo_envios') {
    if (!in_array('44', $permisos_arr) && !$es_master) { 
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'Sin Vector [44] para enviar directo a envíos.']); 
        exit; 
    }

    $id_cot = intval($_POST['id_cotizacion'] ?? 0);

    mysqli_query($conexion, "UPDATE cotizacion SET enviado_logistica = 2 WHERE ID = $id_cot");
    
    $q_cot = mysqli_query($conexion, "SELECT id_cliente, id_vendedor, nro_cotizacion FROM cotizacion WHERE ID = $id_cot");
    $cot = mysqli_fetch_assoc($q_cot);
    $id_cli = intval($cot['id_cliente'] ?? 0);
    $id_ven = intval($cot['id_vendedor'] ?? 0);
    $nro = $cot['nro_cotizacion'] ?? '';
    $fecha = date('Y-m-d');
    
    $q_max = mysqli_query($conexion, "SELECT MAX(ID) as max_id FROM orden_fabrica");
    $siguiente = intval(mysqli_fetch_assoc($q_max)['max_id'] ?? 0) + 1;
    $nro_orden = "DIR-" . str_pad($siguiente, 5, "0", STR_PAD_LEFT);
    
    mysqli_query($conexion, "INSERT INTO orden_fabrica (id_cliente, id_cotizacion, nro_orden_fabrica, fecha_emision, fecha_entrega, es_express, id_usuario_vendedor, acepta_entregas_parciales, descripcion, fecha_ingreso_orden) 
                             VALUES ($id_cli, $id_cot, '$nro_orden', '$fecha', '$fecha', 0, $id_ven, 1, 'ENVÍO DIRECTO (Sin pasar por producción)', '$fecha')");

    if (function_exists('registrar_auditoria')) {
        registrar_auditoria($conexion, $id_usuario, 'ENVÍO DIRECTO', 'cotizacion', $id_cot, "Envió la cotización $nro DIRECTO a módulo de Envíos (Saltando Fábrica)");
    }

    ob_clean();
    echo json_encode(['success' => true]);
    exit;
}

// === REGISTRO DE PAGO SEGURO ===
if ($accion == 'cambiar_estado') { 
    if (!$puede_editar && !$es_master) { 
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No tienes el Vector [8] para cambiar estados.']); 
        exit; 
    }
    
    $id = intval($_POST['id'] ?? 0);
    $referencia = mysqli_real_escape_string($conexion, trim($_POST['referencia'] ?? ''));
    $pago_fecha = mysqli_real_escape_string($conexion, trim($_POST['pago_fecha'] ?? ''));
    $pago_tasa = mysqli_real_escape_string($conexion, trim($_POST['pago_tasa_bcv'] ?? ''));
    $pago_usd = mysqli_real_escape_string($conexion, trim($_POST['pago_valor_usd'] ?? ''));
    $pago_banco = mysqli_real_escape_string($conexion, trim($_POST['pago_banco'] ?? ''));
    $retencionActiva = ($_POST['pago_con_retenciones'] ?? '') === '1';
    if ($retencionActiva && !$es_master) {
        echo json_encode(['success' => false, 'msg' => 'Solo Master puede registrar retenciones en un pago.']);
        exit;
    }
    $retencionesBs = [];
    $retencionesPct = [];
    foreach (['iva', 'islr', 'municipal'] as $tipo) {
        $campoPct = 'retencion_' . $tipo . '_pct';
        $valorPct = trim((string)($_POST[$campoPct] ?? '0'));
        $porcentaje = $valorPct === '' ? 0.0 : filter_var($valorPct, FILTER_VALIDATE_FLOAT);
        if ($porcentaje === false || !is_finite((float)$porcentaje) || (float)$porcentaje < 0 || (float)$porcentaje > 100) {
            echo json_encode(['success' => false, 'msg' => 'Los porcentajes de retención deben estar entre 0 y 100.']);
            exit;
        }
        $retencionesPct[$tipo . '_pct'] = round((float)$porcentaje, 2);
        $retencionesBs[$tipo . '_bs'] = 0.0;
    }
    if (!$retencionActiva) {
        $retencionesBs = ['iva_bs' => 0.0, 'islr_bs' => 0.0, 'municipal_bs' => 0.0];
        $retencionesPct = ['iva_pct' => 0.0, 'islr_pct' => 0.0, 'municipal_pct' => 0.0];
    }

    $fotos_nuevas = [];
    if (isset($_FILES['fotos_pago'])) {
        $dir_uploads = "../../images/pagos/"; 
        if (!is_dir($dir_uploads)) mkdir($dir_uploads, 0777, true);
        $total_archivos = is_array($_FILES['fotos_pago']['name']) ? count($_FILES['fotos_pago']['name']) : 0;
        for ($i = 0; $i < $total_archivos; $i++) {
            if ($_FILES['fotos_pago']['error'][$i] == UPLOAD_ERR_OK) {
                $ext = strtolower(pathinfo($_FILES['fotos_pago']['name'][$i], PATHINFO_EXTENSION));
                $nombre_archivo = "pago_" . time() . "_" . rand(100, 999) . "_" . $i . "." . $ext;
                if (move_uploaded_file($_FILES['fotos_pago']['tmp_name'][$i], $dir_uploads . $nombre_archivo)) {
                    $fotos_nuevas[] = $nombre_archivo;
                }
            }
        }
    }

    $q_curr = mysqli_query($conexion, "
        SELECT c.total, c.sub_total, c.descuento, c.servicio_logistico, c.flete,
               c.iva, c.igtf, c.tipo_cotizacion, c.enviado_logistica,
               c.prealerta_produccion, c.referencias_pago, c.fotos_pagos, c.pago_fecha,
               c.pago_tasa_bcv, c.pago_valor_usd, c.pago_banco, c.pago_retenciones,
               f.tasa_bcv AS tasa_factura_fiscal,
               (SELECT COUNT(*) FROM orden_fabrica o WHERE o.id_cotizacion = c.ID) AS ordenes_existentes
        FROM cotizacion c
        LEFT JOIN factura_fiscal_cotizacion f ON f.id_cotizacion = c.ID AND (f.estado IS NULL OR f.estado = 'Activa')
        WHERE c.ID = $id
    ");
    $curr = mysqli_fetch_assoc($q_curr);
    if (!$curr) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se encontró la cotización para registrar el pago.']);
        exit;
    }
    $tasaFactura = (float)($curr['tasa_factura_fiscal'] ?? 0);
    $tasaRetencion = $tasaFactura > 0 ? $tasaFactura : (is_numeric($pago_tasa) ? (float)$pago_tasa : 0.0);
    $baseImponibleUsd = max(
        0,
        (float)$curr['sub_total']
        + (float)($curr['servicio_logistico'] ?? 0)
        + (float)($curr['flete'] ?? 0)
        - (float)($curr['descuento'] ?? 0)
    );
    if ($retencionActiva) {
        $hayPorcentajesRetencion = array_sum($retencionesPct) > 0;
        if ($hayPorcentajesRetencion && $tasaRetencion <= 0) {
            echo json_encode(['success' => false, 'msg' => 'Ingresa una tasa BCV válida para calcular las retenciones.']);
            exit;
        }
        if ($tasaRetencion > 0) {
            $basesRetencionBs = [
                'iva' => max(0, (float)$curr['iva']) * $tasaRetencion,
                'islr' => $baseImponibleUsd * $tasaRetencion,
                'municipal' => $baseImponibleUsd * $tasaRetencion
            ];
            foreach ($basesRetencionBs as $tipo => $baseBs) {
                $retencionesBs[$tipo . '_bs'] = round($baseBs * $retencionesPct[$tipo . '_pct'] / 100, 2);
            }
        }
    }
    $totalRetencionBsActual = array_sum($retencionesBs);
    if ($totalRetencionBsActual > 0 && $tasaRetencion <= 0) {
        echo json_encode(['success' => false, 'msg' => 'Ingresa una tasa BCV válida en el pago o emite la factura fiscal antes de registrar las retenciones.']);
        exit;
    }
    $pagoUsdNumero = $pago_usd === '' ? 0.0 : filter_var($pago_usd, FILTER_VALIDATE_FLOAT);
    if ($pagoUsdNumero === false || !is_finite((float)$pagoUsdNumero) || (float)$pagoUsdNumero < 0) {
        echo json_encode(['success' => false, 'msg' => 'El monto pagado en USD debe ser un número válido igual o mayor que cero.']);
        exit;
    }
    if ((float)$pagoUsdNumero <= 0 && $totalRetencionBsActual <= 0) {
        echo json_encode(['success' => false, 'msg' => 'Registra un pago en USD o un monto de retención mayor que cero.']);
        exit;
    }
    
    $refs_final = $curr['referencias_pago'] ?? '';
    if (!empty($referencia)) { $refs_final = empty($refs_final) ? $referencia : $refs_final . " | " . $referencia; }

    $fotos_final = $curr['fotos_pagos'] ?? '';
    if (!empty($fotos_nuevas)) { $fotos_str = implode(',', $fotos_nuevas); $fotos_final = empty($fotos_final) ? $fotos_str : $fotos_final . "," . $fotos_str; }

    $fecha_final = $curr['pago_fecha'] ?? '';
    if (!empty($pago_fecha)) { $fecha_final = empty($fecha_final) ? date('d/m/Y', strtotime($pago_fecha)) : $fecha_final . " | " . date('d/m/Y', strtotime($pago_fecha)); }

    $tasa_final = $curr['pago_tasa_bcv'] ?? '';
    if (!empty($pago_tasa)) { $tasa_final = empty($tasa_final) ? $pago_tasa : $tasa_final . " | " . $pago_tasa; }

    $usd_final = $curr['pago_valor_usd'] ?? '';
    if ($pago_usd !== '' || $totalRetencionBsActual > 0) {
        $pago_usd = $pago_usd === '' ? '0' : $pago_usd;
        $usd_final = trim((string)$usd_final) === '' ? $pago_usd : $usd_final . " | " . $pago_usd;
    }

    $banco_final = $curr['pago_banco'] ?? '';
    if (!empty($pago_banco)) { $banco_final = empty($banco_final) ? $pago_banco : $banco_final . " | " . $pago_banco; }

    $retencionesActualesRaw = trim((string)($curr['pago_retenciones'] ?? ''));
    $retencionesRaizActual = $retencionesActualesRaw === '' ? [] : json_decode($retencionesActualesRaw);
    if ($retencionesActualesRaw !== '' && (!is_array($retencionesRaizActual) || json_last_error() !== JSON_ERROR_NONE)) {
        echo json_encode(['success' => false, 'msg' => 'El historial de retenciones está dañado. Corrige esos datos antes de registrar otro pago.']);
        exit;
    }
    if ($retencionesActualesRaw === '') {
        $retencionesFinal = array_fill(0, count(parsearSeriePagosCotizacion($curr['pago_valor_usd'] ?? '')), [
            'iva_bs' => 0.0,
            'islr_bs' => 0.0,
            'municipal_bs' => 0.0,
            'iva_pct' => 0.0,
            'islr_pct' => 0.0,
            'municipal_pct' => 0.0
        ]);
    } else {
        $retencionesFinal = json_decode($retencionesActualesRaw, true);
        if (totalRetencionesUsdCotizacion($retencionesActualesRaw, $tasaFactura) === null) {
            echo json_encode(['success' => false, 'msg' => 'El historial de retenciones contiene datos inválidos. Corrige esos datos antes de registrar otro pago.']);
            exit;
        }
    }
    $pagoIndex = count(parsearSeriePagosCotizacion($usd_final)) - 1;
    $retencionesBs['tasa_bcv'] = $tasaRetencion;
    $retencionesBs = array_merge($retencionesBs, $retencionesPct);
    $retencionesFinal[] = $retencionesBs;
    $retencionesFinalJson = mysqli_real_escape_string(
        $conexion,
        json_encode($retencionesFinal, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
    );

    // --- LÓGICA DE CÁLCULO ESTRICTO Y ROBUSTO DE ESTADOS ---
    $total_cotizacion = round(floatval($curr['total'] ?? 0), 2);
    $total_abonado = 0;
    
    if (trim((string)$usd_final) !== '') {
        foreach (parsearSeriePagosCotizacion($usd_final) as $p) {
            $num_limpio = preg_replace('/[^0-9.-]/', '', $p);
            if ($num_limpio !== '') {
                $total_abonado += round(floatval($num_limpio), 2);
            }
        }
    }
    $total_abonado += totalRetencionesUsdCotizacion(json_encode($retencionesFinal), $tasaFactura);
    $total_abonado = round($total_abonado, 2);

    if ($total_abonado <= 0) {
        $estado_calculado = 'sin pagar';
    } else if ($total_abonado >= ($total_cotizacion - 0.50)) { 
        $estado_calculado = 'Pagado';
    } else {
        $estado_calculado = 'Pago Inicial';
    }

    $sql_update = "UPDATE cotizacion SET estado_pago = '$estado_calculado'";
    $sql_update .= ", pago_retenciones = '$retencionesFinalJson'";
    if (strtolower($estado_calculado) !== 'sin pagar') {
        $sql_update .= ", referencias_pago = '$refs_final', fotos_pagos = '$fotos_final', pago_fecha = '$fecha_final', pago_tasa_bcv = '$tasa_final', pago_valor_usd = '$usd_final', pago_banco = '$banco_final'";
    } else {
        $sql_update .= ", referencias_pago = NULL, fotos_pagos = NULL, pago_fecha = NULL, pago_tasa_bcv = NULL, pago_valor_usd = NULL, pago_banco = NULL";
    }
    $base_prealerta = max(0, round(floatval($curr['total']) - floatval($curr['iva']) - floatval($curr['igtf']), 2));
    $minimo_prealerta = round($base_prealerta * 0.40, 2);
    $cumple_prealerta = strtoupper(trim($curr['tipo_cotizacion'] ?? '')) !== 'MUESTRA'
        && intval($curr['enviado_logistica'] ?? 0) === 0
        && intval($curr['ordenes_existentes'] ?? 0) === 0
        && $total_abonado > 0
        && $total_abonado >= ($minimo_prealerta - 0.10);
    $estado_prealerta = $cumple_prealerta
        ? (intval($curr['prealerta_produccion'] ?? 0) === 2 ? 2 : 1)
        : 0;
    $sql_update .= ", prealerta_produccion = $estado_prealerta";
    $sql_update .= " WHERE ID = $id";
    
    if (mysqli_query($conexion, $sql_update)) {
        registrar_auditoria($conexion, $id_usuario, 'ESTADO_PAGO', 'cotizacion', $id, "Registró pago. Estado forzado por el sistema matemático a $estado_calculado");
        ob_clean();
        echo json_encode(['success' => true, 'id_cotizacion' => $id, 'pago_index' => max(0, $pagoIndex)]);
    } else {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => mysqli_error($conexion)]); 
    }
    exit;
}

if ($accion == 'eliminar') { 
    if (!$puede_eliminar && !$es_master) { 
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No tienes el Vector [9] para eliminar cotizaciones.']); 
        exit; 
    }
    $id = intval($_POST['id'] ?? 0);
    $qAbonosComision = mysqli_query($conexion, "SELECT COUNT(*) AS total FROM nomina_prestamo_vendedor_abonos WHERE id_cotizacion = $id");
    $rAbonosComision = $qAbonosComision ? mysqli_fetch_assoc($qAbonosComision) : null;
    if (!$rAbonosComision) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se pudo verificar si esta cotización tiene abonos de préstamo vinculados.']);
        exit;
    }
    if ((int)$rAbonosComision['total'] > 0) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se puede eliminar una cotización cuya comisión ya abonó un préstamo.']);
        exit;
    }
    if ($id < 1) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'Identificador de cotización no válido.']);
        exit;
    }
    if (!asegurarTablaGarantiasTextiles($conexion)) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se pudo comprobar el historial de garantías.']);
        exit;
    }
    $qGarantiasCotizacion = mysqli_query($conexion, "SELECT COUNT(*) AS total FROM garantias_textiles WHERE id_cotizacion = $id");
    if (!$qGarantiasCotizacion) {
        error_log('Ventas: no se pudo comprobar si la cotización tiene garantías: ' . mysqli_error($conexion));
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se pudo comprobar el historial de garantías de esta cotización.']);
        exit;
    }
    $totalGarantiasCotizacion = (int)(mysqli_fetch_assoc($qGarantiasCotizacion)['total'] ?? 0);
    if ($totalGarantiasCotizacion > 0) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se puede archivar esta cotización porque tiene garantías textiles vinculadas. El historial debe conservarse.']);
        exit;
    }

    $crearArchivo = mysqli_query($conexion, "
        CREATE TABLE IF NOT EXISTS cotizaciones_eliminadas (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            cotizacion_id_original INT NOT NULL,
            nro_cotizacion VARCHAR(100) NOT NULL,
            cliente_nombre VARCHAR(255) DEFAULT NULL,
            fecha_eliminacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            id_usuario_elimino INT NOT NULL,
            datos_cotizacion LONGTEXT NOT NULL,
            datos_detalles LONGTEXT NOT NULL,
            datos_ordenes LONGTEXT NOT NULL,
            fecha_restauracion DATETIME DEFAULT NULL,
            id_usuario_restauro INT DEFAULT NULL,
            KEY idx_cotizacion_original (cotizacion_id_original),
            KEY idx_fecha_eliminacion (fecha_eliminacion)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    if (!$crearArchivo) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se pudo preparar el archivador de cotizaciones: ' . mysqli_error($conexion)]);
        exit;
    }

    if (!mysqli_begin_transaction($conexion)) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se pudo iniciar el archivado seguro de la cotización.']);
        exit;
    }

    $qCotizacion = mysqli_query($conexion, "
        SELECT c.*, cli.nombre AS nombre_cliente
        FROM cotizacion c
        LEFT JOIN cliente cli ON cli.ID = c.id_cliente
        WHERE c.ID = $id
        FOR UPDATE
    ");
    $cotizacionArchivada = $qCotizacion ? mysqli_fetch_assoc($qCotizacion) : null;
    if (!$cotizacionArchivada) {
        mysqli_rollback($conexion);
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se encontró la cotización para archivarla.']);
        exit;
    }

    $nombreClienteArchivado = $cotizacionArchivada['nombre_cliente'] ?? null;
    unset($cotizacionArchivada['nombre_cliente']);
    $jsonCotizacion = json_encode($cotizacionArchivada, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    $detallesArchivados = [];
    $qDetalles = mysqli_query($conexion, "SELECT * FROM detalle_cotizacion WHERE id_cotizacion = $id");
    if (!$qDetalles) {
        mysqli_rollback($conexion);
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se pudieron leer los detalles para archivarlos: ' . mysqli_error($conexion)]);
        exit;
    }
    while ($detalle = mysqli_fetch_assoc($qDetalles)) {
        $detallesArchivados[] = $detalle;
    }
    $jsonDetalles = json_encode($detallesArchivados, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    $ordenesArchivadas = [];
    $qOrdenes = mysqli_query($conexion, "SELECT ID FROM orden_fabrica WHERE id_cotizacion = $id FOR UPDATE");
    if (!$qOrdenes) {
        mysqli_rollback($conexion);
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se pudieron leer las órdenes vinculadas: ' . mysqli_error($conexion)]);
        exit;
    }
    while ($orden = mysqli_fetch_assoc($qOrdenes)) {
        $ordenesArchivadas[] = intval($orden['ID']);
    }
    $jsonOrdenes = json_encode($ordenesArchivadas);

    if ($jsonCotizacion === false || $jsonDetalles === false || $jsonOrdenes === false) {
        mysqli_rollback($conexion);
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se pudieron serializar todos los datos de la cotización.']);
        exit;
    }

    $nroArchivado = mysqli_real_escape_string($conexion, $cotizacionArchivada['nro_cotizacion']);
    $clienteArchivadoSql = $nombreClienteArchivado === null
        ? 'NULL'
        : "'" . mysqli_real_escape_string($conexion, $nombreClienteArchivado) . "'";
    $jsonCotizacionSql = mysqli_real_escape_string($conexion, $jsonCotizacion);
    $jsonDetallesSql = mysqli_real_escape_string($conexion, $jsonDetalles);
    $jsonOrdenesSql = mysqli_real_escape_string($conexion, $jsonOrdenes);
    $insertArchivo = mysqli_query($conexion, "
        INSERT INTO cotizaciones_eliminadas (
            cotizacion_id_original, nro_cotizacion, cliente_nombre,
            id_usuario_elimino, datos_cotizacion, datos_detalles, datos_ordenes
        ) VALUES (
            $id, '$nroArchivado', $clienteArchivadoSql,
            $id_usuario, '$jsonCotizacionSql', '$jsonDetallesSql', '$jsonOrdenesSql'
        )
    ");
    if (!$insertArchivo) {
        mysqli_rollback($conexion);
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se pudo guardar la cotización en el archivador: ' . mysqli_error($conexion)]);
        exit;
    }
    $idArchivo = mysqli_insert_id($conexion);

    if (!mysqli_query($conexion, "DELETE FROM detalle_cotizacion WHERE id_cotizacion = $id")
        || !mysqli_query($conexion, "DELETE FROM cotizacion WHERE ID = $id")) {
        $error = mysqli_error($conexion);
        mysqli_rollback($conexion);
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se pudo eliminar la cotización; el archivado fue revertido: ' . $error]);
        exit;
    }

    registrar_auditoria($conexion, $id_usuario, 'ELIMINAR', 'cotizacion', $id, "Archivó y eliminó cotización $nroArchivado (Archivo ID $idArchivo)");
    if (!mysqli_commit($conexion)) {
        mysqli_rollback($conexion);
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se pudo confirmar el archivado de la cotización.']);
        exit;
    }
    ob_clean();
    echo json_encode(['success' => true, 'id_archivo' => $idArchivo]);
    exit;
}

if ($accion == 'previsualizar_comision') {
    if (!$puede_comisiones && !$es_master) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No tienes el Vector [35] para gestionar comisiones.']);
        exit;
    }

    $id = intval($_GET['id'] ?? $_POST['id_cotizacion'] ?? 0);
    $monto = max(0, floatval($_GET['monto'] ?? $_POST['comision_monto'] ?? 0));
    $vinculo = buscarUsuarioVendedorDeCotizacion($conexion, $id);
    if (!$vinculo['success']) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => $vinculo['msg']]);
        exit;
    }

    $deuda = (float)$vinculo['saldo'];
    ob_clean();
    echo json_encode([
        'success' => true,
        'vendedor_encontrado' => !empty($vinculo['encontrado']),
        'vendedor' => $vinculo['vendedor'] ?? '',
        'deuda_pendiente' => $deuda,
        'descuento' => min($monto, $deuda),
        'neto_pagar' => max(0, $monto - $deuda)
    ]);
    exit;
}

if ($accion == 'obtener_comision') {
    $id = intval($_GET['id'] ?? 0);
    $q = mysqli_query($conexion, "SELECT sub_total, descuento_logistica, flete, descuento, comision_pagada, comision_porc, comision_monto, comision_descuento_prestamo, comision_pago_neto, comision_fecha, comision_tasa, comision_banco_emi, comision_banco_rec, comision_ref, comision_foto FROM cotizacion WHERE ID = $id");
    $data = mysqli_fetch_assoc($q);
    
    if ($data) {
        $base_imponible = (floatval($data['sub_total'] ?? 0) + floatval($data['descuento_logistica'] ?? 0) + floatval($data['flete'] ?? 0)) - floatval($data['descuento'] ?? 0);
        if ($base_imponible < 0) $base_imponible = 0;
        
        $data['base_imponible'] = $base_imponible;
        
        ob_clean();
        echo json_encode(['success' => true, 'data' => $data]);
    } else {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'Cotización no encontrada']);
    }
    exit;
}

if ($accion == 'pagar_comision') {
    if (!$puede_comisiones && !$es_master) { 
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No tienes el Vector [35] para gestionar comisiones.']); 
        exit; 
    }

    $id = intval($_POST['id_cotizacion'] ?? 0);
    $comision_porc = floatval($_POST['comision_porc'] ?? 0);
    $comision_monto = floatval($_POST['comision_monto'] ?? 0);
    $comision_fecha = mysqli_real_escape_string($conexion, trim($_POST['comision_fecha'] ?? ''));
    if (!empty($comision_fecha)) { $comision_fecha = date('d/m/Y', strtotime($comision_fecha)); }
    $comision_tasa = floatval($_POST['comision_tasa'] ?? 0);
    $comision_banco_emi = mysqli_real_escape_string($conexion, trim($_POST['comision_banco_emi'] ?? ''));
    $comision_banco_rec = mysqli_real_escape_string($conexion, trim($_POST['comision_banco_rec'] ?? ''));
    $comision_ref = mysqli_real_escape_string($conexion, trim($_POST['comision_ref'] ?? ''));

    if ($id <= 0 || $comision_monto <= 0) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'La cotización y el monto de comisión deben ser válidos.']);
        exit;
    }

    $qTablaPrestamos = mysqli_query($conexion, "SHOW TABLES LIKE 'nomina_prestamos_vendedores'");
    $qTablaAbonos = mysqli_query($conexion, "SHOW TABLES LIKE 'nomina_prestamo_vendedor_abonos'");
    if (!$qTablaPrestamos || !$qTablaAbonos ||
        mysqli_num_rows($qTablaPrestamos) === 0 || mysqli_num_rows($qTablaAbonos) === 0) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No está disponible el módulo de préstamos de vendedores en Nómina para aplicar el descuento.']);
        exit;
    }

    $foto_sql = "";
    if (isset($_FILES['comision_foto']) && $_FILES['comision_foto']['error'] == UPLOAD_ERR_OK) {
        $dir_uploads = "../../images/pagos/"; 
        if (!is_dir($dir_uploads)) mkdir($dir_uploads, 0777, true);
        
        $ext = strtolower(pathinfo($_FILES['comision_foto']['name'], PATHINFO_EXTENSION));
        $nombre_archivo = "com_" . time() . "_" . rand(100, 999) . "." . $ext;
        
        if (move_uploaded_file($_FILES['comision_foto']['tmp_name'], $dir_uploads . $nombre_archivo)) {
            $foto_sql = ", comision_foto = '$nombre_archivo'";
        }
    }

    if (!mysqli_begin_transaction($conexion)) {
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se pudo iniciar el registro seguro del pago de comisión.']);
        exit;
    }
    $qCotizacion = mysqli_query($conexion, "SELECT id_vendedor, comision_pagada FROM cotizacion WHERE ID = $id FOR UPDATE");
    if (!$qCotizacion || !($cotizacion = mysqli_fetch_assoc($qCotizacion))) {
        mysqli_rollback($conexion);
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se encontró la cotización para registrar la comisión.']);
        exit;
    }
    if ((int)$cotizacion['comision_pagada'] === 1) {
        mysqli_rollback($conexion);
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'Esta comisión ya fue registrada y no se volverá a descontar del préstamo.']);
        exit;
    }

    $vinculo = buscarUsuarioVendedorDeCotizacion($conexion, $id);
    if (!$vinculo['success']) {
        mysqli_rollback($conexion);
        ob_clean();
        echo json_encode(['success' => false, 'msg' => $vinculo['msg']]);
        exit;
    }
    if (empty($vinculo['encontrado'])) {
        mysqli_rollback($conexion);
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'Solo se pueden registrar comisiones para usuarios con rol Vendedor o Jefe de Ventas.']);
        exit;
    }

    $deuda_inicial = 0.0;
    $descuento_prestamo = 0.0;
    $id_vendedor = intval($vinculo['id_vendedor']);
    $qDeudas = mysqli_query($conexion, "
            SELECT id, saldo_pendiente
            FROM nomina_prestamos_vendedores
            WHERE id_vendedor = $id_vendedor
              AND estado = 'Pendiente'
              AND saldo_pendiente > 0
            ORDER BY fecha ASC, id ASC
            FOR UPDATE
        ");
    if (!$qDeudas) {
        mysqli_rollback($conexion);
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se pudieron cargar los préstamos pendientes del vendedor.']);
        exit;
    }

    $deudas = [];
    while ($deuda = mysqli_fetch_assoc($qDeudas)) {
        $deuda['saldo_pendiente'] = round((float)$deuda['saldo_pendiente'], 2);
        $deudas[] = $deuda;
        $deuda_inicial += $deuda['saldo_pendiente'];
    }

    $restanteComision = round($comision_monto, 2);
    foreach ($deudas as $deuda) {
        if ($restanteComision <= 0) {
            break;
        }

        $aplicado = min($restanteComision, $deuda['saldo_pendiente']);
        $nuevoSaldo = round($deuda['saldo_pendiente'] - $aplicado, 2);
        $nuevoEstado = $nuevoSaldo <= 0 ? 'Procesado' : 'Pendiente';
        $id_prestamo = intval($deuda['id']);
        $qActualizarDeuda = mysqli_query($conexion, "
                UPDATE nomina_prestamos_vendedores
                SET saldo_pendiente = $nuevoSaldo, estado = '$nuevoEstado'
                WHERE id = $id_prestamo AND estado = 'Pendiente'
            ");
        $deudaActualizada = $qActualizarDeuda && mysqli_affected_rows($conexion) === 1;
        $qGuardarAbono = mysqli_query($conexion, "
                INSERT INTO nomina_prestamo_vendedor_abonos (id_cotizacion, id_prestamo, id_vendedor, monto)
                VALUES ($id, $id_prestamo, $id_vendedor, $aplicado)
            ");
        if (!$deudaActualizada || !$qGuardarAbono) {
            mysqli_rollback($conexion);
            ob_clean();
            echo json_encode(['success' => false, 'msg' => 'No se pudo guardar el abono del préstamo; la comisión no fue registrada.']);
            exit;
        }

        $descuento_prestamo += $aplicado;
        $restanteComision = round($restanteComision - $aplicado, 2);
    }

    $descuento_prestamo = round($descuento_prestamo, 2);
    $comision_pago_neto = round(max(0, $comision_monto - $descuento_prestamo), 2);
    if ($comision_pago_neto > 0 && (trim($comision_banco_emi) === '' || trim($comision_banco_rec) === '' || trim($comision_ref) === '')) {
        mysqli_rollback($conexion);
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'Indica el banco y la referencia del pago neto que se entregará al vendedor.']);
        exit;
    }

    $foto_sql = $foto_sql !== '' ? ", comision_foto = '" . mysqli_real_escape_string($conexion, basename($nombre_archivo ?? '')) . "'" : '';
    $sql = "UPDATE cotizacion SET
            comision_pagada = 1,
            comision_porc = $comision_porc,
            comision_monto = $comision_monto,
            comision_descuento_prestamo = $descuento_prestamo,
            comision_pago_neto = $comision_pago_neto,
            comision_fecha = '$comision_fecha',
            comision_tasa = $comision_tasa,
            comision_banco_emi = '$comision_banco_emi',
            comision_banco_rec = '$comision_banco_rec',
            comision_ref = '$comision_ref'$foto_sql
            WHERE ID = $id AND comision_pagada = 0";

    if (!mysqli_query($conexion, $sql) || mysqli_affected_rows($conexion) !== 1) {
        mysqli_rollback($conexion);
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se pudo registrar la comisión; no se aplicaron abonos al préstamo.']);
        exit;
    }

    if (!mysqli_commit($conexion)) {
        mysqli_rollback($conexion);
        ob_clean();
        echo json_encode(['success' => false, 'msg' => 'No se pudo confirmar el registro de comisión y los abonos.']);
        exit;
    }
    $detalleAuditoria = "Registró comisión de $$comision_monto para cotización ID $id; descuento de préstamo: $$descuento_prestamo; neto pagado: $$comision_pago_neto.";
    registrar_auditoria($conexion, $id_usuario, 'EDITAR', 'cotizacion', $id, $detalleAuditoria);
    ob_clean();
    echo json_encode([
        'success' => true,
        'comision_bruta' => $comision_monto,
        'descuento_prestamo' => $descuento_prestamo,
        'neto_pagar' => $comision_pago_neto,
        'saldo_prestamo' => round(max(0, $deuda_inicial - $descuento_prestamo), 2),
        'vendedor_encontrado' => !empty($vinculo['encontrado'])
    ]);
    exit;
}
?>