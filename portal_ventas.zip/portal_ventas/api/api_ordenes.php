<?php
session_start();
session_write_close(); 
error_reporting(0); 
require_once '../../conexion.php';

// FORZAR UTF-8 Y JSON (Excepto para descargas)
if (!isset($_GET['accion']) || $_GET['accion'] !== 'descargar_fotos') {
    header('Content-Type: application/json; charset=utf-8');
}
mysqli_set_charset($conexion, "utf8mb4");

// AMPLIAR COLUMNAS AL VUELO PARA SOPORTAR MÚLTIPLES FOTOS SIN LÍMITE DE TEXTO
mysqli_query($conexion, "ALTER TABLE orden_fabrica MODIFY COLUMN foto TEXT");
mysqli_query($conexion, "ALTER TABLE medicion_personal ADD COLUMN IF NOT EXISTS cantidad INT DEFAULT 1");
mysqli_query($conexion, "ALTER TABLE medicion_personal ADD COLUMN IF NOT EXISTS tela VARCHAR(255) DEFAULT ''");
mysqli_query($conexion, "ALTER TABLE cotizacion ADD COLUMN IF NOT EXISTS prealerta_produccion TINYINT NOT NULL DEFAULT 0 COMMENT '0 sin prealerta, 1 pendiente, 2 revisada'");

if (!isset($_SESSION['usuario_id'])) {
    if (isset($_GET['accion']) && $_GET['accion'] === 'descargar_fotos') {
        die("Sesión expirada.");
    } else {
        echo json_encode(['success' => false, 'msg' => 'Sesión expirada']); exit;
    }
}

$id_usuario_actual = intval($_SESSION['usuario_id']);
$q_usr = mysqli_query($conexion, "SELECT rol, permisos FROM usuario WHERE ID = $id_usuario_actual");
$datos_usr = mysqli_fetch_assoc($q_usr);
$permisos_arr = explode(',', $datos_usr['permisos'] ?? '');
$rol_actual = strtolower(trim($datos_usr['rol'] ?? ''));
$es_master = ($rol_actual === 'master');

// VERIFICADOR DE PERMISO DE ALTERACIÓN (Vector 53 o Master)
$puede_alterar = in_array('53', $permisos_arr) || $es_master;

$accion = $_POST['accion'] ?? $_GET['accion'] ?? '';

function registrar_auditoria($con, $id_usr, $accion, $tabla, $id_reg, $detalle) {
    $acc = mysqli_real_escape_string($con, $accion);
    $tab = mysqli_real_escape_string($con, $tabla);
    $det = mysqli_real_escape_string($con, $detalle);
    mysqli_query($con, "INSERT INTO historial_actividad (id_usuario, accion, tabla_afectada, id_registro_afectado, fecha_hora, detalle_cambio) VALUES ($id_usr, '$acc', '$tab', $id_reg, NOW(), '$det')");
}

function extraer_codigo_final_cotizacion($nro_cotizacion, $id_cotizacion): string {
    $nro = trim((string)$nro_cotizacion);
    if (preg_match('/(\d+)\s*$/', $nro, $matches)) {
        return $matches[1];
    }
    return str_pad((string)intval($id_cotizacion), 5, '0', STR_PAD_LEFT);
}

function es_cargo_talla_extra_orden($tipo_prenda): bool {
    return preg_match('/^tallas?\s+extras?\b/i', trim((string)$tipo_prenda)) === 1;
}

function genero_especificacion_valido_orden($tipo_prenda, $genero): bool {
    $genero = trim((string)$genero);
    $nombre = mb_strtolower(trim((string)$tipo_prenda), 'UTF-8');
    if (strpos($nombre, 'gorra') !== false || strpos($nombre, 'visera') !== false || strpos($nombre, 'vicera') !== false) {
        return $genero === 'Accesorio';
    }
    if (strpos($nombre, 'bota') !== false) {
        return $genero === 'No aplica';
    }
    return in_array($genero, ['Dama', 'Caballero', 'Niña', 'Niño', 'U', 'Accesorio', 'No aplica'], true);
}

function obtener_tela_base_orden($detalle_diseno): string {
    if (!preg_match('/\bTela:\s*([^|]+)/i', (string)$detalle_diseno, $matches)) {
        return '';
    }

    $tela = trim($matches[1]);
    return in_array(mb_strtolower($tela, 'UTF-8'), ['n/a', 'no aplica', 'no especificada'], true) ? '' : $tela;
}

// ==============================================================================
// FUNCIÓN: ELIMINAR UNA FOTO ESPECÍFICA DE LA ORDEN
// ==============================================================================
if ($accion == 'eliminar_foto_orden') {
    if (!$puede_alterar) {
        echo json_encode(['success' => false, 'msg' => 'Seguridad: Sin permisos para alterar órdenes.']); exit;
    }
    
    $id_orden = intval($_POST['id_orden']);
    $foto_a_eliminar = trim(mysqli_real_escape_string($conexion, $_POST['foto']));
    
    $q = mysqli_query($conexion, "SELECT foto FROM orden_fabrica WHERE ID = $id_orden");
    if($row = mysqli_fetch_assoc($q)) {
        $fotos_actuales = explode(',', $row['foto']);
        
        $fotos_nuevas = array_filter($fotos_actuales, function($f) use ($foto_a_eliminar) {
            return trim($f) !== '' && trim($f) !== $foto_a_eliminar;
        });
        
        $foto_sql = empty($fotos_nuevas) ? "NULL" : "'" . implode(',', $fotos_nuevas) . "'";
        mysqli_query($conexion, "UPDATE orden_fabrica SET foto = $foto_sql WHERE ID = $id_orden");
        
        $file_path = "../../images/ordenes/" . $foto_a_eliminar;
        if(file_exists($file_path)) { @unlink($file_path); }
        
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'msg' => 'Orden no encontrada']);
    }
    exit;
}

// ==============================================================================
// FUNCIÓN: DESCARGAR FOTOS EN ARCHIVO ZIP
// ==============================================================================
if ($accion == 'descargar_fotos') {
    if (!in_array('10', $permisos_arr) && !$puede_alterar) { 
        die("No tienes permisos para ver esta orden."); 
    }

    $id = intval($_GET['id']);
    $q = mysqli_query($conexion, "SELECT nro_orden_fabrica, foto FROM orden_fabrica WHERE ID = $id");
    $ord = mysqli_fetch_assoc($q);

    if (!$ord || empty($ord['foto'])) {
        echo "<script>alert('Esta orden no tiene fotos adjuntas para descargar.'); window.close();</script>";
        exit;
    }

    $fotos = explode(',', $ord['foto']);
    $zip = new ZipArchive();
    $nro_limpio = preg_replace('/[^a-zA-Z0-9_-]/', '', $ord['nro_orden_fabrica']);
    $zip_name = "Fotos_Orden_" . $nro_limpio . ".zip";
    $zip_path = sys_get_temp_dir() . '/' . $zip_name;

    if ($zip->open($zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
        $has_files = false;
        foreach ($fotos as $f) {
            $f = trim($f);
            if(empty($f)) continue;
            
            $file_path = "../../images/ordenes/" . $f;
            if (!file_exists($file_path)) {
                $file_path = "../../images/uploads/" . $f;
            }

            if (file_exists($file_path)) {
                $zip->addFile($file_path, $f);
                $has_files = true;
            }
        }
        $zip->close();

        if ($has_files) {
            header('Content-Type: application/zip');
            header('Content-disposition: attachment; filename=' . $zip_name);
            header('Content-Length: ' . filesize($zip_path));
            readfile($zip_path);
            unlink($zip_path); 
            exit;
        } else {
            echo "<script>alert('Los archivos físicos ya no se encuentran en el servidor.'); window.close();</script>";
            exit;
        }
    } else {
        echo "<script>alert('Error interno al crear el archivo ZIP.'); window.close();</script>";
        exit;
    }
}

// ==============================================================================
// FUNCIÓN: REVERTIR ORDEN DE FÁBRICA A EDICIÓN (VECTOR 43)
// ==============================================================================
if ($accion == 'revertir_orden') {
    if (!in_array('43', $permisos_arr) && !$es_master) { 
        echo json_encode(['success' => false, 'msg' => 'Sin Vector [43] para revertir órdenes.']); exit; 
    }
    
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $transaccion_iniciada = false;
    try {
        $id_orden = intval($_POST['id'] ?? 0);
        mysqli_begin_transaction($conexion);
        $transaccion_iniciada = true;

        $q_ord = mysqli_query($conexion, "SELECT id_cotizacion, nro_orden_fabrica FROM orden_fabrica WHERE ID = $id_orden FOR UPDATE");
        $row_ord = mysqli_fetch_assoc($q_ord);
        if (!$row_ord) {
            throw new RuntimeException('La orden de fábrica no existe.');
        }

        $id_cotizacion = intval($row_ord['id_cotizacion']);
        $nro_ord = $row_ord['nro_orden_fabrica'] ?? "Desconocida";
        if ($id_cotizacion <= 0) {
            throw new RuntimeException('La orden no está vinculada a una cotización y no se puede devolver automáticamente.');
        }

        $q_detalles = mysqli_query($conexion, "SELECT ID FROM detalle_orden_fabrica WHERE id_orden_fabrica = $id_orden");
        while($d = mysqli_fetch_assoc($q_detalles)) {
            mysqli_query($conexion, "DELETE FROM medicion_personal WHERE id_detalle_orden_fabrica = {$d['ID']}");
            mysqli_query($conexion, "DELETE FROM posicion WHERE id_detalle_orden_fabrica = {$d['ID']}");
        }
        mysqli_query($conexion, "DELETE FROM detalle_orden_fabrica WHERE id_orden_fabrica = $id_orden");
        mysqli_query($conexion, "DELETE FROM orden_fabrica WHERE ID = $id_orden");
        mysqli_query($conexion, "UPDATE cotizacion SET enviado_logistica = 0, prealerta_produccion = IF(prealerta_produccion IN (1, 2), 1, 0) WHERE ID = $id_cotizacion");
        registrar_auditoria($conexion, $id_usuario_actual, 'ELIMINAR/REVERTIR', 'orden_fabrica', $id_orden, "Revirtió la Orden $nro_ord hacia Ventas (se conservaron las últimas reglas de la cotización)");
        mysqli_commit($conexion);
        $transaccion_iniciada = false;
        mysqli_report(MYSQLI_REPORT_OFF);
        echo json_encode(['success' => true]);
    } catch (Throwable $e) {
        if ($transaccion_iniciada) {
            mysqli_rollback($conexion);
        }
        mysqli_report(MYSQLI_REPORT_OFF);
        error_log('Error al revertir orden de fábrica: ' . $e->getMessage());
        echo json_encode([
            'success' => false,
            'msg' => $e instanceof RuntimeException ? $e->getMessage() : 'No se pudo revertir la orden. No se aplicaron cambios; intenta nuevamente.'
        ]);
    }
    exit;
}

if ($accion == 'listar_cotizaciones_aptas') {
    if (!in_array('13', $permisos_arr) && !in_array('11', $permisos_arr) && !$es_master) {
        echo json_encode(['success' => true, 'data' => []]); exit;
    }

    // Incluye cotizaciones enviadas a logística (tanto las pagadas como las autorizadas sin pago por el Master)
    $sql = "SELECT c.ID, c.nro_cotizacion, cli.nombre AS cliente 
            FROM cotizacion c 
            LEFT JOIN cliente cli ON c.id_cliente = cli.ID 
            LEFT JOIN orden_fabrica ofab ON c.ID = ofab.id_cotizacion
            WHERE (c.estado_pago IN ('Pagado', 'Pago Medio', 'Pago Inicial', 'Muestra Física') OR c.enviado_logistica = 1)
              AND c.enviado_logistica = 1 
              AND ofab.ID IS NULL 
            ORDER BY c.ID DESC";
            
    $q = mysqli_query($conexion, $sql);
    $data = [];
    if($q) {
        while($r = mysqli_fetch_assoc($q)) {
            $r['cliente'] = $r['cliente'] ?? 'Cliente Desconocido';
            $data[] = $r;
        }
    }
    echo json_encode(['success' => true, 'data' => $data]);
    exit;
}

if ($accion == 'listar_ordenes') {
    if (!in_array('10', $permisos_arr) && !$es_master) { 
        echo json_encode(['success' => false, 'msg' => 'Sin Vector [10]']); exit; 
    }

    // Autocorrección silenciosa: repara órdenes que hayan quedado con OF-2026 usando el código final de su cotización
    $q_fix_2026 = mysqli_query($conexion, "
        SELECT o.ID, o.id_cotizacion, o.nro_orden_fabrica, c.nro_cotizacion
        FROM orden_fabrica o
        JOIN cotizacion c ON o.id_cotizacion = c.ID
        WHERE o.nro_orden_fabrica IN ('OF-2026', 'OF-2025', 'OF-2027')
    ");
    if ($q_fix_2026) {
        while ($f2026 = mysqli_fetch_assoc($q_fix_2026)) {
            $cod_real = extraer_codigo_final_cotizacion($f2026['nro_cotizacion'], $f2026['id_cotizacion']);
            if ($cod_real !== '' && $cod_real !== '2026') {
                $nuevo_nro_of = mysqli_real_escape_string($conexion, 'OF-' . $cod_real);
                mysqli_query($conexion, "UPDATE orden_fabrica SET nro_orden_fabrica = '$nuevo_nro_of' WHERE ID = " . intval($f2026['ID']));
            }
        }
    }

    $condiciones = [];
    if (isset($_GET['id_vendedor']) && is_numeric($_GET['id_vendedor'])) {
        $id_vendedor = intval($_GET['id_vendedor']);
        $condiciones[] = "o.id_usuario_vendedor = $id_vendedor";
    }

    $busqueda = trim((string)($_GET['busqueda'] ?? ''));
    if ($busqueda !== '') {
        $busqueda_sql = mysqli_real_escape_string($conexion, $busqueda);
        $busqueda_numeros = preg_replace('/\D+/', '', $busqueda);
        $criterios_busqueda = [
            "cli.nombre LIKE '%$busqueda_sql%'",
            "o.nro_orden_fabrica LIKE '%$busqueda_sql%'"
        ];
        if ($busqueda_numeros !== '') {
            $busqueda_numeros_sql = mysqli_real_escape_string($conexion, $busqueda_numeros);
            $criterios_busqueda[] = "c.nro_cotizacion LIKE '%$busqueda_numeros_sql%'";
        }
        $condiciones[] = '(' . implode(' OR ', $criterios_busqueda) . ')';
    }

    $where = !empty($condiciones) ? 'WHERE ' . implode(' AND ', $condiciones) : '';
    $sql = "SELECT o.ID, o.id_cotizacion, o.nro_orden_fabrica, o.fecha_emision, o.fecha_entrega, cli.nombre AS cliente,
                   c.nro_cotizacion, o.es_express, o.foto, o.id_usuario_vendedor
            FROM orden_fabrica o 
            LEFT JOIN cliente cli ON o.id_cliente = cli.ID 
            LEFT JOIN cotizacion c ON o.id_cotizacion = c.ID
            $where
            ORDER BY o.ID DESC";
            
    $q = mysqli_query($conexion, $sql);
    $data = [];
    
    if($q) {
        while($r = mysqli_fetch_assoc($q)) {
            $fecha_ent = $r['fecha_entrega'];
            if (empty($fecha_ent) || strpos($fecha_ent, '0000') !== false || strpos($fecha_ent, '-0001') !== false) {
                $r['fecha_entrega'] = '-';
            } else {
                $r['fecha_entrega'] = date('d/m/Y', strtotime($fecha_ent));
            }
            
            $fecha_emi = $r['fecha_emision'];
            if (empty($fecha_emi) || strpos($fecha_emi, '0000') !== false || strpos($fecha_emi, '-0001') !== false) {
                $r['fecha_emision'] = '-';
            } else {
                $r['fecha_emision'] = date('d/m/Y', strtotime($fecha_emi));
            }
            
            $r['tiene_fotos'] = !empty($r['foto']) ? true : false;
            unset($r['foto']); 
            
            $r['cliente'] = $r['cliente'] ?? 'Cliente Eliminado / Desconocido';
            $r['puede_alterar'] = $puede_alterar;

            $data[] = $r;
        }
        echo json_encode(['success' => true, 'data' => $data]);
    } else {
        echo json_encode(['success' => false, 'msg' => 'Error SQL: ' . mysqli_error($conexion)]);
    }
    exit;
}

if ($accion == 'obtener_datos_cotizacion') {
    if (!in_array('11', $permisos_arr) && !$es_master) { 
        echo json_encode(['success' => false, 'msg' => 'Sin Vector [11]']); exit; 
    }
    
    $id_cot = intval($_GET['id_cotizacion']);
    $q_cot = mysqli_query($conexion, "SELECT id_cliente, notas, fotos_diseno FROM cotizacion WHERE ID = $id_cot");
    $cot = mysqli_fetch_assoc($q_cot);
    
    $q_det = mysqli_query($conexion, "
        SELECT d.*, c.nombre as categoria 
        FROM detalle_cotizacion d 
        LEFT JOIN productos p ON d.id_producto = p.id
        LEFT JOIN subcategorias s ON p.id_subcategoria = s.id
        LEFT JOIN categorias c ON s.id_categoria = c.id
        WHERE d.id_cotizacion = $id_cot
    ");
    $detalles = [];
    if($q_det){
        while($r = mysqli_fetch_assoc($q_det)) {
            $r['es_cargo_talla_extra'] = es_cargo_talla_extra_orden($r['tipo_prenda']);
            $r['es_arte'] = stripos($r['detalle_diseno'] ?? '', 'Ubicación:') !== false
                || preg_match('/^(bordado|serigraf|dtf|vinil)/i', trim((string)($r['tipo_prenda'] ?? ''))) === 1;
            $r['tela_cotizada'] = obtener_tela_base_orden($r['detalle_diseno'] ?? '');
            $detalles[] = $r;
        }
    }
    
    $q_mat = mysqli_query($conexion, "SELECT ID, nombre, color FROM materia_prima ORDER BY nombre ASC");
    $telas = [];
    if($q_mat){
        while($r = mysqli_fetch_assoc($q_mat)) $telas[] = $r;
    }

    echo json_encode([
        'success' => true, 
        'id_cliente' => $cot['id_cliente'] ?? 0, 
        'notas_cotizacion' => $cot['notas'] ?? '',
        'fotos_diseno' => $cot['fotos_diseno'] ?? '',
        'detalles' => $detalles, 
        'telas' => $telas
    ]);
    exit;
}

if ($accion == 'guardar_orden') {
    if (!in_array('11', $permisos_arr) && !$es_master) { 
        echo json_encode(['success' => false, 'msg' => 'Sin Vector [11] para generar']); exit; 
    }

    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $archivos_subidos = [];
    $transaccion_iniciada = false;
    try {
        mysqli_begin_transaction($conexion);
        $transaccion_iniciada = true;
        $id_cotizacion = intval($_POST['id_cotizacion'] ?? 0);
        if ($id_cotizacion <= 0) {
            throw new RuntimeException('Selecciona una cotización válida.');
        }

        $q_cotizacion = mysqli_query($conexion, "
            SELECT id_cliente, id_vendedor, nro_cotizacion, estado_pago, enviado_logistica, tipo_cotizacion, notas, fotos_diseno
            FROM cotizacion
            WHERE ID = $id_cotizacion
            FOR UPDATE
        ");
        $cotizacion = mysqli_fetch_assoc($q_cotizacion);
        if (!$cotizacion) {
            throw new RuntimeException('No se encontró la cotización seleccionada.');
        }
        if (intval($cotizacion['enviado_logistica']) !== 1) {
            throw new RuntimeException('La cotización todavía no fue enviada a logística. Revísala y envíala antes de crear la orden.');
        }
        // Solo se permite estado 'sin pagar' si ya tiene enviado_logistica == 1 (autorizado por el Master en api_cotizaciones.php)
        if (!in_array($cotizacion['estado_pago'], ['Pagado', 'Pago Medio', 'Pago Inicial', 'Muestra Física'], true) && intval($cotizacion['enviado_logistica']) !== 1) {
            throw new RuntimeException('Solo el usuario Master puede autorizar y enviar a logística una cotización sin pago.');
        }

        $q_orden_existente = mysqli_query($conexion, "SELECT ID FROM orden_fabrica WHERE id_cotizacion = $id_cotizacion LIMIT 1");
        if (mysqli_fetch_assoc($q_orden_existente)) {
            throw new RuntimeException('Esta cotización ya tiene una orden de fábrica emitida.');
        }

        $id_cliente = intval($cotizacion['id_cliente']);
        if ($id_cliente <= 0) {
            throw new RuntimeException('La cotización no tiene un cliente válido asociado.');
        }

        $fecha_actual = date('Y-m-d');
        $fecha_entrega_post = trim((string)($_POST['fecha_entrega'] ?? ''));
        $fecha_entrega = ($fecha_entrega_post !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $fecha_entrega_post))
            ? $fecha_entrega_post
            : date('Y-m-d', strtotime($fecha_actual . ' + 20 days'));
        $es_express = intval($_POST['es_express'] ?? 0) === 1 ? 1 : 0;
        $acepta_parciales = intval($_POST['acepta_parciales'] ?? 0) === 1 ? 1 : 0;
        $notas_post = trim((string)($_POST['descripcion_global'] ?? ''));
        $descripcion_global = mysqli_real_escape_string($conexion, $notas_post !== '' ? $notas_post : ($cotizacion['notas'] ?? ''));

        $fotos_guardadas = array_values(array_filter(array_map('trim', explode(',', $cotizacion['fotos_diseno'] ?? ''))));
        if (isset($_FILES['orden_foto'])) {
            $dir_uploads = "../../images/ordenes/";
            if (!is_dir($dir_uploads)) mkdir($dir_uploads, 0777, true);
            $total_archivos = is_array($_FILES['orden_foto']['name']) ? count($_FILES['orden_foto']['name']) : 0;
            for ($i = 0; $i < $total_archivos; $i++) {
                if ($_FILES['orden_foto']['error'][$i] === UPLOAD_ERR_OK) {
                    $ext = strtolower(pathinfo($_FILES['orden_foto']['name'][$i], PATHINFO_EXTENSION));
                    $nombre_archivo = "orden_" . time() . "_" . rand(100, 999) . "_" . $i . "." . $ext;
                    if (move_uploaded_file($_FILES['orden_foto']['tmp_name'][$i], $dir_uploads . $nombre_archivo)) {
                        $fotos_guardadas[] = $nombre_archivo;
                        $archivos_subidos[] = $dir_uploads . $nombre_archivo;
                    }
                }
            }
        }

        // Respaldo desde la cotización si el cliente no envió arrays manuales
        $q_detalles_cotizacion = mysqli_query($conexion, "
            SELECT ID, id_producto, tipo_prenda, genero, cantidad, detalle_diseno, especificaciones_tallas
            FROM detalle_cotizacion
            WHERE id_cotizacion = $id_cotizacion
            ORDER BY ID
        ");
        $prendas_servidor = [];
        $medidas_servidor = [];
        $artes_servidor = [];

        while ($detalle_cotizacion = mysqli_fetch_assoc($q_detalles_cotizacion)) {
            $tipo_base = trim((string)($detalle_cotizacion['tipo_prenda'] ?? ''));
            $diseno = (string)($detalle_cotizacion['detalle_diseno'] ?? '');
            if ($tipo_base === '' || es_cargo_talla_extra_orden($tipo_base)) {
                continue;
            }
            if (stripos($diseno, 'Ubicación:') !== false || preg_match('/^(bordado|serigraf|dtf|vinil)/i', $tipo_base) === 1) {
                $ubicacion = '';
                $vinculo = '';
                if (preg_match('/\[Para:\s*(.*?)\]\s*-\s*Ubicación:\s*(.*)$/iu', $diseno, $partes_arte)) {
                    $vinculo = trim($partes_arte[1]);
                    $ubicacion = trim($partes_arte[2]);
                } elseif (preg_match('/Ubicación:\s*(.*)$/iu', $diseno, $partes_arte)) {
                    $ubicacion = trim($partes_arte[1]);
                }
                $artes_servidor[] = [
                    'elemento' => $tipo_base,
                    'cantidad' => max(1, intval($detalle_cotizacion['cantidad'] ?? 1)),
                    'vinculo' => $vinculo,
                    'ubicacion' => $ubicacion !== '' ? $ubicacion : 'Por definir'
                ];
                continue;
            }

            $cantidad_cotizada = max(1, intval($detalle_cotizacion['cantidad'] ?? 1));
            $specs = json_decode($detalle_cotizacion['especificaciones_tallas'] ?? '', true);
            $tela_base = obtener_tela_base_orden($diseno);
            $genero_base = trim((string)($detalle_cotizacion['genero'] ?? ''));
            $etiqueta_prenda = $tipo_base . ($genero_base !== '' && $genero_base !== 'No especificado' ? " ($genero_base)" : '');

            if (is_array($specs) && !empty($specs)) {
                foreach ($specs as $spec) {
                    if (!is_array($spec)) continue;
                    $medidas_servidor[] = [
                        'tipo_prenda' => $etiqueta_prenda,
                        'nombre' => $spec['nombre'] ?? '',
                        'genero' => $spec['genero'] ?? $genero_base,
                        'talla' => $spec['talla'] ?? 'M',
                        'obs' => $spec['obs'] ?? '',
                        'cantidad' => max(1, intval($spec['cantidad'] ?? 1)),
                        'tela' => trim((string)($spec['tela'] ?? $tela_base)),
                        'medidas_personales' => is_array($spec['medidas_personales'] ?? null) ? $spec['medidas_personales'] : []
                    ];
                }
            }

            $id_materia = 0;
            $tela_buscar = (is_array($specs) && !empty($specs[0]['tela'])) ? trim((string)$specs[0]['tela']) : $tela_base;
            if ($tela_buscar !== '' && preg_match('/^(.+)\s+\(([^()]*)\)$/u', $tela_buscar, $partes_tela)) {
                $nombre_tela = mysqli_real_escape_string($conexion, trim($partes_tela[1]));
                $color_tela = mysqli_real_escape_string($conexion, trim($partes_tela[2]));
                $q_materia = mysqli_query($conexion, "SELECT ID FROM materia_prima WHERE TRIM(nombre) = '$nombre_tela' AND TRIM(color) = '$color_tela' LIMIT 1");
                if ($fila_materia = mysqli_fetch_assoc($q_materia)) {
                    $id_materia = intval($fila_materia['ID']);
                }
            }

            $prendas_servidor[] = [
                'tipo' => $etiqueta_prenda,
                'cantidad' => $cantidad_cotizada,
                'id_materia' => $id_materia
            ];
        }

        // Si el formulario de Nueva Orden envió prendas/medidas/artes/sastrería revisados por el usuario, los usamos
        $prendas_post = json_decode($_POST['prendas'] ?? '[]', true);
        $artes_post = json_decode($_POST['artes'] ?? '[]', true);
        $medidas_post = json_decode($_POST['medidas'] ?? '[]', true);
        $sastreria_post = json_decode($_POST['sastreria'] ?? '[]', true);

        $prendas = (is_array($prendas_post) && count($prendas_post) > 0) ? $prendas_post : $prendas_servidor;
        $artes = (is_array($artes_post) && count($artes_post) > 0) ? $artes_post : $artes_servidor;
        $medidas = (is_array($medidas_post) && count($medidas_post) > 0) ? $medidas_post : $medidas_servidor;
        $sastreria = is_array($sastreria_post) ? $sastreria_post : [];

        $foto_sql = "NULL";
        if (!empty($fotos_guardadas)) {
            $foto_str = mysqli_real_escape_string($conexion, implode(',', array_unique($fotos_guardadas)));
            $foto_sql = "'$foto_str'";
        }

        // EXTRAER SIEMPRE EL CÓDIGO ÚNICO DEL FINAL DE LA COTIZACIÓN (NUNCA EL AÑO 2026)
        $numeros_cot = extraer_codigo_final_cotizacion($cotizacion['nro_cotizacion'], $id_cotizacion);
        $nro_orden = "OF-" . $numeros_cot;

        $vendedor_orig = intval($cotizacion['id_vendedor'] ?? $id_usuario_actual);

        $sql_ord = "INSERT INTO orden_fabrica (id_cliente, id_cotizacion, nro_orden_fabrica, fecha_emision, fecha_entrega, es_express, id_usuario_vendedor, acepta_entregas_parciales, descripcion, fecha_ingreso_orden, foto) 
                    VALUES ($id_cliente, $id_cotizacion, '$nro_orden', '$fecha_actual', '$fecha_entrega', $es_express, $vendedor_orig, $acepta_parciales, '$descripcion_global', '$fecha_actual', $foto_sql)";
                    
        mysqli_query($conexion, $sql_ord);
        $id_orden = mysqli_insert_id($conexion);
        registrar_auditoria($conexion, $id_usuario_actual, 'CREAR', 'orden_fabrica', $id_orden, "Generó Orden de Producción $nro_orden (Base: Cotización ID $id_cotizacion)");

        $prendas_agrupadas = [];
        if (is_array($prendas)) {
            foreach ($prendas as $p) {
                if (es_cargo_talla_extra_orden($p['tipo'] ?? '')) continue;
                $tipo = trim((string)($p['tipo'] ?? ''));
                if ($tipo === '') continue;
                if (!isset($prendas_agrupadas[$tipo])) {
                    $prendas_agrupadas[$tipo] = $p;
                } else {
                    $prendas_agrupadas[$tipo]['cantidad'] += intval($p['cantidad']);
                }
            }
        }

        // Construir mapa de bordados/artes por prenda para que siempre salgan en la observación de la camisa/prenda relacionada
        $bordados_por_prenda = [];
        if (is_array($artes)) {
            foreach ($artes as $a_item) {
                $elem_str = trim((string)($a_item['elemento'] ?? ''));
                $ubi_str = trim((string)($a_item['ubicacion'] ?? ''));
                $vinc_str = trim((string)($a_item['vinculo'] ?? ''));
                if ($elem_str === '') continue;
                $txt_arte = ($ubi_str !== '' && strtolower($ubi_str) !== 'por definir') ? "$elem_str ($ubi_str)" : $elem_str;
                if ($vinc_str !== '') {
                    $bordados_por_prenda[$vinc_str][] = $txt_arte;
                } else {
                    $bordados_por_prenda['__GENERAL__'][] = $txt_arte;
                }
            }
        }

        $mapa_prendas = [];
        foreach ($prendas_agrupadas as $tipo => $p) {
            $id_materia = intval($p['id_materia'] ?? 0);
            $tipo_esc = mysqli_real_escape_string($conexion, $tipo);
            $cant = max(1, intval($p['cantidad'] ?? 1));
            $id_mat_sql = $id_materia > 0 ? $id_materia : "NULL";
            
            mysqli_query($conexion, "INSERT INTO detalle_orden_fabrica (id_orden_fabrica, id_materia, tipo_prenda, cantidad) 
                                     VALUES ($id_orden, $id_mat_sql, '$tipo_esc', $cant)");
            $id_detalle = mysqli_insert_id($conexion);
            $mapa_prendas[$tipo] = $id_detalle;

            $artes_de_esta_prenda = $bordados_por_prenda[$tipo] ?? [];
            if (empty($artes_de_esta_prenda) && !empty($bordados_por_prenda['__GENERAL__'])) {
                if (count($prendas_agrupadas) === 1 || preg_match('/(camisa|chemis|chemise|franela|jersey|filipina|bata|chaqueta|chaleco|delantal)/i', $tipo)) {
                    $artes_de_esta_prenda = $bordados_por_prenda['__GENERAL__'];
                }
            }
            $texto_bordado_prenda = implode(' + ', array_unique($artes_de_esta_prenda));
            
            if (is_array($medidas)) {
                foreach ($medidas as $m) {
                    if (trim((string)($m['tipo_prenda'] ?? '')) === $tipo) {
                        $nom = mysqli_real_escape_string($conexion, empty($m['nombre']) ? '-' : $m['nombre']);
                        $gen = mysqli_real_escape_string($conexion, $m['genero'] ?? 'U');
                        $tal = mysqli_real_escape_string($conexion, $m['talla'] ?? 'U');
                        $obs_raw = trim((string)($m['obs'] ?? ''));
                        if ($texto_bordado_prenda !== '' && stripos($obs_raw, 'bordado') === false && stripos($obs_raw, $texto_bordado_prenda) === false) {
                            $obs_raw = $obs_raw !== '' ? ($obs_raw . ' | ' . $texto_bordado_prenda) : $texto_bordado_prenda;
                        }
                        $obs = mysqli_real_escape_string($conexion, $obs_raw);
                        
                        $cant_med = max(1, intval($m['cantidad'] ?? 1));
                        $tela_med = mysqli_real_escape_string($conexion, $m['tela'] ?? '');
                        $medidas_personales = is_array($m['medidas_personales'] ?? null) ? $m['medidas_personales'] : [];
                        $hom = floatval($medidas_personales['hombro'] ?? 0);
                        $bus = floatval($medidas_personales['busto_torax'] ?? 0);
                        $cin = floatval($medidas_personales['cintura'] ?? 0);
                        $cad = floatval($medidas_personales['cadera'] ?? 0);
                        $lcam = floatval($medidas_personales['largo_camisa'] ?? 0);
                        $lbra = floatval($medidas_personales['largo_brazo'] ?? 0);
                        $lpan = floatval($medidas_personales['largo_pantalon'] ?? 0);
                        $tiro = floatval($medidas_personales['tiro_total'] ?? 0);
                        $mus = floatval($medidas_personales['ancho_muslo'] ?? 0);
                        $rod = floatval($medidas_personales['ancho_rodilla'] ?? 0);
                        $talon = floatval($medidas_personales['ancho_talon'] ?? 0);
                        
                        mysqli_query($conexion, "INSERT INTO medicion_personal (
                            id_detalle_orden_fabrica, nombre, genero, talla_asignada, observacion, cantidad, tela,
                            hombro, busto_torax, cintura, cadera, largo_camisa, largo_brazo, largo_pantalon,
                            tiro_total, ancho_muslo, ancho_rodilla, ancho_talon
                        ) VALUES (
                            $id_detalle, '$nom', '$gen', '$tal', '$obs', $cant_med, '$tela_med',
                            $hom, $bus, $cin, $cad, $lcam, $lbra, $lpan, $tiro, $mus, $rod, $talon
                        )");
                        $id_medicion = mysqli_insert_id($conexion);
                        
                        if (is_array($sastreria)) {
                            foreach ($sastreria as $s) {
                                if (trim((string)($s['nombre'] ?? '')) === trim((string)($m['nombre'] ?? '')) && trim((string)($s['tipo_prenda'] ?? '')) === trim((string)($m['tipo_prenda'] ?? ''))) {
                                    $hom = floatval($s['hombro'] ?? 0); $bus = floatval($s['busto'] ?? 0); $cin = floatval($s['cintura'] ?? 0); $cad = floatval($s['cadera'] ?? 0);
                                    $lcam = floatval($s['l_camisa'] ?? 0); $lbra = floatval($s['l_brazo'] ?? 0); $lpan = floatval($s['l_pantalon'] ?? 0); $tiro = floatval($s['tiro'] ?? 0);
                                    $mus = floatval($s['muslo'] ?? 0); $rod = floatval($s['rodilla'] ?? 0); $talon = floatval($s['talon'] ?? 0);
                                    
                                    mysqli_query($conexion, "UPDATE medicion_personal
                                                             SET hombro=IF($hom > 0, $hom, hombro),
                                                                 busto_torax=IF($bus > 0, $bus, busto_torax),
                                                                 cintura=IF($cin > 0, $cin, cintura),
                                                                 cadera=IF($cad > 0, $cad, cadera),
                                                                 largo_camisa=IF($lcam > 0, $lcam, largo_camisa),
                                                                 largo_brazo=IF($lbra > 0, $lbra, largo_brazo),
                                                                 largo_pantalon=IF($lpan > 0, $lpan, largo_pantalon),
                                                                 tiro_total=IF($tiro > 0, $tiro, tiro_total),
                                                                 ancho_muslo=IF($mus > 0, $mus, ancho_muslo),
                                                                 ancho_rodilla=IF($rod > 0, $rod, ancho_rodilla),
                                                                 ancho_talon=IF($talon > 0, $talon, ancho_talon)
                                                             WHERE ID=$id_medicion");
                                }
                            }
                        }
                    }
                }
            }
        }

        if (is_array($artes)) {
            $primer_id_detalle = !empty($mapa_prendas) ? reset($mapa_prendas) : 0;
            foreach ($artes as $a) {
                $vinculo = trim((string)($a['vinculo'] ?? ''));
                $id_fk = $mapa_prendas[$vinculo] ?? $primer_id_detalle;
                if ($id_fk > 0) {
                    $ubicacion = mysqli_real_escape_string($conexion, $a['ubicacion'] ?? 'Por definir');
                    $elemento = mysqli_real_escape_string($conexion, $a['elemento'] ?? 'Arte');
                    $obs = mysqli_real_escape_string($conexion, "Cant: " . ($a['cantidad'] ?? 1));
                    mysqli_query($conexion, "INSERT INTO posicion (id_detalle_orden_fabrica, ubicacion, elemento, observacion) 
                                             VALUES ($id_fk, '$ubicacion', '$elemento', '$obs')");
                }
            }
        }
        
        mysqli_commit($conexion);
        $transaccion_iniciada = false;
        mysqli_report(MYSQLI_REPORT_OFF);
        echo json_encode(['success' => true, 'id_orden' => $id_orden]);
    } catch (Throwable $e) {
        if ($transaccion_iniciada) {
            mysqli_rollback($conexion);
        }
        foreach ($archivos_subidos as $archivo) {
            if (is_file($archivo)) {
                unlink($archivo);
            }
        }
        mysqli_report(MYSQLI_REPORT_OFF);
        error_log('Error al generar orden de fábrica desde cotización ' . $id_cotizacion . ': ' . $e->getMessage());
        echo json_encode(['success' => false, 'msg' => $e instanceof RuntimeException ? $e->getMessage() : 'No se pudo completar la orden. No se guardaron cambios; verifica la cotización e intenta nuevamente.']);
    }
    exit;
}

// OBTENER LA ORDEN COMPLETA PARA LLENAR EL MODAL DE EDICIÓN
if ($accion == 'obtener_orden_completa') {
    if (!$puede_alterar) {
        echo json_encode(['success' => false, 'msg' => 'Seguridad: Sin Vector [53] para alterar órdenes.']); exit;
    }
    
    $id_orden = intval($_GET['id_orden']);
    $q_ord = mysqli_query($conexion, "SELECT o.*, c.nro_cotizacion, cli.nombre as cliente_nombre FROM orden_fabrica o LEFT JOIN cotizacion c ON o.id_cotizacion=c.ID LEFT JOIN cliente cli ON o.id_cliente=cli.ID WHERE o.ID=$id_orden");
    $orden = mysqli_fetch_assoc($q_ord);

    $detalles = [];
    $q_d = mysqli_query($conexion, "SELECT * FROM detalle_orden_fabrica WHERE id_orden_fabrica=$id_orden");
    while($d = mysqli_fetch_assoc($q_d)) { 
        if (es_cargo_talla_extra_orden($d['tipo_prenda'])) continue;
        $detalles[] = $d; 
    }

    $medidas = [];
    $q_m = mysqli_query($conexion, "SELECT m.*, d.tipo_prenda, d.id_materia FROM medicion_personal m JOIN detalle_orden_fabrica d ON m.id_detalle_orden_fabrica=d.ID WHERE d.id_orden_fabrica=$id_orden");
    while($m = mysqli_fetch_assoc($q_m)) { $medidas[] = $m; }

    $posiciones = [];
    $q_p = mysqli_query($conexion, "SELECT p.*, d.tipo_prenda FROM posicion p JOIN detalle_orden_fabrica d ON p.id_detalle_orden_fabrica=d.ID WHERE d.id_orden_fabrica=$id_orden");
    while($p = mysqli_fetch_assoc($q_p)) { $posiciones[] = $p; }

    $telas = [];
    $q_mat = mysqli_query($conexion, "SELECT ID, nombre, color FROM materia_prima ORDER BY nombre ASC");
    while($r = mysqli_fetch_assoc($q_mat)) { $telas[] = $r; }

    echo json_encode([
        'success' => true,
        'orden' => $orden,
        'detalles' => $detalles,
        'medidas' => $medidas,
        'posiciones' => $posiciones,
        'telas' => $telas
    ]);
    exit;
}

// GUARDAR LA ALTERACIÓN DE LA ORDEN
if ($accion == 'guardar_edicion_orden') {
    if (!$puede_alterar) {
        echo json_encode(['success' => false, 'msg' => 'Seguridad: Sin Vector [53] para alterar órdenes.']); exit;
    }

    $id_orden = intval($_POST['id_orden']);
    $fecha_entrega = mysqli_real_escape_string($conexion, $_POST['fecha_entrega']);
    $es_express = intval($_POST['es_express'] ?? 0);
    $acepta_parciales = intval($_POST['acepta_parciales'] ?? 0);
    $descripcion_global = mysqli_real_escape_string($conexion, $_POST['descripcion_global'] ?? '');

    $fotos_extra = [];
    if (isset($_FILES['orden_foto_extra'])) {
        $dir_uploads = "../../images/ordenes/";
        if (!is_dir($dir_uploads)) mkdir($dir_uploads, 0777, true);
        $total_archivos = is_array($_FILES['orden_foto_extra']['name']) ? count($_FILES['orden_foto_extra']['name']) : 0;
        for ($i = 0; $i < $total_archivos; $i++) {
            if ($_FILES['orden_foto_extra']['error'][$i] == UPLOAD_ERR_OK) {
                $ext = strtolower(pathinfo($_FILES['orden_foto_extra']['name'][$i], PATHINFO_EXTENSION));
                $nombre_archivo = "orden_ext_" . time() . "_" . rand(100,999) . "_" . $i . "." . $ext;
                if (move_uploaded_file($_FILES['orden_foto_extra']['tmp_name'][$i], $dir_uploads . $nombre_archivo)) {
                    $fotos_extra[] = $nombre_archivo;
                }
            }
        }
    }

    $q_ord = mysqli_query($conexion, "SELECT foto, nro_orden_fabrica, id_cotizacion FROM orden_fabrica WHERE ID = $id_orden");
    $row_ord = mysqli_fetch_assoc($q_ord);
    $foto_actual = $row_ord['foto'];

    if (!empty($fotos_extra)) {
        $foto_str = implode(',', $fotos_extra);
        if (empty($foto_actual)) { $foto_actual = $foto_str; } 
        else { $foto_actual .= "," . $foto_str; }
    }
    
    $foto_sql = empty($foto_actual) ? "NULL" : "'" . mysqli_real_escape_string($conexion, $foto_actual) . "'";

    mysqli_query($conexion, "UPDATE orden_fabrica SET fecha_entrega='$fecha_entrega', es_express=$es_express, acepta_entregas_parciales=$acepta_parciales, descripcion='$descripcion_global', foto=$foto_sql WHERE ID=$id_orden");

    $q_detalles = mysqli_query($conexion, "SELECT ID FROM detalle_orden_fabrica WHERE id_orden_fabrica = $id_orden");
    while($d = mysqli_fetch_assoc($q_detalles)) {
        mysqli_query($conexion, "DELETE FROM medicion_personal WHERE id_detalle_orden_fabrica = {$d['ID']}");
        mysqli_query($conexion, "DELETE FROM posicion WHERE id_detalle_orden_fabrica = {$d['ID']}");
    }
    mysqli_query($conexion, "DELETE FROM detalle_orden_fabrica WHERE id_orden_fabrica = $id_orden");

    $prendas = json_decode($_POST['prendas'], true);
    $artes = json_decode($_POST['artes'], true);
    $medidas = json_decode($_POST['medidas'], true);
    $sastreria = json_decode($_POST['sastreria'], true);

    $prendas_agrupadas = [];
    if (is_array($prendas)) {
        foreach ($prendas as $p) {
            if (es_cargo_talla_extra_orden($p['tipo'])) {
                continue;
            }
            $tipo = trim($p['tipo']);
            if (!isset($prendas_agrupadas[$tipo])) { $prendas_agrupadas[$tipo] = $p; } 
            else { $prendas_agrupadas[$tipo]['cantidad'] += intval($p['cantidad']); }
        }
    }

    // Construir mapa de bordados/artes también al editar la orden
    $bordados_por_prenda = [];
    if (is_array($artes)) {
        foreach ($artes as $a_item) {
            $elem_str = trim((string)($a_item['elemento'] ?? ''));
            $ubi_str = trim((string)($a_item['ubicacion'] ?? ''));
            $vinc_str = trim((string)($a_item['vinculo'] ?? ''));
            if ($elem_str === '') continue;
            $txt_arte = ($ubi_str !== '' && strtolower($ubi_str) !== 'por definir') ? "$elem_str ($ubi_str)" : $elem_str;
            if ($vinc_str !== '') {
                $bordados_por_prenda[$vinc_str][] = $txt_arte;
            } else {
                $bordados_por_prenda['__GENERAL__'][] = $txt_arte;
            }
        }
    }
    
    $mapa_prendas = [];

    foreach ($prendas_agrupadas as $tipo => $p) {
        $id_materia = intval($p['id_materia']);
        $tipo_esc = mysqli_real_escape_string($conexion, $tipo);
        $cant = intval($p['cantidad']);
        $id_mat_sql = $id_materia > 0 ? $id_materia : "NULL";
        
        mysqli_query($conexion, "INSERT INTO detalle_orden_fabrica (id_orden_fabrica, id_materia, tipo_prenda, cantidad) VALUES ($id_orden, $id_mat_sql, '$tipo_esc', $cant)");
        $id_detalle = mysqli_insert_id($conexion);
        $mapa_prendas[$tipo] = $id_detalle;

        $artes_de_esta_prenda = $bordados_por_prenda[$tipo] ?? [];
        if (empty($artes_de_esta_prenda) && !empty($bordados_por_prenda['__GENERAL__'])) {
            if (count($prendas_agrupadas) === 1 || preg_match('/(camisa|chemis|chemise|franela|jersey|filipina|bata|chaqueta|chaleco|delantal)/i', $tipo)) {
                $artes_de_esta_prenda = $bordados_por_prenda['__GENERAL__'];
            }
        }
        $texto_bordado_prenda = implode(' + ', array_unique($artes_de_esta_prenda));
        
        if (is_array($medidas)) {
            foreach ($medidas as $m) {
                if (trim($m['tipo_prenda']) === $tipo) {
                    $nom = mysqli_real_escape_string($conexion, empty($m['nombre']) ? '-' : $m['nombre']);
                    $gen = mysqli_real_escape_string($conexion, $m['genero']);
                    $tal = mysqli_real_escape_string($conexion, $m['talla']);
                    $obs_raw = trim((string)($m['obs'] ?? ''));
                    if ($texto_bordado_prenda !== '' && stripos($obs_raw, 'bordado') === false && stripos($obs_raw, $texto_bordado_prenda) === false) {
                        $obs_raw = $obs_raw !== '' ? ($obs_raw . ' | ' . $texto_bordado_prenda) : $texto_bordado_prenda;
                    }
                    $obs = mysqli_real_escape_string($conexion, $obs_raw);
                    
                    $cant_med = intval($m['cantidad'] ?? 1);
                    $tela_med = mysqli_real_escape_string($conexion, $m['tela'] ?? '');
                    $medidas_personales = is_array($m['medidas_personales'] ?? null) ? $m['medidas_personales'] : [];
                    $hom = floatval($medidas_personales['hombro'] ?? 0);
                    $bus = floatval($medidas_personales['busto_torax'] ?? 0);
                    $cin = floatval($medidas_personales['cintura'] ?? 0);
                    $cad = floatval($medidas_personales['cadera'] ?? 0);
                    $lcam = floatval($medidas_personales['largo_camisa'] ?? 0);
                    $lbra = floatval($medidas_personales['largo_brazo'] ?? 0);
                    $lpan = floatval($medidas_personales['largo_pantalon'] ?? 0);
                    $tiro = floatval($medidas_personales['tiro_total'] ?? 0);
                    $mus = floatval($medidas_personales['ancho_muslo'] ?? 0);
                    $rod = floatval($medidas_personales['ancho_rodilla'] ?? 0);
                    $talon = floatval($medidas_personales['ancho_talon'] ?? 0);
                    
                    mysqli_query($conexion, "INSERT INTO medicion_personal (
                        id_detalle_orden_fabrica, nombre, genero, talla_asignada, observacion, cantidad, tela,
                        hombro, busto_torax, cintura, cadera, largo_camisa, largo_brazo, largo_pantalon,
                        tiro_total, ancho_muslo, ancho_rodilla, ancho_talon
                    ) VALUES (
                        $id_detalle, '$nom', '$gen', '$tal', '$obs', $cant_med, '$tela_med',
                        $hom, $bus, $cin, $cad, $lcam, $lbra, $lpan, $tiro, $mus, $rod, $talon
                    )");
                    $id_medicion = mysqli_insert_id($conexion);
                    
                    if (is_array($sastreria)) {
                        foreach ($sastreria as $s) {
                            if (trim($s['nombre']) === trim($m['nombre']) && trim($s['tipo_prenda']) === trim($m['tipo_prenda'])) {
                                $hom = floatval($s['hombro']); $bus = floatval($s['busto']); $cin = floatval($s['cintura']); $cad = floatval($s['cadera']);
                                $lcam = floatval($s['l_camisa']); $lbra = floatval($s['l_brazo']); $lpan = floatval($s['l_pantalon']); $tiro = floatval($s['tiro']);
                                $mus = floatval($s['muslo']); $rod = floatval($s['rodilla']); $talon = floatval($s['talon']);
                                
                                mysqli_query($conexion, "UPDATE medicion_personal
                                                         SET hombro=IF($hom > 0, $hom, hombro),
                                                             busto_torax=IF($bus > 0, $bus, busto_torax),
                                                             cintura=IF($cin > 0, $cin, cintura),
                                                             cadera=IF($cad > 0, $cad, cadera),
                                                             largo_camisa=IF($lcam > 0, $lcam, largo_camisa),
                                                             largo_brazo=IF($lbra > 0, $lbra, largo_brazo),
                                                             largo_pantalon=IF($lpan > 0, $lpan, largo_pantalon),
                                                             tiro_total=IF($tiro > 0, $tiro, tiro_total),
                                                             ancho_muslo=IF($mus > 0, $mus, ancho_muslo),
                                                             ancho_rodilla=IF($rod > 0, $rod, ancho_rodilla),
                                                             ancho_talon=IF($talon > 0, $talon, ancho_talon)
                                                         WHERE ID=$id_medicion");
                            }
                        }
                    }
                }
            }
        }
    }

    if (is_array($artes)) {
        $primer_id_detalle = !empty($mapa_prendas) ? reset($mapa_prendas) : 0;
        foreach ($artes as $a) {
            $vinculo = trim($a['vinculo'] ?? '');
            $id_fk = $mapa_prendas[$vinculo] ?? $primer_id_detalle;
            if ($id_fk > 0) {
                $ubicacion = mysqli_real_escape_string($conexion, $a['ubicacion']);
                $elemento = mysqli_real_escape_string($conexion, $a['elemento']);
                $obs = mysqli_real_escape_string($conexion, "Cant: " . $a['cantidad']);
                mysqli_query($conexion, "INSERT INTO posicion (id_detalle_orden_fabrica, ubicacion, elemento, observacion) VALUES ($id_fk, '$ubicacion', '$elemento', '$obs')");
            }
        }
    }

    $nro_ord = $row_ord['nro_orden_fabrica'] ?? "ID $id_orden";
    registrar_auditoria($conexion, $id_usuario_actual, 'ALTERAR ORDEN', 'orden_fabrica', $id_orden, "Editó la Orden de Producción $nro_ord");

    echo json_encode(['success' => true]);
    exit;
}

if ($accion == 'eliminar') {
    if (!in_array('12', $permisos_arr) && !$es_master) { 
        echo json_encode(['success' => false, 'msg' => 'Sin Vector [12] para eliminar.']); exit; 
    }
    
    $id = intval($_POST['id']);
    
    $q_ord = mysqli_query($conexion, "SELECT nro_orden_fabrica, foto, id_cotizacion FROM orden_fabrica WHERE ID = $id");
    $row_ord = mysqli_fetch_assoc($q_ord);
    if ($row_ord && intval($row_ord['id_cotizacion'] ?? 0) > 0) {
        echo json_encode(['success' => false, 'msg' => 'Esta orden pertenece a una cotización. Usa “Revertir a Ventas” para eliminarla conservando sus reglas y habilitar una nueva orden.']);
        exit;
    }
    $nro_ord = $row_ord['nro_orden_fabrica'] ?? "Desconocida";

    $q_detalles = mysqli_query($conexion, "SELECT ID FROM detalle_orden_fabrica WHERE id_orden_fabrica = $id");
    while($d = mysqli_fetch_assoc($q_detalles)) {
        mysqli_query($conexion, "DELETE FROM medicion_personal WHERE id_detalle_orden_fabrica = {$d['ID']}");
        mysqli_query($conexion, "DELETE FROM posicion WHERE id_detalle_orden_fabrica = {$d['ID']}");
    }
    mysqli_query($conexion, "DELETE FROM detalle_orden_fabrica WHERE id_orden_fabrica = $id");
    
    if(mysqli_query($conexion, "DELETE FROM orden_fabrica WHERE ID = $id")) {
        registrar_auditoria($conexion, $id_usuario_actual, 'ELIMINAR', 'orden_fabrica', $id, "Eliminó Orden de Producción $nro_ord");
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'msg' => mysqli_error($conexion)]);
    }
    exit;
}
?>